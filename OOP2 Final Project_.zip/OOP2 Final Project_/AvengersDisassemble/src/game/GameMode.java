package game;

public enum GameMode {
    PLAYER_VS_PLAYER("Player vs Player"),
    PLAYER_VS_AI    ("Player vs AI"),
    AI_VS_AI        ("AI vs AI"),
    ARCADE          ("Arcade Mode");

    private final String displayName;
    GameMode(String d) { this.displayName = d; }
    public String getDisplayName() { return displayName; }
}
