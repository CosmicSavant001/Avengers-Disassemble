package game;

import characters.Character;
import characters.CharacterFactory;
import ai.AIController;
import battle.BattleEngine;

/**
 * Holds everything about one match (best-of-3 for PvP / PvAI).
 * Round wins are tracked here; caller checks isMatchOver() / getMatchWinner().
 */
public class GameSession {

    private GameMode mode;
    private String   blueCharacterName;
    private String   redCharacterName;
    private Character blueCharacter;
    private Character redCharacter;
    private AIController blueAI;
    private AIController redAI;
    private BattleEngine engine;

    // Best-of-3 round tracking
    private int blueRoundWins = 0;
    private int redRoundWins  = 0;
    private int currentRound  = 1;
    private static final int ROUNDS_TO_WIN = 2;  // first to 2 wins the match

    public GameSession(GameMode mode) { this.mode = mode; }

    // ── Character setup ───────────────────────────────────────────────────────

    public void setBlueCharacter(String name) {
        this.blueCharacterName = name;
        blueCharacter = CharacterFactory.createCharacter(name);
        blueCharacter.setTeam("BLUE");
    }

    public void setRedCharacter(String name) {
        this.redCharacterName = name;
        redCharacter = CharacterFactory.createCharacter(name);
        redCharacter.setTeam("RED");
        if (redAI != null) redAI.applyDifficultyScaling(redCharacter);
    }

    public void setBlueAI(AIController.Difficulty diff) {
        blueAI = new AIController(diff);
    }

    public void setRedAI(AIController.Difficulty diff) {
        redAI = new AIController(diff);
        if (redCharacter != null) redAI.applyDifficultyScaling(redCharacter);
    }

    // ── Engine ────────────────────────────────────────────────────────────────

    public BattleEngine startBattle() {
        engine = new BattleEngine(blueCharacter, redCharacter);
        return engine;
    }

    /**
     * Call after a round ends. Records the winner and prepares fresh characters
     * for the next round.
     * @param blueWon true if blue team won this round
     */
    public void recordRoundWin(boolean blueWon) {
        if (blueWon) blueRoundWins++;
        else          redRoundWins++;
        currentRound++;
        // Recreate characters fresh for next round
        if (!isMatchOver()) {
            blueCharacter = CharacterFactory.createCharacter(blueCharacterName);
            blueCharacter.setTeam("BLUE");
            redCharacter  = CharacterFactory.createCharacter(redCharacterName);
            redCharacter.setTeam("RED");
            if (redAI != null) redAI.applyDifficultyScaling(redCharacter);
        }
    }

    // ── Round/match queries ───────────────────────────────────────────────────

    /** True when one player has won enough rounds to claim the match. */
    public boolean isMatchOver() {
        return blueRoundWins >= ROUNDS_TO_WIN || redRoundWins >= ROUNDS_TO_WIN;
    }

    /** Only valid after isMatchOver() == true */
    public boolean blueWonMatch() { return blueRoundWins >= ROUNDS_TO_WIN; }

    public int getBlueRoundWins()  { return blueRoundWins; }
    public int getRedRoundWins()   { return redRoundWins; }
    public int getCurrentRound()   { return currentRound; }
    public int getRoundsToWin()    { return ROUNDS_TO_WIN; }

    // ── Arcade / non-BO3 modes don't use round tracking ──────────────────────
    public boolean isRoundBasedMode() {
        return mode == GameMode.PLAYER_VS_PLAYER || mode == GameMode.PLAYER_VS_AI;
    }

    // ── Getters ───────────────────────────────────────────────────────────────
    public AIController  getBlueAI()           { return blueAI; }
    public AIController  getRedAI()            { return redAI; }
    public GameMode      getMode()             { return mode; }
    public Character     getBlueCharacter()    { return blueCharacter; }
    public Character     getRedCharacter()     { return redCharacter; }
    public String        getBlueCharacterName(){ return blueCharacterName; }
    public String        getRedCharacterName() { return redCharacterName; }
    public BattleEngine  getEngine()           { return engine; }
}
