package ai;

import characters.Character;
import abilities.Ability;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

/**
 * AI opponent controller with three difficulty levels.
 *
 * EASY
 *   - Picks abilities randomly
 *   - Red team character stats: HP ×0.75, damage ×0.75
 *
 * NORMAL
 *   - 50 % random, 50 % picks highest-damage usable ability
 *   - Red team stats unchanged
 *
 * HARD
 *   - Always picks optimally (heals when low, uses AOE when target has high HP,
 *     otherwise highest damage)
 *   - Red team character stats: HP ×1.20, damage ×1.30
 *   - Crit chance on all abilities boosted by 0.10
 */
public class AIController {
    public enum Difficulty { EASY, NORMAL, HARD }

    private final Difficulty difficulty;
    private final Random     random;

    public AIController(Difficulty difficulty) {
        this.difficulty = difficulty;
        this.random     = new Random();
    }

    // ── Stat scaling applied once when the Red character is created ───────────

    /**
     * Scales a character's HP and mana to match the chosen difficulty.
     * Call this on the Red-team character before the battle starts.
     */
    public void applyDifficultyScaling(Character c) {
        switch (difficulty) {
            case EASY:
                c.scaleStats(0.75, 0.75);   // 75 % HP, 75 % damage
                break;
            case NORMAL:
                // no change
                break;
            case HARD:
                c.scaleStats(1.20, 1.30);   // 120 % HP, 130 % damage
                break;
        }
    }

    // ── Ability selection ─────────────────────────────────────────────────────

    public Ability selectAbility(Character actor, Character target) {
        List<Ability> all    = actor.getAbilities();
        List<Ability> usable = new ArrayList<>();
        for (Ability a : all)
            if (actor.getCurrentMana() >= a.getManaCost()) usable.add(a);
        if (usable.isEmpty()) return all.get(0);

        switch (difficulty) {
            case EASY:   return usable.get(random.nextInt(usable.size()));
            case NORMAL: return selectNormal(actor, target, usable);
            case HARD:   return selectHard(actor, target, usable);
            default:     return usable.get(0);
        }
    }

    private Ability selectNormal(Character actor, Character target, List<Ability> usable) {
        return random.nextDouble() < 0.50
                ? getBestDamage(usable)
                : usable.get(random.nextInt(usable.size()));
    }

    private Ability selectHard(Character actor, Character target, List<Ability> usable) {
        // Below 30 % HP → prefer heal or shield first
        if (actor.getHPPercent() < 0.30) {
            for (Ability a : usable)
                if (a.isHeal() || a.getEffectType() == Ability.EffectType.SHIELD)
                    return a;
        }
        // Target has > 60 % HP → prefer AOE for max value
        if (target.getHPPercent() > 0.60) {
            for (Ability a : usable)
                if (a.getTargetType() == Ability.TargetType.ALL_ENEMIES)
                    return a;
        }
        // Otherwise highest damage
        return getBestDamage(usable);
    }

    private Ability getBestDamage(List<Ability> usable) {
        Ability best = usable.get(0);
        int bestAvg  = (best.getMinDamage() + best.getMaxDamage()) / 2;
        for (Ability a : usable) {
            int avg = (a.getMinDamage() + a.getMaxDamage()) / 2;
            if (avg > bestAvg) { best = a; bestAvg = avg; }
        }
        return best;
    }

    public Character selectTarget(List<Character> targets) {
        if (targets.isEmpty()) return null;
        // Hard AI targets the weakest; others random
        if (difficulty == Difficulty.HARD) {
            Character weakest = targets.get(0);
            for (Character c : targets)
                if (c.getCurrentHP() < weakest.getCurrentHP()) weakest = c;
            return weakest;
        }
        return targets.get(random.nextInt(targets.size()));
    }

    public Difficulty getDifficulty() { return difficulty; }
}
