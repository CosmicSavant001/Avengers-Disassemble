package characters;

import abilities.Ability;
import abilities.Ability.TargetType;
import abilities.Ability.EffectType;

public class BlackWidow extends Character {
    public BlackWidow() {
        super("Black Widow", 2000, 450);
        backstory = "A master tactician who uses strategy and precision to outsmart cloned opponents.";
    }

    @Override
    protected void initAbilities() {
        abilities.add(new Ability("Brylle Shadow Strike",
            "A swift strike from the shadows dealing moderate damage.", 180, 250, 60, TargetType.SINGLE_ENEMY));
        abilities.add(new Ability("Ivanna Silent Execution",
            "A precise strike that reduces the enemy's defense.", 210, 310, 90, TargetType.SINGLE_ENEMY)
            .setEffect(EffectType.REDUCE_DEFENSE, 30, 2));
        abilities.add(new Ability("Fantastic Tactical Command",
            "Commands the team, hitting all enemies and boosting team speed and evasion.", 150, 220, 130, TargetType.ALL_ENEMIES)
            .setEffect(EffectType.SPEED_BOOST, 20, 2));
    }

    @Override
    public String getImagePath() { return "assets/sprites/blackwidow.png"; }
}
