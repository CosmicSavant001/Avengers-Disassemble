package characters;

import java.util.ArrayList;
import java.util.List;

public class CharacterFactory {

    public static final String[] CHARACTER_NAMES = {
        "Iron Man", "Spider-Man", "Thor", "Hulk",
        "Black Widow", "Scarlet Witch", "Doctor Strange", "Cadie",
        "Loki", "Ultron"
    };

    public static Character createCharacter(String name) {
        switch (name) {
            case "Iron Man": return new IronMan();
            case "Spider-Man": return new SpiderMan();
            case "Thor": return new Thor();
            case "Hulk": return new Hulk();
            case "Black Widow": return new BlackWidow();
            case "Scarlet Witch": return new ScarletWitch();
            case "Doctor Strange": return new DoctorStrange();
            case "Cadie": return new Cadie();
            case "Loki": return new Loki();
            case "Ultron": return new Ultron();
            default: throw new IllegalArgumentException("Unknown character: " + name);
        }
    }

    public static List<Character> getAllCharacters() {
        List<Character> list = new ArrayList<>();
        for (String name : CHARACTER_NAMES) {
            list.add(createCharacter(name));
        }
        return list;
    }

    public static List<Character> getHeroCharacters() {
        List<Character> list = new ArrayList<>();
        String[] heroes = {"Iron Man", "Spider-Man", "Thor", "Hulk",
                           "Black Widow", "Scarlet Witch", "Doctor Strange", "Cadie"};
        for (String name : heroes) {
            list.add(createCharacter(name));
        }
        return list;
    }

    public static List<Character> getVillainCharacters() {
        List<Character> list = new ArrayList<>();
        list.add(createCharacter("Loki"));
        list.add(createCharacter("Ultron"));
        return list;
    }
}
