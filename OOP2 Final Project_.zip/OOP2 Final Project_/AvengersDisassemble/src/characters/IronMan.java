package characters;

import abilities.Ability;
import abilities.Ability.TargetType;
import abilities.Ability.EffectType;

public class IronMan extends Character {
    public IronMan() {
        super("Iron Man", 2400, 500);
        backstory = "A genius billionaire inventor who upgrades his armor to survive the Multiversal Clash Arena and stop Ultron's cloning system.";
    }

    @Override
    protected void initAbilities() {
        abilities.add(new Ability("Brylle Reactor Strike",
            "Fires a focused repulsor beam at a single enemy.", 160, 250, 60, TargetType.SINGLE_ENEMY));
        abilities.add(new Ability("Embodo Armor Boost",
            "Supercharges the armor, increasing attack power for 2 turns.", 120, 180, 80, TargetType.SINGLE_ENEMY)
            .setEffect(EffectType.ATTACK_BOOST, 30, 2));
        abilities.add(new Ability("Fantastic Fusion Barrage",
            "Unleashes a full repulsor barrage targeting all enemies.", 350, 520, 150, TargetType.ALL_ENEMIES));
    }

    @Override
    public String getImagePath() { return "assets/sprites/ironman.png"; }
}
