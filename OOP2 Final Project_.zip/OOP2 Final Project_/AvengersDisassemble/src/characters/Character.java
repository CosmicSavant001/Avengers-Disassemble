package characters;

import abilities.Ability;
import java.util.List;
import java.util.ArrayList;

public abstract class Character {
    protected String name;
    protected int maxHP;
    protected int currentHP;
    protected int maxMana;
    protected int currentMana;
    protected int attackBoost;
    protected int defenseBoost;
    protected int speedBoost;
    protected boolean isStunned;
    protected boolean isConfused;
    protected boolean isImmobilized;
    protected boolean hasShield;
    protected int shieldAmount;
    protected int attackBoostTurns;
    protected int defenseBoostTurns;
    protected int speedBoostTurns;
    protected int stunTurns;
    protected int confuseTurns;
    protected int immobilizeTurns;
    protected List<Ability> abilities;
    protected String backstory;
    protected String team; // "BLUE" or "RED"
    protected String imagePath;

    public Character(String name, int maxHP, int maxMana) {
        this.name = name;
        this.maxHP = maxHP;
        this.currentHP = maxHP;
        this.maxMana = maxMana;
        this.currentMana = maxMana;
        this.attackBoost = 0;
        this.defenseBoost = 0;
        this.speedBoost = 0;
        this.isStunned = false;
        this.isConfused = false;
        this.isImmobilized = false;
        this.hasShield = false;
        this.shieldAmount = 0;
        this.attackBoostTurns = 0;
        this.defenseBoostTurns = 0;
        this.speedBoostTurns = 0;
        this.stunTurns = 0;
        this.confuseTurns = 0;
        this.immobilizeTurns = 0;
        this.abilities = new ArrayList<>();
        initAbilities();
    }

    protected abstract void initAbilities();
    public abstract String getImagePath();

    public void takeDamage(int damage) {
        if (hasShield && shieldAmount > 0) {
            if (damage <= shieldAmount) {
                shieldAmount -= damage;
                if (shieldAmount <= 0) {
                    hasShield = false;
                    shieldAmount = 0;
                }
                return;
            } else {
                damage -= shieldAmount;
                hasShield = false;
                shieldAmount = 0;
            }
        }
        int reducedDamage = Math.max(1, damage - defenseBoost);
        currentHP = Math.max(0, currentHP - reducedDamage);
    }

    public void heal(int amount) {
        currentHP = Math.min(maxHP, currentHP + amount);
    }

    public void regenMana(int amount) {
        currentMana = Math.min(maxMana, currentMana + amount);
    }

    public void useMana(int amount) {
        currentMana = Math.min(maxMana, Math.max(0, currentMana - amount));
    }

    public boolean isAlive() {
        return currentHP > 0;
    }

    public void applyShield(int amount) {
        hasShield = true;
        shieldAmount = amount;
    }

    public void applyAttackBoost(int amount, int turns) {
        attackBoost += amount;
        attackBoostTurns = turns;
    }

    public void applyDefenseBoost(int amount, int turns) {
        defenseBoost += amount;
        defenseBoostTurns = turns;
    }

    public void applySpeedBoost(int amount, int turns) {
        speedBoost += amount;
        speedBoostTurns = turns;
    }

    public void applyStun(int turns) {
        isStunned = true;
        stunTurns = turns;
    }

    public void applyConfuse(int turns) {
        isConfused = true;
        confuseTurns = turns;
    }

    public void applyImmobilize(int turns) {
        isImmobilized = true;
        immobilizeTurns = turns;
    }

    public void reduceDefense(int amount) {
        defenseBoost = Math.max(-100, defenseBoost - amount);
    }

    public void tickStatusEffects() {
        if (attackBoostTurns > 0) {
            attackBoostTurns--;
            if (attackBoostTurns == 0) attackBoost = Math.max(0, attackBoost - 30);
        }
        if (defenseBoostTurns > 0) {
            defenseBoostTurns--;
            if (defenseBoostTurns == 0) defenseBoost = Math.max(0, defenseBoost - 20);
        }
        if (speedBoostTurns > 0) {
            speedBoostTurns--;
            if (speedBoostTurns == 0) speedBoost = 0;
        }
        if (stunTurns > 0) {
            stunTurns--;
            if (stunTurns == 0) isStunned = false;
        }
        if (confuseTurns > 0) {
            confuseTurns--;
            if (confuseTurns == 0) isConfused = false;
        }
        if (immobilizeTurns > 0) {
            immobilizeTurns--;
            if (immobilizeTurns == 0) isImmobilized = false;
        }
    }

    public void resetForBattle() {
        currentHP = maxHP;
        currentMana = maxMana;
        attackBoost = 0;
        defenseBoost = 0;
        speedBoost = 0;
        isStunned = false;
        isConfused = false;
        isImmobilized = false;
        hasShield = false;
        shieldAmount = 0;
        attackBoostTurns = 0;
        defenseBoostTurns = 0;
        speedBoostTurns = 0;
        stunTurns = 0;
        confuseTurns = 0;
        immobilizeTurns = 0;
    }

    public String getStatusString() {
        StringBuilder sb = new StringBuilder();
        if (isStunned) sb.append("[STUNNED] ");
        if (isConfused) sb.append("[CONFUSED] ");
        if (isImmobilized) sb.append("[IMMOBILIZED] ");
        if (hasShield) sb.append("[SHIELD:" + shieldAmount + "] ");
        if (attackBoost > 0) sb.append("[ATK+] ");
        if (defenseBoost > 0) sb.append("[DEF+] ");
        if (speedBoost > 0) sb.append("[SPD+] ");
        return sb.toString().trim();
    }

    // Getters
    public String getName() { return name; }
    public int getCurrentHP() { return currentHP; }
    public int getMaxHP() { return maxHP; }
    public int getCurrentMana() { return currentMana; }
    public int getMaxMana() { return maxMana; }
    public List<Ability> getAbilities() { return abilities; }
    public String getBackstory() { return backstory; }
    public String getTeam() { return team; }
    public void setTeam(String team) { this.team = team; }
    public int getAttackBoost() { return attackBoost; }
    public int getDefenseBoost() { return defenseBoost; }
    public boolean isStunned() { return isStunned; }
    public boolean isConfused() { return isConfused; }
    public boolean isImmobilized() { return isImmobilized; }
    public boolean hasShield() { return hasShield; }
    public int getShieldAmount() { return shieldAmount; }

    public double getHPPercent() {
        return (double) currentHP / maxHP;
    }

    public double getManaPercent() {
        return (double) currentMana / maxMana;
    }

    @Override
    public String toString() {
        return name + " [HP: " + currentHP + "/" + maxHP + " | MP: " + currentMana + "/" + maxMana + "]";
    }

    /**
     * Scales this character's max HP and ability damage by the given multipliers.
     * Called once by AIController.applyDifficultyScaling() on the Red team character.
     * hpMult  e.g. 0.75 = Easy, 1.0 = Normal, 1.20 = Hard
     * dmgMult e.g. 0.75 = Easy, 1.0 = Normal, 1.30 = Hard
     */
    public void scaleStats(double hpMult, double dmgMult) {
        maxHP     = (int)(maxHP     * hpMult);
        currentHP = (int)(currentHP * hpMult);
        maxMana   = (int)(maxMana   * hpMult);
        currentMana = maxMana;
        for (abilities.Ability a : abilities) {
            a.scaleDamage(dmgMult);
        }
    }

}
