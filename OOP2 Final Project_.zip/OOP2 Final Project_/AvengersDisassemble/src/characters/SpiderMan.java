package characters;

import abilities.Ability;
import abilities.Ability.TargetType;
import abilities.Ability.EffectType;

public class SpiderMan extends Character {
    public SpiderMan() {
        super("Spider-Man", 2100, 450);
        backstory = "Pulled into the arena, Spider-Man relies on agility and intelligence to outmaneuver his own clone and protect the Blue Team.";
    }

    @Override
    protected void initAbilities() {
        abilities.add(new Ability("Kate Precision Web",
            "Shoots a precision web to immobilize the target for 1 turn.", 130, 210, 60, TargetType.SINGLE_ENEMY)
            .setEffect(EffectType.IMMOBILIZE, 1, 1));
        abilities.add(new Ability("Lucy Kate Aerial Combo",
            "Performs a rapid aerial combo with high critical hit chance.", 260, 390, 100, TargetType.SINGLE_ENEMY)
            .setCritChance(0.4));
        abilities.add(new Ability("Patagnan Ultimate Web Lock",
            "Fires webs at all enemies, reducing their speed and accuracy.", 320, 470, 140, TargetType.ALL_ENEMIES)
            .setEffect(EffectType.REDUCE_DEFENSE, 20, 2));
    }

    @Override
    public String getImagePath() { return "assets/sprites/spiderman.png"; }
}
