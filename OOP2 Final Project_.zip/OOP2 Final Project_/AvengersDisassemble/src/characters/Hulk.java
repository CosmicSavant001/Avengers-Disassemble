package characters;

import abilities.Ability;
import abilities.Ability.TargetType;
import abilities.Ability.EffectType;

public class Hulk extends Character {
    public Hulk() {
        super("Hulk", 3500, 300);
        backstory = "Fueled by rage, Hulk battles his clone to prove that true strength comes from heart, not programming.";
    }

    @Override
    protected void initAbilities() {
        abilities.add(new Ability("Raymund Power Smash",
            "Delivers a ground-shaking smash to a single enemy.", 190, 270, 60, TargetType.SINGLE_ENEMY));
        abilities.add(new Ability("Alerta Arena Breaker",
            "Slams the ground with both fists, hitting all enemies.", 220, 320, 100, TargetType.ALL_ENEMIES));
        abilities.add(new Ability("Vince Ultimate Fury",
            "Enters a rage state, increasing attack and defense for 3 turns.", 250, 350, 120, TargetType.SINGLE_ENEMY)
            .setEffect(EffectType.ATTACK_BOOST, 40, 3));
    }

    @Override
    public String getImagePath() { return "assets/sprites/hulk.png"; }
}
