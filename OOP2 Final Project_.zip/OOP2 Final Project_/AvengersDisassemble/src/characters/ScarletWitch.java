package characters;

import abilities.Ability;
import abilities.Ability.TargetType;
import abilities.Ability.EffectType;

public class ScarletWitch extends Character {
    public ScarletWitch() {
        super("Scarlet Witch", 2200, 600);
        backstory = "Using chaos magic, she senses the imbalance caused by cloning and fights to restore reality.";
    }

    @Override
    protected void initAbilities() {
        abilities.add(new Ability("Tubiano Chaos Burst",
            "Unleashes chaos energy that lowers enemy attack.", 160, 240, 70, TargetType.SINGLE_ENEMY)
            .setEffect(EffectType.REDUCE_DEFENSE, 25, 2));
        abilities.add(new Ability("Embodo Reality Wave",
            "Sends a reality-warping wave that hits all enemies.", 230, 360, 120, TargetType.ALL_ENEMIES));
        abilities.add(new Ability("Fantastic Distortion Field",
            "Creates a confusion field that hits all enemies and confuses them for 1 turn.", 280, 420, 160, TargetType.ALL_ENEMIES)
            .setEffect(EffectType.CONFUSE, 1, 1));
    }

    @Override
    public String getImagePath() { return "assets/sprites/scarletwitch.png"; }
}
