package characters;

import abilities.Ability;
import abilities.Ability.TargetType;
import abilities.Ability.EffectType;

public class DoctorStrange extends Character {
    public DoctorStrange() {
        super("Doctor Strange", 2100, 650);
        backstory = "The protector of the multiverse who understands the danger of cloning technology and time manipulation.";
    }

    @Override
    protected void initAbilities() {
        abilities.add(new Ability("Brylle Mystic Guard",
            "Creates a mystic shield that absorbs incoming damage.", 140, 200, 80, TargetType.SELF)
            .setEffect(EffectType.SHIELD, 300, 0));
        abilities.add(new Ability("Alerta Time Restore",
            "Manipulates time to heal an ally's wounds.", 0, 0, 90, TargetType.SINGLE_ALLY)
            .setHeal(260));
        abilities.add(new Ability("Ivanna Astral Judgment",
            "Channels astral energy in an attack that ignores the target's defense.", 320, 480, 150, TargetType.SINGLE_ENEMY)
            .setEffect(EffectType.IGNORE_DEFENSE, 1, 0));
    }

    @Override
    public String getImagePath() { return "assets/sprites/doctorstrange.png"; }
}
