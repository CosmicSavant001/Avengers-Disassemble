package characters;

import abilities.Ability;
import abilities.Ability.TargetType;
import abilities.Ability.EffectType;

public class Loki extends Character {
    public Loki() {
        super("Loki", 3800, 750);
        backstory = "The God of Mischief who traps heroes inside the arena for entertainment and manipulation.";
    }

    @Override
    protected void initAbilities() {
        abilities.add(new Ability("Illusionary Mirror",
            "Creates a temporary illusion that repeats an attack, dealing moderate damage.", 220, 320, 80, TargetType.SINGLE_ENEMY)
            .setEffect(EffectType.SUMMON_CLONE, 1, 2));
        abilities.add(new Ability("Scepter Energy Surge",
            "Channels energy from the scepter hitting all enemies with a chance to stun.", 300, 420, 130, TargetType.ALL_ENEMIES)
            .setEffect(EffectType.STUN, 1, 1));
        abilities.add(new Ability("God of Mischief's Deception",
            "Summons a clone of an enemy to fight for several turns.", 350, 500, 180, TargetType.SINGLE_ENEMY)
            .setEffect(EffectType.SUMMON_CLONE, 1, 3));
    }

    @Override
    public String getImagePath() { return "assets/sprites/loki.png"; }
}
