package characters;

import abilities.Ability;
import abilities.Ability.TargetType;
import abilities.Ability.EffectType;

public class Ultron extends Character {
    public Ultron() {
        super("Ultron", 4200, 600);
        backstory = "The AI villain who creates perfect clones, believing machines are superior to humans.";
    }

    @Override
    protected void initAbilities() {
        abilities.add(new Ability("Vibranium Beam",
            "Fires a concentrated vibranium energy beam at a single enemy.", 240, 340, 80, TargetType.SINGLE_ENEMY));
        abilities.add(new Ability("Drone Replication Protocol",
            "Summons drone allies to assist in combat.", 200, 280, 100, TargetType.SINGLE_ENEMY)
            .setEffect(EffectType.SUMMON_CLONE, 1, 2));
        abilities.add(new Ability("Extinction Command",
            "Issues the extinction command, hitting all enemies and lowering their defense.", 380, 550, 170, TargetType.ALL_ENEMIES)
            .setEffect(EffectType.REDUCE_DEFENSE, 40, 2));
    }

    @Override
    public String getImagePath() { return "assets/sprites/ultron.png"; }
}
