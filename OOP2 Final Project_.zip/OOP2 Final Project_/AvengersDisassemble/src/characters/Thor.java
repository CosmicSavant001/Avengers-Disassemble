package characters;

import abilities.Ability;
import abilities.Ability.TargetType;
import abilities.Ability.EffectType;

public class Thor extends Character {
    public Thor() {
        super("Thor", 2700, 400);
        backstory = "The God of Thunder enters the arena to stop Loki's chaos and Ultron's technological threat.";
    }

    @Override
    protected void initAbilities() {
        abilities.add(new Ability("Ivanna Lightning Strike",
            "Calls down a bolt of lightning on a single enemy.", 170, 250, 70, TargetType.SINGLE_ENEMY));
        abilities.add(new Ability("Tubiano Thunder Crash",
            "Smashes Mjolnir into the ground, sending shockwaves to all enemies.", 210, 330, 110, TargetType.ALL_ENEMIES));
        abilities.add(new Ability("Lucy Storm Dominion",
            "Unleashes a full storm that devastates all enemies.", 420, 560, 160, TargetType.ALL_ENEMIES));
    }

    @Override
    public String getImagePath() { return "assets/sprites/thor.png"; }
}
