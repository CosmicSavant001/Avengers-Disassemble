package characters;

import abilities.Ability;
import abilities.Ability.TargetType;
import abilities.Ability.EffectType;

public class Cadie extends Character {
    public Cadie() {
        super("Cadie", 2600, 350);
        backstory = "A chubby orange Flerken cat who unexpectedly joins the fight. After eating, Cadie becomes stronger, and his unique way of drinking water unlocks healing abilities.";
    }

    @Override
    protected void initAbilities() {
        abilities.add(new Ability("Vince's Six-Hour Hunger Call",
            "Cadie howls from hunger, striking with surprising force. Gains attack boost after several turns.", 150, 230, 60, TargetType.SINGLE_ENEMY)
            .setEffect(EffectType.ATTACK_BOOST, 35, 3));
        abilities.add(new Ability("Raymund Paw Dip Ritual",
            "Cadie dips paw in water and licks it, gradually healing himself.", 100, 150, 70, TargetType.SELF)
            .setHeal(200));
        abilities.add(new Ability("Alerta Direct Drink Awakening",
            "Cadie drinks directly from a bowl, restoring large HP and increasing defense.", 180, 260, 100, TargetType.SELF)
            .setHeal(400).setEffect(EffectType.DEFENSE_BOOST, 30, 3));
    }

    @Override
    public String getImagePath() { return "assets/sprites/cadie.png"; }
}
