package battle;

import characters.Character;
import abilities.Ability;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

public class BattleEngine {
    private Character blueTeam;
    private Character redTeam;
    private List<String> battleLog;
    private boolean blueTeamTurn;
    private boolean battleOver;
    private String winner;
    private Random random;
    private BattleListener listener;

    public interface BattleListener {
        void onBattleLogUpdate(String message);
        void onTurnChange(boolean blueTeamTurn);
        void onBattleEnd(String winner);
        void onStatusUpdate();
    }

    public BattleEngine(Character blue, Character red) {
        this.blueTeam     = blue;
        this.redTeam      = red;
        this.battleLog    = new ArrayList<>();
        this.blueTeamTurn = true;
        this.battleOver   = false;
        this.random       = new Random();
        blueTeam.resetForBattle();
        redTeam.resetForBattle();
    }

    public void setListener(BattleListener listener) {
        this.listener = listener;
    }

    /**
     * Execute an ability for the current attacker.
     * Mana shortage is handled gracefully — the cheapest ability is auto-selected
     * and mana is refilled to cover it, so the game NEVER stalls.
     */
    public BattleResult executeAbility(Character attacker, Character target, Ability ability) {
        if (battleOver) return null;

        // ── Mana safety net ───────────────────────────────────────────────────
        // If the attacker can't afford the requested ability, pick their cheapest
        // one and give just enough mana for it. This prevents any stall scenario.
        if (attacker.getCurrentMana() < ability.getManaCost()) {
            List<abilities.Ability> all = attacker.getAbilities();
            abilities.Ability cheapest = all.get(0);
            for (abilities.Ability a : all)
                if (a.getManaCost() < cheapest.getManaCost()) cheapest = a;
            int needed = cheapest.getManaCost() - attacker.getCurrentMana();
            if (needed > 0) attacker.regenMana(needed);
            ability = cheapest;
            log(attacker.getName() + " focuses and uses " + cheapest.getName() + "!");
        }

        attacker.useMana(ability.getManaCost());

        // ── Status effects that skip turns ────────────────────────────────────
        if (attacker.isStunned()) {
            log(attacker.getName() + " is stunned and cannot act!");
            endTurn(attacker);
            return new BattleResult(false, 0, false, attacker.getName() + " is stunned!");
        }
        if (attacker.isImmobilized()) {
            log(attacker.getName() + " is immobilized!");
            endTurn(attacker);
            return new BattleResult(false, 0, false, attacker.getName() + " is immobilized!");
        }

        // ── Damage calculation ────────────────────────────────────────────────
        int damage  = ability.rollDamage();
        boolean crit = ability.rollCrit();
        if (crit) damage = (int)(damage * 1.5);
        damage += attacker.getAttackBoost();

        StringBuilder logMsg = new StringBuilder();
        logMsg.append(attacker.getName()).append(" uses ").append(ability.getName()).append("!");
        if (crit) logMsg.append(" CRITICAL HIT!");

        // ── Apply to target(s) ────────────────────────────────────────────────
        List<Character> targets = new ArrayList<>();
        if (ability.getTargetType() == Ability.TargetType.SINGLE_ALLY
         || ability.getTargetType() == Ability.TargetType.SELF) {
            targets.add(attacker);
        } else {
            targets.add(target);
        }

        for (Character t : targets) {
            if (ability.isHeal()) {
                t.heal(ability.getHealAmount());
                logMsg.append("\n  ").append(t.getName())
                      .append(" healed for ").append(ability.getHealAmount()).append(" HP!");
            } else if (damage > 0) {
                boolean ignoreDefense = ability.getEffectType() == Ability.EffectType.IGNORE_DEFENSE;
                if (ignoreDefense) {
                    int oldDef = t.getDefenseBoost();
                    t.applyDefenseBoost(-oldDef, 0);
                    t.takeDamage(damage);
                    t.applyDefenseBoost(oldDef, 0);
                } else {
                    t.takeDamage(damage);
                }
                logMsg.append("\n  ").append(t.getName())
                      .append(" takes ").append(damage).append(" damage!");
                if (!t.isAlive())
                    logMsg.append("\n  ").append(t.getName()).append(" has been defeated!");
            }
            applyEffect(attacker, t, ability, logMsg);
        }

        log(logMsg.toString());
        checkBattleEnd();
        if (listener != null) listener.onStatusUpdate();
        endTurn(attacker);

        return new BattleResult(true, damage, crit, logMsg.toString());
    }

    private void applyEffect(Character attacker, Character target,
                              Ability ability, StringBuilder logMsg) {
        Ability.EffectType effect = ability.getEffectType();
        if (effect == Ability.EffectType.NONE
         || effect == Ability.EffectType.IGNORE_DEFENSE) return;
        if (random.nextDouble() > 0.7) return;

        int val = ability.getEffectValue(), turns = ability.getEffectTurns();
        switch (effect) {
            case STUN:
                target.applyStun(turns);
                logMsg.append("\n  ").append(target.getName())
                      .append(" is STUNNED for ").append(turns).append(" turn(s)!"); break;
            case CONFUSE:
                target.applyConfuse(turns);
                logMsg.append("\n  ").append(target.getName())
                      .append(" is CONFUSED for ").append(turns).append(" turn(s)!"); break;
            case IMMOBILIZE:
                target.applyImmobilize(turns);
                logMsg.append("\n  ").append(target.getName())
                      .append(" is IMMOBILIZED for ").append(turns).append(" turn(s)!"); break;
            case ATTACK_BOOST:
                attacker.applyAttackBoost(val, turns);
                logMsg.append("\n  ").append(attacker.getName()).append(" gains ATTACK BOOST!"); break;
            case DEFENSE_BOOST:
                attacker.applyDefenseBoost(val, turns);
                logMsg.append("\n  ").append(attacker.getName()).append(" gains DEFENSE BOOST!"); break;
            case SPEED_BOOST:
                attacker.applySpeedBoost(val, turns);
                logMsg.append("\n  ").append(attacker.getName()).append(" gains SPEED BOOST!"); break;
            case REDUCE_DEFENSE:
                target.reduceDefense(val);
                logMsg.append("\n  ").append(target.getName()).append("'s defense is REDUCED!"); break;
            case SHIELD:
                attacker.applyShield(val);
                logMsg.append("\n  ").append(attacker.getName())
                      .append(" creates a shield absorbing ").append(val).append(" damage!"); break;
            case HEAL:
                attacker.heal(val);
                logMsg.append("\n  ").append(attacker.getName()).append(" heals ").append(val).append(" HP!"); break;
            case SUMMON_CLONE:
                logMsg.append("\n  ").append(attacker.getName()).append(" summons a clone!"); break;
            default: break;
        }
    }

    private void endTurn(Character actor) {
        actor.tickStatusEffects();
        // Generous mana regen: 15% of max per turn so characters never run fully dry
        int regen = Math.max(20, (int)(actor.getMaxMana() * 0.15));
        actor.regenMana(regen);
        blueTeamTurn = !blueTeamTurn;
        if (listener != null) listener.onTurnChange(blueTeamTurn);
    }

    private void checkBattleEnd() {
        if (!blueTeam.isAlive()) {
            battleOver = true;
            winner = redTeam.getName() + " (Red Team)";
            log("\n=== " + winner + " WINS! ===");
            if (listener != null) listener.onBattleEnd(winner);
        } else if (!redTeam.isAlive()) {
            battleOver = true;
            winner = blueTeam.getName() + " (Blue Team)";
            log("\n=== " + winner + " WINS! ===");
            if (listener != null) listener.onBattleEnd(winner);
        }
    }

    private void log(String msg) {
        battleLog.add(msg);
        if (listener != null) listener.onBattleLogUpdate(msg);
    }

    public Character getCurrentActor()    { return blueTeamTurn ? blueTeam : redTeam; }
    public Character getCurrentTarget()   { return blueTeamTurn ? redTeam  : blueTeam; }
    public boolean isBlueTeamTurn()       { return blueTeamTurn; }
    public boolean isBattleOver()         { return battleOver; }
    public String  getWinner()            { return winner; }
    public Character getBlueTeam()        { return blueTeam; }
    public Character getRedTeam()         { return redTeam; }
    public List<String> getBattleLog()    { return battleLog; }
}
