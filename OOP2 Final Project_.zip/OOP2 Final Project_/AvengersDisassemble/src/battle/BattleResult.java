package battle;

public class BattleResult {
    private boolean success;
    private int damage;
    private boolean isCrit;
    private String message;

    public BattleResult(boolean success, int damage, boolean isCrit, String message) {
        this.success = success;
        this.damage = damage;
        this.isCrit = isCrit;
        this.message = message;
    }

    public boolean isSuccess() { return success; }
    public int getDamage() { return damage; }
    public boolean isCrit() { return isCrit; }
    public String getMessage() { return message; }
}
