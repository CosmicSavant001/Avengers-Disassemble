package graphics;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;

/**
 * Creates character portrait images using real sprite assets.
 * Uses the south-facing frame (the "looking at you" pose) scaled up
 * with nearest-neighbour to fill the portrait area.
 *
 * Falls back to CharacterPortraitRenderer if sprite is missing.
 */
public class SpritePortrait {

    /**
     * Render a w×h portrait for the named character.
     * The sprite frame is drawn centred on a themed gradient background.
     */
    public static BufferedImage render(String charName, int w, int h) {
        // Load the south-facing frame at native size first, then we'll scale it
        BufferedImage[] frames = SpriteLoader.load(charName, 128);
        BufferedImage southFrame = (frames != null) ? frames[SpriteLoader.DIR_SOUTH] : null;

        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,  RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        g.setRenderingHint(RenderingHints.KEY_RENDERING,     RenderingHints.VALUE_RENDER_QUALITY);

        if (southFrame != null) {
            drawSpritePortrait(g, charName, southFrame, w, h);
        } else {
            // Hard fallback – use the old Java2D renderer
            BufferedImage fallback = CharacterPortraitRenderer.render(charName, w, h);
            g.drawImage(fallback, 0, 0, null);
        }

        g.dispose();
        return img;
    }

    private static void drawSpritePortrait(Graphics2D g, String charName,
                                            BufferedImage sprite, int w, int h) {
        Color top    = topColor(charName);
        Color bottom = bottomColor(charName);

        // Rounded background
        g.setPaint(new GradientPaint(0, 0, top, 0, h, bottom));
        g.fillRoundRect(0, 0, w, h, 14, 14);

        // Subtle inner glow
        Color glow = glowColor(charName);
        RadialGradientPaint rg = new RadialGradientPaint(
                w / 2f, h * 0.45f, w * 0.55f,
                new float[]{0f, 1f},
                new Color[]{new Color(glow.getRed(), glow.getGreen(), glow.getBlue(), 60),
                             new Color(glow.getRed(), glow.getGreen(), glow.getBlue(), 0)});
        g.setPaint(rg);
        g.fillRoundRect(0, 0, w, h, 14, 14);

        // Draw sprite scaled to fill ~85% of height, centred horizontally
        int sprH = (int)(h * 0.85);
        int sprW = sprH; // sprites are square
        int sprX = (w - sprW) / 2;
        int sprY = (int)(h * 0.08);

        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                           RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        g.drawImage(sprite, sprX, sprY, sprW, sprH, null);

        // Thin coloured border
        g.setColor(new Color(glow.getRed(), glow.getGreen(), glow.getBlue(), 160));
        g.setStroke(new BasicStroke(1.5f));
        g.drawRoundRect(1, 1, w-2, h-2, 14, 14);

        // Name label at bottom
        g.setFont(new Font("Impact", Font.PLAIN, Math.max(9, w / 8)));
        FontMetrics fm = g.getFontMetrics();
        String label = charName.toUpperCase();
        int tx = (w - fm.stringWidth(label)) / 2;
        int ty = h - 5;
        g.setColor(new Color(0, 0, 0, 160));
        g.drawString(label, tx+1, ty+1);
        g.setColor(new Color(255, 255, 255, 230));
        g.drawString(label, tx, ty);
    }

    // ── Colour palettes per character ─────────────────────────────────────────

    private static Color topColor(String name) {
        switch (name) {
            case "Iron Man":       return new Color(60, 8, 8);
            case "Spider-Man":     return new Color(10, 8, 50);
            case "Thor":           return new Color(10, 18, 60);
            case "Hulk":           return new Color(8, 38, 8);
            case "Black Widow":    return new Color(10, 10, 10);
            case "Scarlet Witch":  return new Color(45, 5, 5);
            case "Doctor Strange": return new Color(5, 5, 35);
            case "Cadie":          return new Color(18, 28, 50);
            case "Loki":           return new Color(5, 20, 10);
            case "Ultron":         return new Color(10, 10, 15);
            default:               return new Color(15, 15, 35);
        }
    }

    private static Color bottomColor(String name) {
        switch (name) {
            case "Iron Man":       return new Color(22, 4, 4);
            case "Spider-Man":     return new Color(5, 5, 28);
            case "Thor":           return new Color(5, 10, 32);
            case "Hulk":           return new Color(4, 18, 4);
            case "Black Widow":    return new Color(5, 5, 22);
            case "Scarlet Witch":  return new Color(22, 4, 30);
            case "Doctor Strange": return new Color(20, 5, 50);
            case "Cadie":          return new Color(5, 10, 25);
            case "Loki":           return new Color(10, 5, 30);
            case "Ultron":         return new Color(5, 5, 28);
            default:               return new Color(8, 8, 22);
        }
    }

    private static Color glowColor(String name) {
        switch (name) {
            case "Iron Man":       return new Color(255, 80, 20);
            case "Spider-Man":     return new Color(200, 20, 20);
            case "Thor":           return new Color(100, 160, 255);
            case "Hulk":           return new Color(50, 220, 50);
            case "Black Widow":    return new Color(200, 20, 20);
            case "Scarlet Witch":  return new Color(220, 40, 90);
            case "Doctor Strange": return new Color(80, 180, 255);
            case "Cadie":          return new Color(255, 150, 50);
            case "Loki":           return new Color(60, 200, 80);
            case "Ultron":         return new Color(220, 60, 0);
            default:               return new Color(120, 100, 220);
        }
    }
}
