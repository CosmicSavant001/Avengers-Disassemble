package graphics;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Loads and caches all 8-direction sprite frames for every character.
 * Works both when running from a JAR (classpath resources) and from
 * a plain directory (filesystem fallback).
 * Frames are scaled up with nearest-neighbour to stay crisp.
 */
public class SpriteLoader {

    public static final String[] DIRECTIONS = {
        "south", "south-east", "east", "north-east",
        "north", "north-west", "west", "south-west"
    };

    public static final int DIR_SOUTH = 0;
    public static final int DIR_SE    = 1;
    public static final int DIR_EAST  = 2;
    public static final int DIR_NE    = 3;
    public static final int DIR_NORTH = 4;
    public static final int DIR_NW    = 5;
    public static final int DIR_WEST  = 6;
    public static final int DIR_SW    = 7;

    private static final Map<String, BufferedImage[]> cache = new HashMap<>();

    private static String folderFor(String charName) {
        switch (charName) {
            case "Iron Man":       return "iron_man";
            case "Spider-Man":     return "spider_man";
            case "Thor":           return "thor";
            case "Hulk":           return "hulk";
            case "Black Widow":    return "black_widow";
            case "Scarlet Witch":  return "scarlet_witch";
            case "Doctor Strange": return "doctor_strange";
            case "Cadie":          return "cadie";
            case "Loki":           return "loki";
            case "Ultron":         return "ultron";
            default:               return charName.toLowerCase().replace(" ", "_");
        }
    }

    private static String baseFor(String charName) {
        switch (charName) {
            case "Loki": case "Ultron": return "assets/images/enemies";
            default:                   return "assets/images/heroes";
        }
    }

    /**
     * Load 8 directional frames, scaled to targetSize×targetSize.
     * Tries classpath first (JAR), then filesystem (development).
     */
    public static BufferedImage[] load(String charName, int targetSize) {
        String key = charName + "@" + targetSize;
        if (cache.containsKey(key)) return cache.get(key);

        String folder = folderFor(charName);
        String base   = baseFor(charName);
        BufferedImage[] frames = new BufferedImage[8];

        for (int i = 0; i < 8; i++) {
            String resourcePath = base + "/" + folder + "/" + DIRECTIONS[i] + ".png";
            BufferedImage raw = loadImage(resourcePath);
            if (raw != null) {
                frames[i] = scaleNearest(raw, targetSize, targetSize);
            }
            // null stays null — SpriteAnimator draws fallback silhouette
        }

        cache.put(key, frames);
        return frames;
    }

    /** Try classpath (JAR) first, then file system. */
    private static BufferedImage loadImage(String path) {
        // 1. Try as classpath resource (works inside JAR)
        try {
            InputStream is = SpriteLoader.class.getClassLoader().getResourceAsStream(path);
            if (is != null) {
                BufferedImage img = ImageIO.read(is);
                is.close();
                if (img != null) return img;
            }
        } catch (Exception ignored) {}

        // 2. Try as filesystem path (works when running from project dir)
        try {
            File f = new File(path);
            if (f.exists()) return ImageIO.read(f);
        } catch (Exception ignored) {}

        return null;
    }

    /** Load a single background map image — classpath then filesystem. */
    public static BufferedImage loadMap(String filename) {
        String path = "assets/images/maps/maps/" + filename;

        try {
            InputStream is = SpriteLoader.class.getClassLoader().getResourceAsStream(path);
            if (is != null) {
                BufferedImage img = ImageIO.read(is);
                is.close();
                if (img != null) return img;
            }
        } catch (Exception ignored) {}

        try {
            File f = new File(path);
            if (f.exists()) return ImageIO.read(f);
        } catch (Exception ignored) {}

        return null;
    }

    /** Nearest-neighbour scale — keeps pixel art crisp at any zoom */
    public static BufferedImage scaleNearest(BufferedImage src, int w, int h) {
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                           RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
        g.drawImage(src, 0, 0, w, h, null);
        g.dispose();
        return out;
    }
}
