package graphics;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

/**
 * A self-contained animated sprite panel.
 *
 * Animation states
 * ─────────────────
 *  IDLE    – bobs gently in place (south frame), breathing cycle
 *  WALK    – cycles through 4 diagonal frames (SW→S→SE→S) simulating approach
 *  ATTACK  – punches forward (SE) with a fast lunge-and-return
 *  HIT     – flashes red and recoils
 *  VICTORY – spins through all 8 directions
 *  DEFEAT  – slumps (desaturated, tilted)
 *
 * The panel renders at whatever size it is given; the sprite is
 * centred and scaled to fill ~75% of the panel height.
 */
public class SpriteAnimator extends JPanel {

    public enum State { IDLE, WALK, ATTACK, HIT, VICTORY, DEFEAT }

    // ── config ────────────────────────────────────────────────────────────────
    private static final int FRAME_MS_IDLE    = 120;
    private static final int FRAME_MS_WALK    = 90;
    private static final int FRAME_MS_ATTACK  = 60;
    private static final int FRAME_MS_HIT     = 55;
    private static final int FRAME_MS_VICTORY = 80;

    // walk cycle: indices into DIRECTIONS array
    private static final int[] WALK_SEQ    = {0, 1, 0, 7};   // S SE S SW
    // attack: lunge right (east-ish) then back
    private static final int[] ATTACK_SEQ  = {2, 1, 2, 1, 0}; // E SE E SE S
    // hit: recoil west
    private static final int[] HIT_SEQ     = {6, 7, 6, 0};    // W SW W S
    // victory: full spin
    private static final int[] VICTORY_SEQ = {0,1,2,3,4,5,6,7};

    // ── state ─────────────────────────────────────────────────────────────────
    private final String      charName;
    private       BufferedImage[] frames;     // 8 direction frames, may contain nulls
    private final Color           fallbackCol;
    private final boolean         flipped;    // true = red team (mirror)

    private State  state      = State.IDLE;
    private int    frameIdx   = 0;
    private int    tick       = 0;          // ms counter
    private double bobOffset  = 0;
    private double bobAngle   = 0;

    // one-shot animations return to IDLE when done
    private boolean oneShotDone = false;
    private State   pendingState = null;

    // hit flash
    private int hitFlashCount = 0;

    private final Timer animTimer;

    // shadow gradient
    private static final Color SHADOW_COL = new Color(0, 0, 0, 80);

    public SpriteAnimator(String charName, boolean flipped) {
        this.charName    = charName;
        this.flipped     = flipped;
        this.fallbackCol = fallbackColor(charName);

        setOpaque(false);

        // load frames at 128px — will be scaled again at paint time if needed
        frames = SpriteLoader.load(charName, 128);

        // 30 fps timer
        animTimer = new Timer(33, e -> tick());
        animTimer.start();
    }

    // ── public API ────────────────────────────────────────────────────────────

    public void setState(State newState) {
        if (state == State.DEFEAT) return; // defeat is permanent
        if (newState == state) return;
        frameIdx  = 0;
        tick      = 0;
        oneShotDone = false;
        state = newState;
    }

    /** Play a one-shot animation then revert to IDLE (or supplied returnTo state) */
    public void playOnce(State oneShot, State returnTo) {
        pendingState = returnTo;
        setState(oneShot);
    }

    public void stopAnimation() { animTimer.stop(); }

    // ── internal ──────────────────────────────────────────────────────────────

    private void tick() {
        tick += 33;
        int frameMs = frameMs();
        if (tick >= frameMs) {
            tick = 0;
            advanceFrame();
        }
        bobAngle += 0.07;
        bobOffset = Math.sin(bobAngle) * 3.0;
        repaint();
    }

    private int frameMs() {
        switch (state) {
            case WALK:    return FRAME_MS_WALK;
            case ATTACK:  return FRAME_MS_ATTACK;
            case HIT:     return FRAME_MS_HIT;
            case VICTORY: return FRAME_MS_VICTORY;
            default:      return FRAME_MS_IDLE;
        }
    }

    private int[] currentSeq() {
        switch (state) {
            case WALK:    return WALK_SEQ;
            case ATTACK:  return flipped ? mirrorSeq(ATTACK_SEQ) : ATTACK_SEQ;
            case HIT:     return flipped ? mirrorSeq(HIT_SEQ)    : HIT_SEQ;
            case VICTORY: return VICTORY_SEQ;
            default:      return new int[]{0}; // IDLE: south only
        }
    }

    private static int[] mirrorSeq(int[] seq) {
        int[] out = seq.clone();
        // mirror horizontally: direction index mirroring
        // 0=S, 1=SE, 2=E, 3=NE, 4=N, 5=NW, 6=W, 7=SW
        // mirror: E<->W, SE<->SW, NE<->NW
        for (int i = 0; i < out.length; i++) {
            out[i] = mirrorDir(out[i]);
        }
        return out;
    }

    private static int mirrorDir(int d) {
        switch(d) {
            case 1: return 7;  // SE->SW
            case 2: return 6;  // E->W
            case 3: return 5;  // NE->NW
            case 5: return 3;  // NW->NE
            case 6: return 2;  // W->E
            case 7: return 1;  // SW->SE
            default: return d;
        }
    }

    private void advanceFrame() {
        int[] seq = currentSeq();
        frameIdx = (frameIdx + 1) % seq.length;
        // check one-shot completion
        if (frameIdx == 0 && pendingState != null && state != State.IDLE && state != State.DEFEAT) {
            state        = pendingState;
            pendingState = null;
            frameIdx     = 0;
        }
    }

    // ── painting ──────────────────────────────────────────────────────────────

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,    RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,   RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING,       RenderingHints.VALUE_RENDER_QUALITY);

        int pw = getWidth(), ph = getHeight();

        // sprite target size: 75% of panel height, keep square
        int spriteSize = (int)(ph * 0.75);
        int cx = pw / 2;
        int baseY = (int)(ph * 0.88);  // feet land at 88% down

        // shadow ellipse
        int shadowW = (int)(spriteSize * 0.65);
        int shadowH = (int)(spriteSize * 0.14);
        g2.setColor(SHADOW_COL);
        g2.fillOval(cx - shadowW/2, baseY - shadowH/2, shadowW, shadowH);

        // get current frame image
        int[] seq = currentSeq();
        int dirIdx = seq[frameIdx % seq.length];
        BufferedImage frame = (frames != null && dirIdx < frames.length) ? frames[dirIdx] : null;

        // defeat: draw slumped + gray
        float defeatTilt = 0f;
        float defeatAlpha = 1f;
        if (state == State.DEFEAT) {
            defeatTilt  = flipped ? -35f : 35f;
            defeatAlpha = 0.6f;
        }

        // hit flash: alternate red tint
        boolean showHitFlash = (state == State.HIT && (frameIdx % 2 == 0));

        // bob (only during IDLE and WALK)
        double bob = (state == State.IDLE || state == State.WALK) ? bobOffset : 0;

        // scale for attack lunge
        float scaleX = 1f, scaleY = 1f;
        if (state == State.ATTACK) {
            float t = (float) frameIdx / Math.max(1, currentSeq().length - 1);
            float lunge = (float)(Math.sin(t * Math.PI) * 0.18); // +18% size at peak
            scaleX = 1f + lunge;
            scaleY = 1f + lunge * 0.5f;
        }

        // compute draw rect
        int drawW = (int)(spriteSize * scaleX);
        int drawH = (int)(spriteSize * scaleY);
        int drawX = cx - drawW / 2;
        int drawY = (int)(baseY - spriteSize + bob);

        // apply defeat tilt
        AffineTransform saved = g2.getTransform();
        if (defeatTilt != 0) {
            g2.rotate(Math.toRadians(defeatTilt), cx, baseY);
        }
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, defeatAlpha));

        if (frame != null) {
            // flip horizontally for red team (mirror)
            if (flipped) {
                g2.drawImage(frame, drawX + drawW, drawY, -drawW, drawH, null);
            } else {
                g2.drawImage(frame, drawX, drawY, drawW, drawH, null);
            }
            // hit flash overlay
            if (showHitFlash) {
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
                g2.setColor(new Color(255, 30, 30));
                g2.fillRect(drawX, drawY, drawW, drawH);
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, defeatAlpha));
            }
            // defeat grayscale — draw desaturated overlay
            if (state == State.DEFEAT) {
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
                g2.setColor(Color.DARK_GRAY);
                g2.fillRect(drawX, drawY, drawW, drawH);
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
            }
        } else {
            // fallback: draw a Java2D placeholder silhouette
            drawFallback(g2, drawX, drawY, drawW, drawH, dirIdx);
        }

        g2.setTransform(saved);
        g2.dispose();
    }

    /** Drawn when sprite PNG is missing — coloured silhouette */
    private void drawFallback(Graphics2D g2, int x, int y, int w, int h, int dir) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        // body
        g2.setColor(fallbackCol);
        int hw = w / 2;
        // head
        g2.fillOval(x + hw/2, y + h/10, hw, (int)(h*0.28));
        // torso
        g2.fillRoundRect(x + hw/2 - 4, y + (int)(h*0.36), hw + 8, (int)(h*0.36), 6, 6);
        // left arm
        g2.fillRoundRect(x + hw/2 - 12, y + (int)(h*0.36), 10, (int)(h*0.30), 4, 4);
        // right arm
        g2.fillRoundRect(x + hw + hw/2 + 2, y + (int)(h*0.36), 10, (int)(h*0.30), 4, 4);
        // legs
        g2.fillRoundRect(x + hw/2 + 2, y + (int)(h*0.70), 10, (int)(h*0.28), 4, 4);
        g2.fillRoundRect(x + hw/2 + hw - 12, y + (int)(h*0.70), 10, (int)(h*0.28), 4, 4);
        // direction indicator dot
        g2.setColor(Color.WHITE);
        int dotSize = Math.max(4, w / 10);
        double angle = dir * Math.PI / 4.0;
        int dotX = x + w/2 + (int)(Math.cos(angle) * w * 0.25) - dotSize/2;
        int dotY = y + h/2 + (int)(Math.sin(angle) * h * 0.20) - dotSize/2;
        g2.fillOval(dotX, dotY, dotSize, dotSize);
    }

    private static Color fallbackColor(String name) {
        switch (name) {
            case "Iron Man":       return new Color(180, 30, 20);
            case "Spider-Man":     return new Color(180, 20, 20);
            case "Thor":           return new Color(80, 100, 200);
            case "Hulk":           return new Color(40, 160, 40);
            case "Black Widow":    return new Color(30, 30, 60);
            case "Scarlet Witch":  return new Color(180, 20, 60);
            case "Doctor Strange": return new Color(20, 30, 160);
            case "Cadie":          return new Color(200, 120, 50);
            case "Loki":           return new Color(30, 100, 40);
            case "Ultron":         return new Color(80, 80, 100);
            default:               return new Color(100, 100, 140);
        }
    }
}
