package graphics;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Renders arena backgrounds.
 * Uses real JPG map assets (loaded via classpath so it works inside a JAR).
 *   asgard.jpg       → Thor / Loki
 *   stark_tower.jpg  → Iron Man
 *   wakanda.jpg      → Hulk / Gamma Lab
 * All other arenas fall back to Java2D painting.
 */
public class BackgroundRenderer {

    public enum Arena {
        STARK_TOWER,
        NEW_YORK_CITY,
        ASGARD,
        GAMMA_LAB,
        SHIELD_HELICARRIER,
        SCARLET_DIMENSION,
        SANCTUM_SANCTORUM,
        SPACE_NEBULA,
        ULTRON_FACTORY,
        DEFAULT_ARENA
    }

    // cache so each map is decoded only once
    private static final Map<String, BufferedImage> mapCache = new HashMap<>();

    private static BufferedImage loadMap(String filename) {
        if (mapCache.containsKey(filename)) return mapCache.get(filename);
        BufferedImage img = SpriteLoader.loadMap(filename);
        mapCache.put(filename, img); // store even if null to avoid retrying
        return img;
    }

    public static Arena arenaFor(String charName) {
        switch (charName) {
            case "Iron Man":          return Arena.STARK_TOWER;
            case "Spider-Man":        return Arena.NEW_YORK_CITY;
            case "Thor": case "Loki": return Arena.ASGARD;
            case "Hulk":              return Arena.GAMMA_LAB;
            case "Black Widow":       return Arena.SHIELD_HELICARRIER;
            case "Scarlet Witch":     return Arena.SCARLET_DIMENSION;
            case "Doctor Strange":    return Arena.SANCTUM_SANCTORUM;
            case "Cadie":             return Arena.SPACE_NEBULA;
            case "Ultron":            return Arena.ULTRON_FACTORY;
            default:                  return Arena.DEFAULT_ARENA;
        }
    }

    public static void paint(Graphics2D g, int w, int h, Arena arena) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,  RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.setRenderingHint(RenderingHints.KEY_RENDERING,     RenderingHints.VALUE_RENDER_QUALITY);

        switch (arena) {
            case STARK_TOWER:
                paintWithMap(g, w, h, "stark_tower.jpg",
                    new Color(5,8,20), new Color(80,150,255,60)); break;
            case ASGARD:
                paintWithMap(g, w, h, "asgard.jpg",
                    new Color(15,20,60), new Color(255,220,50,50)); break;
            case GAMMA_LAB:
                paintWithMap(g, w, h, "wakanda.jpg",
                    new Color(8,15,8), new Color(0,200,0,40)); break;
            case NEW_YORK_CITY:      paintNewYork(g,w,h);     break;
            case SHIELD_HELICARRIER: paintHelicarrier(g,w,h); break;
            case SCARLET_DIMENSION:  paintScarlet(g,w,h);     break;
            case SANCTUM_SANCTORUM:  paintSanctum(g,w,h);     break;
            case SPACE_NEBULA:       paintNebula(g,w,h);      break;
            case ULTRON_FACTORY:     paintUltron(g,w,h);      break;
            default:                 paintDefault(g,w,h);     break;
        }
    }

    // ── Real-map painter ──────────────────────────────────────────────────────
    private static void paintWithMap(Graphics2D g, int w, int h,
                                     String file, Color fallback, Color floorGlow) {
        BufferedImage map = loadMap(file);
        if (map != null) {
            g.drawImage(map, 0, 0, w, h, null);
            // readability vignette – stronger at very top, lighter in middle
            GradientPaint vignette = new GradientPaint(
                    0, 0,         new Color(0,0,0,110),
                    0, h * 0.5f,  new Color(0,0,0,20));
            g.setPaint(vignette); g.fillRect(0, 0, w, h);
            // floor glow strip
            GradientPaint floor = new GradientPaint(
                    0, h-90, floorGlow, 0, h, new Color(0,0,0,0));
            g.setPaint(floor); g.fillRect(0, h-90, w, 90);
        } else {
            // fallback if asset missing
            g.setColor(fallback); g.fillRect(0, 0, w, h);
            paintDefault(g, w, h);
        }
    }

    // ── Java2D fallback arenas ────────────────────────────────────────────────
    private static void paintNewYork(Graphics2D g, int w, int h) {
        g.setPaint(new GradientPaint(0,0,new Color(10,20,60),0,h,new Color(30,40,80)));
        g.fillRect(0,0,w,h);
        g.setColor(new Color(230,230,200)); g.fillOval(w-120,30,60,60);
        Random r = new Random(99);
        g.setColor(new Color(15,18,35));
        int[][] blds = {{0,h-150,80,150},{60,h-200,90,200},{130,h-160,70,160},
                {180,h-240,80,240},{240,h-180,90,180},{310,h-220,70,220},
                {360,h-190,85,190},{420,h-260,75,260},{470,h-200,90,200},
                {530,h-170,80,170},{590,h-230,95,230},{660,h-200,85,200},
                {720,h-150,80,150},{790,h-210,90,210},{860,h-180,80,180},
                {920,h-240,90,240},{980,h-170,80,170}};
        for (int[] b : blds) g.fillRect(b[0],b[1],b[2],b[3]);
        g.setColor(new Color(255,230,100,100));
        for (int[] b : blds)
            for (int row=2; row<b[3]/20; row++)
                for (int col=1; col<b[2]/14; col++)
                    if (r.nextBoolean()) g.fillRect(b[0]+col*12, b[1]+row*18, 8, 11);
        g.setPaint(new GradientPaint(0,h-40,new Color(255,180,50,50),0,h,new Color(0,0,0,0)));
        g.fillRect(0,h-40,w,40);
    }

    private static void paintHelicarrier(Graphics2D g, int w, int h) {
        g.setPaint(new GradientPaint(0,0,new Color(100,130,180),0,(int)(h*.65),new Color(60,90,140)));
        g.fillRect(0,0,w,h);
        g.setColor(new Color(200,210,230,160));
        for (int i=0;i<8;i++) g.fillOval(i*140-30,20+i%3*40,160,50);
        g.setPaint(new GradientPaint(0,(int)(h*.65),new Color(20,60,120),0,h,new Color(10,30,80)));
        g.fillRect(0,(int)(h*.65),w,(int)(h*.35));
        g.setColor(new Color(60,65,70));
        g.fillRoundRect(w/2-320,h/2-30,640,80,12,12);
        g.setColor(new Color(200,200,220));
        g.setFont(new Font("Arial",Font.BOLD,14));
        FontMetrics fm = g.getFontMetrics();
        String txt = "S.H.I.E.L.D";
        g.drawString(txt, w/2 - fm.stringWidth(txt)/2, h/2-10);
        g.setPaint(new GradientPaint(0,h-50,new Color(100,180,255,40),0,h,new Color(0,0,0,0)));
        g.fillRect(0,h-50,w,50);
    }

    private static void paintScarlet(Graphics2D g, int w, int h) {
        g.setPaint(new GradientPaint(0,0,new Color(60,5,20),w,h,new Color(20,5,40)));
        g.fillRect(0,0,w,h);
        g.setColor(new Color(200,30,80,25)); g.setStroke(new BasicStroke(1f));
        for (int row=0; row<h/30; row++)
            for (int col=0; col<w/26; col++) {
                int hx=col*26+(row%2)*13, hy=row*23;
                int[] xs={hx+13,hx+26,hx+26,hx+13,hx,hx};
                int[] ys={hy,hy+7,hy+16,hy+23,hy+16,hy+7};
                g.drawPolygon(xs,ys,6);
            }
        g.setStroke(new BasicStroke(2f));
        for (int i=0;i<8;i++) {
            g.setColor(new Color(220,50,100,80+i*10));
            g.drawArc(w/2-50-i*25,h/2-50-i*25,100+i*50,100+i*50,i*30,200);
        }
        glow(g, w/2, h/2, h*0.4f, new Color(255,30,80,60));
    }

    private static void paintSanctum(Graphics2D g, int w, int h) {
        g.setPaint(new GradientPaint(0,0,new Color(8,8,30),0,h,new Color(20,10,50)));
        g.fillRect(0,0,w,h);
        for (int i=8; i>=1; i--) {
            g.setColor(new Color(80+i*15,50+i*10,200+i*5,20*i));
            g.setStroke(new BasicStroke(3f));
            g.drawOval(w/2-i*50,h/2-i*40,i*100,i*80);
        }
        glow(g, w/2, h/2, 120, new Color(255,160,30,80));
        g.setColor(new Color(40,25,15)); g.fillRect(0,h-120,w,120);
        Random r = new Random(33);
        for (int i=0; i<w; i+=18) {
            g.setColor(new Color(80+r.nextInt(60),40+r.nextInt(40),20+r.nextInt(30)));
            g.fillRect(i, h-110+r.nextInt(20), 14, 90+r.nextInt(20));
        }
    }

    private static void paintNebula(Graphics2D g, int w, int h) {
        g.setColor(new Color(2,2,12)); g.fillRect(0,0,w,h);
        Color[] nc = {new Color(80,20,120,60),new Color(20,60,140,50),
                      new Color(140,50,20,50),new Color(20,120,80,40)};
        for (int i=0;i<4;i++) glow(g, w/4+i*(w/4), h/3+i*(h/6), w*0.35f, nc[i]);
        Random r = new Random(11);
        for (int i=0;i<300;i++) {
            int sx=r.nextInt(w),sy=r.nextInt(h),ss=r.nextInt(3);
            g.setColor(new Color(255,255,255,100+r.nextInt(155)));
            g.fillOval(sx,sy,ss+1,ss+1);
        }
        g.setPaint(new GradientPaint(0,(int)(h*.75),new Color(20,20,35,200),0,h,new Color(10,10,20,255)));
        g.fillRect(0,(int)(h*.75),w,(int)(h*.25));
    }

    private static void paintUltron(Graphics2D g, int w, int h) {
        g.setColor(new Color(8,8,12)); g.fillRect(0,0,w,h);
        glow(g, w/2, h/2, w*0.5f, new Color(200,50,0,40));
        g.setColor(new Color(25,25,32)); g.fillRect(0,h-80,w,80);
        g.setColor(new Color(38,38,48));
        for (int i=0;i<w;i+=40) g.fillRect(i,h-80,2,80);
        for (int i=h-80;i<h;i+=20) g.fillRect(0,i,w,2);
        for (int i=0;i<5;i++) {
            int vx=100+i*200;
            glow(g, vx, h-80, 30, new Color(220,80,0,120));
            g.setColor(new Color(255,100,0,180)); g.fillRect(vx-10,h-100,20,20);
        }
        glow(g, w/2, 100, 50, new Color(255,80,0,120));
        g.setColor(new Color(255,80,0,200));
        g.setFont(new Font("Impact",Font.BOLD,28));
        FontMetrics fm = g.getFontMetrics();
        g.drawString("ULTRON ARENA", w/2 - fm.stringWidth("ULTRON ARENA")/2, 110);
    }

    private static void paintDefault(Graphics2D g, int w, int h) {
        g.setPaint(new GradientPaint(0,0,new Color(5,5,20),0,h,new Color(15,10,35)));
        g.fillRect(0,0,w,h);
        g.setColor(new Color(40,40,80,50));
        for (int i=0;i<w;i+=50) g.drawLine(i,0,i,h);
        for (int i=0;i<h;i+=50) g.drawLine(0,i,w,i);
        glow(g, w/2, h/2, w*0.4f, new Color(80,60,200,50));
        g.setPaint(new GradientPaint(0,h-60,new Color(100,80,255,50),0,h,new Color(0,0,0,0)));
        g.fillRect(0,h-60,w,60);
    }

    private static void glow(Graphics2D g, float cx, float cy, float r, Color c) {
        if (r <= 0) return;
        Paint old = g.getPaint();
        RadialGradientPaint rp = new RadialGradientPaint(cx, cy, r,
                new float[]{0f,1f},
                new Color[]{c, new Color(c.getRed(),c.getGreen(),c.getBlue(),0)});
        g.setPaint(rp);
        g.fillOval((int)(cx-r),(int)(cy-r),(int)(r*2),(int)(r*2));
        g.setPaint(old);
    }
}
