package graphics;

import javax.sound.sampled.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Synthesizes sound effects entirely in Java — no external audio files needed.
 * Uses javax.sound.sampled with PCM wave generation.
 */
public class SoundEngine {

    private static final ExecutorService pool = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "SoundEngine");
        t.setDaemon(true);
        return t;
    });

    private static boolean enabled = true;

    public static void setEnabled(boolean en) { enabled = en; }
    public static boolean isEnabled() { return enabled; }

    public enum SFX {
        ATTACK, HEAVY_ATTACK, HEAL, BUFF, STUN, VICTORY, DEFEAT, SELECT, MENU_CLICK, MAGIC
    }

    public static void play(SFX sfx) {
        if (!enabled) return;
        pool.submit(() -> {
            try {
                byte[] data = generate(sfx);
                AudioFormat fmt = new AudioFormat(44100, 16, 1, true, false);
                DataLine.Info info = new DataLine.Info(SourceDataLine.class, fmt);
                if (!AudioSystem.isLineSupported(info)) return;
                SourceDataLine line = (SourceDataLine) AudioSystem.getLine(info);
                line.open(fmt, data.length);
                line.start();
                line.write(data, 0, data.length);
                line.drain();
                line.close();
            } catch (Exception ignored) {}
        });
    }

    private static byte[] generate(SFX sfx) {
        int sampleRate = 44100;
        switch (sfx) {
            case ATTACK:        return punch(sampleRate);
            case HEAVY_ATTACK:  return heavyPunch(sampleRate);
            case HEAL:          return healChime(sampleRate);
            case BUFF:          return buffSound(sampleRate);
            case STUN:          return stunSound(sampleRate);
            case VICTORY:       return victoryFanfare(sampleRate);
            case DEFEAT:        return defeatSound(sampleRate);
            case SELECT:        return selectClick(sampleRate);
            case MENU_CLICK:    return menuClick(sampleRate);
            case MAGIC:         return magicSound(sampleRate);
            default:            return punch(sampleRate);
        }
    }

    // ── short impact "whump" ──
    private static byte[] punch(int sr) {
        int len = sr / 8; // 125ms
        byte[] buf = new byte[len * 2];
        for (int i = 0; i < len; i++) {
            double t = (double) i / sr;
            double freq = 200 - 150 * t * 8;
            double amp = 0.8 * Math.exp(-t * 20);
            double noise = (Math.random() - 0.5) * 0.3 * amp;
            short s = (short)((Math.sin(2 * Math.PI * freq * t) * amp + noise) * 32767);
            buf[i*2]   = (byte)(s & 0xFF);
            buf[i*2+1] = (byte)((s >> 8) & 0xFF);
        }
        return buf;
    }

    // ── deeper impact ──
    private static byte[] heavyPunch(int sr) {
        int len = sr / 5;
        byte[] buf = new byte[len * 2];
        for (int i = 0; i < len; i++) {
            double t = (double) i / sr;
            double freq = 80 - 60 * t * 5;
            double amp = 0.9 * Math.exp(-t * 12);
            double noise = (Math.random() - 0.5) * 0.5 * amp;
            short s = (short)((Math.sin(2 * Math.PI * freq * t) * amp + noise) * 32767);
            buf[i*2]   = (byte)(s & 0xFF);
            buf[i*2+1] = (byte)((s >> 8) & 0xFF);
        }
        return buf;
    }

    // ── rising chime for heal ──
    private static byte[] healChime(int sr) {
        int len = sr / 3;
        byte[] buf = new byte[len * 2];
        double[] freqs = {523.25, 659.25, 783.99, 1046.5};
        for (int i = 0; i < len; i++) {
            double t = (double) i / sr;
            double amp = 0.5 * (1 - Math.exp(-t * 30)) * Math.exp(-t * 5);
            double wave = 0;
            for (double f : freqs) wave += Math.sin(2 * Math.PI * f * t);
            wave /= freqs.length;
            short s = (short)(wave * amp * 32767);
            buf[i*2]   = (byte)(s & 0xFF);
            buf[i*2+1] = (byte)((s >> 8) & 0xFF);
        }
        return buf;
    }

    // ── power-up sweep ──
    private static byte[] buffSound(int sr) {
        int len = sr / 4;
        byte[] buf = new byte[len * 2];
        for (int i = 0; i < len; i++) {
            double t = (double) i / sr;
            double freq = 300 + 600 * t * 4;
            double amp = 0.5 * Math.sin(Math.PI * t * 4);
            short s = (short)(Math.sin(2 * Math.PI * freq * t) * amp * 32767);
            buf[i*2]   = (byte)(s & 0xFF);
            buf[i*2+1] = (byte)((s >> 8) & 0xFF);
        }
        return buf;
    }

    // ── electric crackle for stun ──
    private static byte[] stunSound(int sr) {
        int len = sr / 6;
        byte[] buf = new byte[len * 2];
        for (int i = 0; i < len; i++) {
            double t = (double) i / sr;
            double amp = 0.7 * Math.exp(-t * 15);
            double noise = (Math.random() - 0.5) * 2 * amp;
            double buzz = Math.sin(2 * Math.PI * 120 * t) * amp * 0.3;
            short s = (short)((noise + buzz) * 32767);
            buf[i*2]   = (byte)(s & 0xFF);
            buf[i*2+1] = (byte)((s >> 8) & 0xFF);
        }
        return buf;
    }

    // ── victory fanfare ──
    private static byte[] victoryFanfare(int sr) {
        double[] notes = {523.25, 659.25, 783.99, 1046.5, 1318.5};
        int noteDur = sr / 6;
        int len = notes.length * noteDur;
        byte[] buf = new byte[len * 2];
        for (int n = 0; n < notes.length; n++) {
            for (int i = 0; i < noteDur; i++) {
                double t = (double) i / sr;
                double amp = 0.6 * (1 - (double)i / noteDur * 0.5);
                short s = (short)(Math.sin(2 * Math.PI * notes[n] * t) * amp * 32767);
                int pos = (n * noteDur + i) * 2;
                buf[pos]   = (byte)(s & 0xFF);
                buf[pos+1] = (byte)((s >> 8) & 0xFF);
            }
        }
        return buf;
    }

    // ── descending tone for defeat ──
    private static byte[] defeatSound(int sr) {
        int len = sr / 2;
        byte[] buf = new byte[len * 2];
        for (int i = 0; i < len; i++) {
            double t = (double) i / sr;
            double freq = 400 - 300 * t * 2;
            double amp = 0.5 * Math.exp(-t * 3);
            short s = (short)(Math.sin(2 * Math.PI * freq * t) * amp * 32767);
            buf[i*2]   = (byte)(s & 0xFF);
            buf[i*2+1] = (byte)((s >> 8) & 0xFF);
        }
        return buf;
    }

    // ── soft click ──
    private static byte[] selectClick(int sr) {
        int len = sr / 20;
        byte[] buf = new byte[len * 2];
        for (int i = 0; i < len; i++) {
            double t = (double) i / sr;
            double amp = 0.4 * Math.exp(-t * 80);
            short s = (short)(Math.sin(2 * Math.PI * 800 * t) * amp * 32767);
            buf[i*2]   = (byte)(s & 0xFF);
            buf[i*2+1] = (byte)((s >> 8) & 0xFF);
        }
        return buf;
    }

    // ── menu button click ──
    private static byte[] menuClick(int sr) {
        int len = sr / 15;
        byte[] buf = new byte[len * 2];
        for (int i = 0; i < len; i++) {
            double t = (double) i / sr;
            double amp = 0.5 * Math.exp(-t * 60);
            short s = (short)(Math.sin(2 * Math.PI * 1200 * t) * amp * 32767);
            buf[i*2]   = (byte)(s & 0xFF);
            buf[i*2+1] = (byte)((s >> 8) & 0xFF);
        }
        return buf;
    }

    // ── whooshing magic sound ──
    private static byte[] magicSound(int sr) {
        int len = sr / 4;
        byte[] buf = new byte[len * 2];
        for (int i = 0; i < len; i++) {
            double t = (double) i / sr;
            double freq = 600 + 400 * Math.sin(t * 20);
            double amp = 0.4 * Math.sin(Math.PI * t * 4) * Math.exp(-t * 4);
            double noise = (Math.random() - 0.5) * 0.15 * amp;
            short s = (short)((Math.sin(2 * Math.PI * freq * t) * amp + noise) * 32767);
            buf[i*2]   = (byte)(s & 0xFF);
            buf[i*2+1] = (byte)((s >> 8) & 0xFF);
        }
        return buf;
    }
}
