package graphics;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;

/**
 * Draws stylised character portraits entirely with Java2D — no external images needed.
 * Each portrait is 200×260 px and shows a distinctive silhouette/costume for each character.
 */
public class CharacterPortraitRenderer {

    public static BufferedImage render(String characterName, int w, int h) {
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,  RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING,     RenderingHints.VALUE_RENDER_QUALITY);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL,RenderingHints.VALUE_STROKE_PURE);

        switch (characterName) {
            case "Iron Man":      drawIronMan(g, w, h);      break;
            case "Spider-Man":    drawSpiderMan(g, w, h);    break;
            case "Thor":          drawThor(g, w, h);         break;
            case "Hulk":          drawHulk(g, w, h);         break;
            case "Black Widow":   drawBlackWidow(g, w, h);   break;
            case "Scarlet Witch": drawScarletWitch(g, w, h); break;
            case "Doctor Strange":drawDoctorStrange(g, w, h);break;
            case "Cadie":         drawCadie(g, w, h);        break;
            case "Loki":          drawLoki(g, w, h);         break;
            case "Ultron":        drawUltron(g, w, h);       break;
            default:              drawGeneric(g, w, h, characterName); break;
        }
        g.dispose();
        return img;
    }

    // ─── shared helpers ───────────────────────────────────────────────────────

    private static void bg(Graphics2D g, int w, int h, Color top, Color bot) {
        g.setPaint(new GradientPaint(0, 0, top, 0, h, bot));
        g.fillRoundRect(0, 0, w, h, 18, 18);
    }

    private static void glow(Graphics2D g, float cx, float cy, float r, Color c) {
        RadialGradientPaint rp = new RadialGradientPaint(cx, cy, r,
                new float[]{0f, 1f}, new Color[]{c, new Color(c.getRed(), c.getGreen(), c.getBlue(), 0)});
        g.setPaint(rp);
        g.fillOval((int)(cx-r),(int)(cy-r),(int)(r*2),(int)(r*2));
    }

    private static void outline(Graphics2D g, Shape s, Color c, float stroke) {
        g.setColor(c); g.setStroke(new BasicStroke(stroke)); g.draw(s);
    }

    // ─── IRON MAN ─────────────────────────────────────────────────────────────
    private static void drawIronMan(Graphics2D g, int w, int h) {
        bg(g, w, h, new Color(60,10,10), new Color(20,5,5));
        // glow
        glow(g, w/2f, h*0.4f, w*0.55f, new Color(255,80,0,90));
        // chest/torso
        g.setColor(new Color(180,20,20));
        g.fillRoundRect(w/2-28, h/2-20, 56, 70, 10, 10);
        // shoulders
        g.setColor(new Color(200,30,20));
        g.fillOval(w/2-52, h/2-28, 32, 28);
        g.fillOval(w/2+20, h/2-28, 32, 28);
        // arms
        g.setColor(new Color(160,20,20));
        g.fillRoundRect(w/2-50, h/2, 18, 55, 6, 6);
        g.fillRoundRect(w/2+32, h/2, 18, 55, 6, 6);
        // legs
        g.fillRoundRect(w/2-24, h/2+48, 20, 55, 6, 6);
        g.fillRoundRect(w/2+4, h/2+48, 20, 55, 6, 6);
        // arc reactor
        glow(g, w/2f, h/2f+10, 20, new Color(80,200,255,180));
        g.setColor(new Color(120,230,255));
        g.fillOval(w/2-10, h/2, 20, 20);
        g.setColor(Color.WHITE);
        g.fillOval(w/2-5, h/2+5, 10, 10);
        // helmet
        g.setColor(new Color(200,25,25));
        g.fillOval(w/2-24, h/2-72, 48, 52);
        // eyes
        g.setColor(new Color(120,230,255));
        g.fillRoundRect(w/2-18, h/2-54, 13, 7, 4, 4);
        g.fillRoundRect(w/2+5,  h/2-54, 13, 7, 4, 4);
        // gold trim
        g.setColor(new Color(255,200,0));
        g.setStroke(new BasicStroke(2.5f));
        g.drawRoundRect(w/2-28, h/2-20, 56, 70, 10, 10);
        g.drawOval(w/2-24, h/2-72, 48, 52);
        // name
        drawName(g, "IRON MAN", w, h, new Color(255,150,50));
    }

    // ─── SPIDER-MAN ───────────────────────────────────────────────────────────
    private static void drawSpiderMan(Graphics2D g, int w, int h) {
        bg(g, w, h, new Color(10,10,60), new Color(5,5,25));
        glow(g, w/2f, h*0.4f, w*0.5f, new Color(200,0,0,80));
        // body
        g.setColor(new Color(190,15,15));
        g.fillRoundRect(w/2-26, h/2-18, 52, 66, 8, 8);
        // arms
        g.fillRoundRect(w/2-50, h/2-10, 26, 48, 6, 6);
        g.fillRoundRect(w/2+24, h/2-10, 26, 48, 6, 6);
        // legs
        g.fillRoundRect(w/2-22, h/2+46, 18, 58, 6, 6);
        g.fillRoundRect(w/2+4,  h/2+46, 18, 58, 6, 6);
        // blue costume parts
        g.setColor(new Color(0,50,200));
        g.fillRoundRect(w/2-24, h/2+10, 48, 38, 4, 4);
        g.fillRoundRect(w/2-50, h/2, 16, 30, 4, 4);
        g.fillRoundRect(w/2+34, h/2, 16, 30, 4, 4);
        // head
        g.setColor(new Color(190,15,15));
        g.fillOval(w/2-22, h/2-68, 44, 50);
        // eyes
        g.setColor(Color.WHITE);
        g.fillOval(w/2-15, h/2-56, 13, 14);
        g.fillOval(w/2+2,  h/2-56, 13, 14);
        g.setColor(new Color(0,50,180));
        g.fillOval(w/2-13, h/2-54, 9, 10);
        g.fillOval(w/2+4,  h/2-54, 9, 10);
        // web lines
        g.setColor(new Color(0,0,0,100));
        g.setStroke(new BasicStroke(1.2f));
        for (int i=-3;i<=3;i++) g.drawLine(w/2+i*8, h/2-68, w/2, h/2-44);
        // web shooter
        g.setColor(Color.WHITE); g.setStroke(new BasicStroke(1.5f));
        g.drawLine(w/2-46, h/2+38, w/2-120, h/2-30);
        drawName(g, "SPIDER-MAN", w, h, new Color(255,80,80));
    }

    // ─── THOR ─────────────────────────────────────────────────────────────────
    private static void drawThor(Graphics2D g, int w, int h) {
        bg(g, w, h, new Color(10,20,60), new Color(5,10,30));
        glow(g, w/2f, h/2f, w*0.6f, new Color(100,150,255,100));
        // cape
        g.setColor(new Color(180,10,10));
        int[] cx={w/2-28,w/2+28,w/2+50,w/2-50};
        int[] cy={h/2-18,h/2-18,h-20,h-20};
        g.fillPolygon(cx,cy,4);
        // body
        g.setColor(new Color(80,100,160));
        g.fillRoundRect(w/2-28,h/2-20,56,70,8,8);
        // circle armor
        g.setColor(new Color(190,170,100));
        g.setStroke(new BasicStroke(3));
        g.drawOval(w/2-15,h/2-10,30,30);
        // arms
        g.setColor(new Color(80,100,160));
        g.fillRoundRect(w/2-52,h/2-14,26,55,6,6);
        g.fillRoundRect(w/2+26,h/2-14,26,55,6,6);
        // legs
        g.setColor(new Color(50,60,110));
        g.fillRoundRect(w/2-24,h/2+48,20,55,6,6);
        g.fillRoundRect(w/2+4,h/2+48,20,55,6,6);
        // head + helmet
        g.setColor(new Color(220,185,140));
        g.fillOval(w/2-20,h/2-70,40,46);
        g.setColor(new Color(140,140,160));
        g.fillRoundRect(w/2-22,h/2-74,44,24,8,8);
        // wings on helmet
        g.setColor(Color.WHITE);
        int[] wx1={w/2-22,w/2-38,w/2-22}; int[] wy1={h/2-68,h/2-80,h/2-56};
        int[] wx2={w/2+22,w/2+38,w/2+22}; int[] wy2={h/2-68,h/2-80,h/2-56};
        g.fillPolygon(wx1,wy1,3); g.fillPolygon(wx2,wy2,3);
        // Mjolnir
        g.setColor(new Color(140,140,160));
        g.fillRoundRect(w/2+42,h/2+20,24,18,4,4);
        g.setColor(new Color(100,80,60));
        g.fillRect(w/2+51,h/2+38,6,26);
        // lightning
        g.setColor(new Color(180,220,255,180));
        g.setStroke(new BasicStroke(2f));
        g.drawLine(w/2+54,h-60,w/2+80,h-90);
        g.drawLine(w/2+80,h-90,w/2+65,h-100);
        g.drawLine(w/2+65,h-100,w/2+88,h-125);
        drawName(g,"THOR",w,h,new Color(150,180,255));
    }

    // ─── HULK ─────────────────────────────────────────────────────────────────
    private static void drawHulk(Graphics2D g, int w, int h) {
        bg(g, w, h, new Color(10,40,10), new Color(5,20,5));
        glow(g,w/2f,h/2f,w*0.65f,new Color(50,180,50,110));
        // huge body
        g.setColor(new Color(40,160,40));
        g.fillRoundRect(w/2-42,h/2-10,84,80,12,12);
        // massive arms
        g.fillRoundRect(w/2-88,h/2-14,52,65,10,10);
        g.fillRoundRect(w/2+36,h/2-14,52,65,10,10);
        // fists
        g.setColor(new Color(30,140,30));
        g.fillOval(w/2-92,h/2+42,30,28);
        g.fillOval(w/2+62,h/2+42,30,28);
        // legs
        g.setColor(new Color(70,50,130));
        g.fillRoundRect(w/2-38,h/2+68,34,55,8,8);
        g.fillRoundRect(w/2+4,h/2+68,34,55,8,8);
        // neck
        g.setColor(new Color(40,160,40));
        g.fillRect(w/2-16,h/2-34,32,24);
        // head
        g.fillOval(w/2-32,h/2-82,64,58);
        // brow
        g.setColor(new Color(30,130,30));
        g.fillRect(w/2-28,h/2-72,56,14);
        // eyes
        g.setColor(new Color(10,70,10));
        g.fillOval(w/2-18,h/2-62,14,10);
        g.fillOval(w/2+4,h/2-62,14,10);
        g.setColor(new Color(200,255,50));
        g.fillOval(w/2-15,h/2-60,8,6);
        g.fillOval(w/2+7,h/2-60,8,6);
        // torn pants detail
        g.setColor(new Color(80,60,140));
        g.setStroke(new BasicStroke(2));
        g.drawLine(w/2-38,h/2+68,w/2-30,h/2+90);
        g.drawLine(w/2+38,h/2+68,w/2+30,h/2+90);
        drawName(g,"HULK",w,h,new Color(80,255,80));
    }

    // ─── BLACK WIDOW ──────────────────────────────────────────────────────────
    private static void drawBlackWidow(Graphics2D g, int w, int h) {
        bg(g,w,h,new Color(10,10,10),new Color(5,5,20));
        glow(g,w/2f,h/2f,w*0.45f,new Color(180,0,0,80));
        // bodysuit
        g.setColor(new Color(20,20,25));
        g.fillRoundRect(w/2-22,h/2-22,44,70,8,8);
        g.fillRoundRect(w/2-44,h/2-15,24,52,6,6);
        g.fillRoundRect(w/2+20,h/2-15,24,52,6,6);
        g.fillRoundRect(w/2-20,h/2+46,16,58,6,6);
        g.fillRoundRect(w/2+4,h/2+46,16,58,6,6);
        // belt
        g.setColor(new Color(150,120,0));
        g.fillRect(w/2-22,h/2+22,44,10);
        // hourglass emblem
        g.setColor(new Color(220,20,20));
        int[] hx={w/2-7,w/2+7,w/2+3,w/2+7,w/2-7,w/2-3};
        int[] hy={h/2-5,h/2-5,h/2,h/2+5,h/2+5,h/2};
        g.fillPolygon(hx,hy,6);
        // head + hair
        g.setColor(new Color(220,175,130));
        g.fillOval(w/2-18,h/2-70,36,42);
        g.setColor(new Color(180,30,30));
        g.fillArc(w/2-20,h/2-74,40,30,0,180);
        // eyes
        g.setColor(new Color(40,30,20));
        g.fillOval(w/2-11,h/2-54,9,7);
        g.fillOval(w/2+2,h/2-54,9,7);
        // widow bites
        g.setColor(new Color(150,150,200));
        g.fillRoundRect(w/2-44,h/2+14,8,6,2,2);
        g.fillRoundRect(w/2+36,h/2+14,8,6,2,2);
        drawName(g,"BLACK WIDOW",w,h,new Color(200,50,50));
    }

    // ─── SCARLET WITCH ────────────────────────────────────────────────────────
    private static void drawScarletWitch(Graphics2D g, int w, int h) {
        bg(g,w,h,new Color(40,5,5),new Color(20,5,30));
        glow(g,w/2f,h/2f-20,w*0.5f,new Color(200,30,80,120));
        // chaos magic aura particles
        for(int i=0;i<12;i++){
            double angle=Math.PI*2*i/12;
            int px=(int)(w/2+Math.cos(angle)*55);
            int py=(int)(h/2-20+Math.sin(angle)*55);
            g.setColor(new Color(220,40,80,(int)(80+Math.random()*80)));
            g.fillOval(px-4,py-4,8,8);
        }
        // dress/body
        g.setColor(new Color(150,10,20));
        int[] bx={w/2-24,w/2+24,w/2+36,w/2-36};
        int[] by={h/2-18,h/2-18,h-15,h-15};
        g.fillPolygon(bx,by,4);
        // top
        g.setColor(new Color(180,15,25));
        g.fillRoundRect(w/2-22,h/2-22,44,50,8,8);
        // arms with hex glow
        g.fillRoundRect(w/2-46,h/2-15,26,45,6,6);
        g.fillRoundRect(w/2+20,h/2-15,26,45,6,6);
        // magic hands
        g.setColor(new Color(255,80,80,180));
        g.fillOval(w/2-46,h/2+28,22,22);
        g.fillOval(w/2+24,h/2+28,22,22);
        glow(g,w/2-35,h/2+39,18,new Color(255,50,50,200));
        glow(g,w/2+35,h/2+39,18,new Color(255,50,50,200));
        // neck+head
        g.setColor(new Color(220,175,130));
        g.fillRect(w/2-10,h/2-36,20,18);
        g.fillOval(w/2-20,h/2-74,40,44);
        // headdress
        g.setColor(new Color(190,15,25));
        int[] hx2={w/2-22,w/2+22,w/2+20,w/2+6,w/2,w/2-6,w/2-20};
        int[] hy2={h/2-58,h/2-58,h/2-74,h/2-74,h/2-90,h/2-74,h/2-74};
        g.fillPolygon(hx2,hy2,7);
        // eyes
        g.setColor(new Color(220,80,150));
        g.fillOval(w/2-12,h/2-52,10,7);
        g.fillOval(w/2+2,h/2-52,10,7);
        drawName(g,"SCARLET WITCH",w,h,new Color(255,100,150));
    }

    // ─── DOCTOR STRANGE ───────────────────────────────────────────────────────
    private static void drawDoctorStrange(Graphics2D g, int w, int h) {
        bg(g,w,h,new Color(5,5,30),new Color(20,5,50));
        glow(g,w/2f,h/2f,w*0.5f,new Color(80,50,200,100));
        // cloak of levitation
        g.setColor(new Color(180,20,20));
        int[] clx={w/2-40,w/2+40,w/2+55,w/2-55};
        int[] cly={h/2-18,h/2-18,h-10,h-10};
        g.fillPolygon(clx,cly,4);
        // inner blue tunic
        g.setColor(new Color(20,40,100));
        g.fillRoundRect(w/2-22,h/2-20,44,68,8,8);
        g.fillRoundRect(w/2-44,h/2-14,24,52,6,6);
        g.fillRoundRect(w/2+20,h/2-14,24,52,6,6);
        // Eye of Agamotto
        glow(g,w/2f,h/2f-2,22,new Color(80,255,200,180));
        g.setColor(new Color(60,200,150));
        g.fillOval(w/2-10,h/2-12,20,20);
        g.setColor(new Color(180,255,220));
        g.fillOval(w/2-5,h/2-7,10,10);
        // hands with sling ring
        g.setColor(new Color(220,175,130));
        g.fillOval(w/2-44,h/2+32,22,20);
        g.fillOval(w/2+22,h/2+32,22,20);
        // magic ring portals
        g.setColor(new Color(255,180,50,160));
        g.setStroke(new BasicStroke(2f));
        g.drawOval(w/2-46,h/2+30,26,24);
        g.drawOval(w/2+20,h/2+30,26,24);
        // neck+face
        g.setColor(new Color(220,175,130));
        g.fillRect(w/2-10,h/2-36,20,18);
        g.fillOval(w/2-20,h/2-74,40,44);
        // white streak in hair
        g.setColor(new Color(60,50,80));
        g.fillArc(w/2-22,h/2-78,44,30,0,180);
        g.setColor(Color.WHITE);
        g.fillRect(w/2-4,h/2-78,8,14);
        // goatee
        g.setColor(new Color(60,50,80));
        g.fillRoundRect(w/2-5,h/2-38,10,8,3,3);
        // eyes
        g.setColor(new Color(80,100,180));
        g.fillOval(w/2-11,h/2-54,9,7);
        g.fillOval(w/2+2,h/2-54,9,7);
        drawName(g,"DR. STRANGE",w,h,new Color(100,150,255));
    }

    // ─── CADIE (Flerken cat) ──────────────────────────────────────────────────
    private static void drawCadie(Graphics2D g, int w, int h) {
        bg(g,w,h,new Color(20,30,50),new Color(5,10,25));
        glow(g,w/2f,h*0.55f,w*0.45f,new Color(255,140,50,80));
        // body (chubby)
        g.setColor(new Color(220,140,70));
        g.fillOval(w/2-38,h/2,76,75);
        // head
        g.fillOval(w/2-30,h/2-55,60,58);
        // ears
        int[] ex1={w/2-30,w/2-44,w/2-18}; int[] ey1={h/2-50,h/2-80,h/2-80};
        int[] ex2={w/2+30,w/2+44,w/2+18}; int[] ey2={h/2-50,h/2-80,h/2-80};
        g.fillPolygon(ex1,ey1,3); g.fillPolygon(ex2,ey2,3);
        g.setColor(new Color(255,180,180));
        int[] ix1={w/2-28,w/2-40,w/2-20}; int[] iy1={h/2-54,h/2-76,h/2-76};
        int[] ix2={w/2+28,w/2+40,w/2+20}; int[] iy2={h/2-54,h/2-76,h/2-76};
        g.fillPolygon(ix1,iy1,3); g.fillPolygon(ix2,iy2,3);
        // stripes
        g.setColor(new Color(190,110,50));
        g.setStroke(new BasicStroke(2f));
        g.drawArc(w/2-15,h/2-45,30,20,0,180);
        g.drawArc(w/2-22,h/2-35,44,25,0,180);
        // eyes
        g.setColor(new Color(80,50,20));
        g.fillOval(w/2-14,h/2-38,14,12);
        g.fillOval(w/2+0,h/2-38,14,12);
        g.setColor(new Color(255,200,50));
        g.fillOval(w/2-11,h/2-36,8,8);
        g.fillOval(w/2+3,h/2-36,8,8);
        // slit pupils
        g.setColor(new Color(20,10,5));
        g.fillOval(w/2-8,h/2-35,4,7);
        g.fillOval(w/2+6,h/2-35,4,7);
        // nose
        g.setColor(new Color(255,120,120));
        int[] nx={w/2-4,w/2+4,w/2}; int[] ny={h/2-24,h/2-24,h/2-18};
        g.fillPolygon(nx,ny,3);
        // whiskers
        g.setColor(new Color(200,200,200));
        g.setStroke(new BasicStroke(1.2f));
        g.drawLine(w/2-10,h/2-22,w/2-50,h/2-26);
        g.drawLine(w/2-10,h/2-20,w/2-50,h/2-18);
        g.drawLine(w/2+10,h/2-22,w/2+50,h/2-26);
        g.drawLine(w/2+10,h/2-20,w/2+50,h/2-18);
        // paws
        g.setColor(new Color(220,140,70));
        g.fillOval(w/2-48,h/2+48,24,22);
        g.fillOval(w/2+24,h/2+48,24,22);
        g.fillOval(w/2-22,h/2+88,22,18);
        g.fillOval(w/2+0,h/2+88,22,18);
        // collar
        g.setColor(new Color(200,50,50));
        g.setStroke(new BasicStroke(4f));
        g.drawArc(w/2-28,h/2-15,56,20,0,180);
        // flerken tentacles hint
        g.setColor(new Color(200,100,200,120));
        g.setStroke(new BasicStroke(2f));
        g.drawArc(w/2-14,h/2-18,10,16,180,180);
        g.drawArc(w/2+4,h/2-18,10,16,180,180);
        drawName(g,"CADIE",w,h,new Color(255,180,80));
    }

    // ─── LOKI ─────────────────────────────────────────────────────────────────
    private static void drawLoki(Graphics2D g, int w, int h) {
        bg(g,w,h,new Color(5,20,10),new Color(10,5,30));
        glow(g,w/2f,h/2f,w*0.5f,new Color(50,180,80,90));
        // cape
        g.setColor(new Color(30,100,40));
        int[] capx={w/2-28,w/2+28,w/2+48,w/2-48};
        int[] capy={h/2-18,h/2-18,h-12,h-12};
        g.fillPolygon(capx,capy,4);
        // armor
        g.setColor(new Color(20,80,30));
        g.fillRoundRect(w/2-26,h/2-22,52,68,8,8);
        g.fillRoundRect(w/2-48,h/2-15,24,52,6,6);
        g.fillRoundRect(w/2+24,h/2-15,24,52,6,6);
        // gold trim
        g.setColor(new Color(200,170,20));
        g.setStroke(new BasicStroke(2.5f));
        g.drawRoundRect(w/2-26,h/2-22,52,68,8,8);
        // Scepter
        g.setColor(new Color(180,160,20));
        g.setStroke(new BasicStroke(4f));
        g.drawLine(w/2+44,h/2-30,w/2+44,h/2+80);
        g.setColor(new Color(80,200,80));
        g.fillOval(w/2+36,h/2-44,16,16);
        glow(g,w/2+44,h/2-36,14,new Color(100,255,100,180));
        // legs
        g.setColor(new Color(15,60,20));
        g.fillRoundRect(w/2-22,h/2+44,18,58,6,6);
        g.fillRoundRect(w/2+4,h/2+44,18,58,6,6);
        // neck+face
        g.setColor(new Color(220,175,130));
        g.fillRect(w/2-10,h/2-38,20,20);
        g.fillOval(w/2-20,h/2-74,40,42);
        // helmet
        g.setColor(new Color(20,80,30));
        g.fillRoundRect(w/2-22,h/2-78,44,28,6,6);
        // Loki horns
        g.setColor(new Color(200,170,20));
        g.fillRect(w/2-20,h/2-94,8,20);
        g.fillRect(w/2+12,h/2-94,8,20);
        g.fillRect(w/2-16,h/2-104,6,14);
        g.fillRect(w/2+10,h/2-104,6,14);
        // eyes
        g.setColor(new Color(50,180,80));
        g.fillOval(w/2-11,h/2-54,10,8);
        g.fillOval(w/2+1,h/2-54,10,8);
        drawName(g,"LOKI",w,h,new Color(80,220,100));
    }

    // ─── ULTRON ───────────────────────────────────────────────────────────────
    private static void drawUltron(Graphics2D g, int w, int h) {
        bg(g,w,h,new Color(10,10,15),new Color(5,5,25));
        glow(g,w/2f,h/2f,w*0.5f,new Color(200,50,0,100));
        // metal body
        g.setColor(new Color(80,80,95));
        g.fillRoundRect(w/2-30,h/2-18,60,72,10,10);
        // chest plate
        g.setColor(new Color(60,60,75));
        g.fillRoundRect(w/2-26,h/2-14,52,50,8,8);
        // energy core
        glow(g,w/2f,h/2f+8,18,new Color(220,60,0,200));
        g.setColor(new Color(255,80,0));
        g.fillOval(w/2-8,h/2,16,16);
        // arms
        g.setColor(new Color(75,75,90));
        g.fillRoundRect(w/2-56,h/2-16,28,60,8,8);
        g.fillRoundRect(w/2+28,h/2-16,28,60,8,8);
        // claws
        g.setColor(new Color(180,180,200));
        g.setStroke(new BasicStroke(2f));
        for(int i=0;i<3;i++){
            g.drawLine(w/2-36+i*5,h/2+42,w/2-40+i*5,h/2+58);
            g.drawLine(w/2+36+i*5,h/2+42,w/2+32+i*5,h/2+58);
        }
        // legs
        g.setColor(new Color(65,65,80));
        g.fillRoundRect(w/2-26,h/2+52,22,52,6,6);
        g.fillRoundRect(w/2+4,h/2+52,22,52,6,6);
        // head
        g.setColor(new Color(80,80,95));
        g.fillOval(w/2-26,h/2-70,52,52);
        // eye visor
        glow(g,w/2f,h/2-48,20,new Color(220,60,0,180));
        g.setColor(new Color(255,80,0));
        g.fillRoundRect(w/2-20,h/2-58,40,12,4,4);
        // mouth
        g.setColor(new Color(30,30,40));
        g.fillRoundRect(w/2-12,h/2-38,24,6,3,3);
        g.setColor(new Color(180,30,0));
        g.setStroke(new BasicStroke(1.5f));
        for(int i=0;i<4;i++) g.drawLine(w/2-10+i*6,h/2-38,w/2-10+i*6,h/2-32);
        // panel lines
        g.setColor(new Color(100,100,120));
        g.setStroke(new BasicStroke(1f));
        g.drawLine(w/2,h/2-18,w/2,h/2+54);
        g.drawLine(w/2-30,h/2+10,w/2+30,h/2+10);
        drawName(g,"ULTRON",w,h,new Color(255,120,50));
    }

    // ─── GENERIC ──────────────────────────────────────────────────────────────
    private static void drawGeneric(Graphics2D g, int w, int h, String name) {
        bg(g,w,h,new Color(20,20,40),new Color(8,8,20));
        glow(g,w/2f,h/2f,w*0.45f,new Color(100,100,200,80));
        g.setColor(new Color(80,80,120));
        g.fillOval(w/2-28,h/2-72,56,56);
        g.fillRoundRect(w/2-26,h/2-18,52,70,8,8);
        g.fillRoundRect(w/2-48,h/2-12,24,52,6,6);
        g.fillRoundRect(w/2+24,h/2-12,24,52,6,6);
        g.fillRoundRect(w/2-22,h/2+50,18,52,6,6);
        g.fillRoundRect(w/2+4,h/2+50,18,52,6,6);
        drawName(g,name.toUpperCase(),w,h,new Color(180,180,255));
    }

    private static void drawName(Graphics2D g, String name, int w, int h, Color col) {
        // shadow
        g.setFont(new Font("Impact", Font.BOLD, 14));
        FontMetrics fm = g.getFontMetrics();
        int tx = (w - fm.stringWidth(name)) / 2;
        int ty = h - 14;
        g.setColor(new Color(0,0,0,180));
        g.drawString(name, tx+1, ty+1);
        g.setColor(col);
        g.drawString(name, tx, ty);
    }
}
