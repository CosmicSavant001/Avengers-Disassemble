package abilities;

public class Ability {
    public enum TargetType {
        SINGLE_ENEMY,
        ALL_ENEMIES,
        SINGLE_ALLY,
        SELF
    }

    public enum EffectType {
        NONE,
        STUN,
        CONFUSE,
        IMMOBILIZE,
        ATTACK_BOOST,
        DEFENSE_BOOST,
        SPEED_BOOST,
        REDUCE_DEFENSE,
        HEAL,
        SHIELD,
        IGNORE_DEFENSE,
        SUMMON_CLONE
    }

    private String name;
    private String description;
    private int minDamage;
    private int maxDamage;
    private int manaCost;
    private TargetType targetType;
    private EffectType effectType;
    private int effectValue;
    private int effectTurns;
    private double critChance;
    private boolean isHeal;
    private int healAmount;

    public Ability(String name, String description, int minDamage, int maxDamage,
                   int manaCost, TargetType targetType) {
        this.name = name;
        this.description = description;
        this.minDamage = minDamage;
        this.maxDamage = maxDamage;
        this.manaCost = manaCost;
        this.targetType = targetType;
        this.effectType = EffectType.NONE;
        this.critChance = 0.1;
        this.isHeal = false;
        this.healAmount = 0;
    }

    public Ability setEffect(EffectType effectType, int effectValue, int effectTurns) {
        this.effectType = effectType;
        this.effectValue = effectValue;
        this.effectTurns = effectTurns;
        return this;
    }

    public Ability setCritChance(double chance) {
        this.critChance = chance;
        return this;
    }

    public Ability setHeal(int amount) {
        this.isHeal = true;
        this.healAmount = amount;
        return this;
    }

    public int rollDamage() {
        if (minDamage == 0 && maxDamage == 0) return 0;
        return minDamage + (int)(Math.random() * (maxDamage - minDamage + 1));
    }

    public boolean rollCrit() {
        return Math.random() < critChance;
    }

    // Getters
    public String getName() { return name; }
    public String getDescription() { return description; }
    public int getMinDamage() { return minDamage; }
    public int getMaxDamage() { return maxDamage; }
    public int getManaCost() { return manaCost; }
    public TargetType getTargetType() { return targetType; }
    public EffectType getEffectType() { return effectType; }
    public int getEffectValue() { return effectValue; }
    public int getEffectTurns() { return effectTurns; }
    public double getCritChance() { return critChance; }
    public boolean isHeal() { return isHeal; }
    public int getHealAmount() { return healAmount; }

    @Override
    public String toString() {
        String dmgStr = (minDamage == 0 && maxDamage == 0) ? "No damage" : minDamage + "–" + maxDamage + " dmg";
        return name + " | " + dmgStr + " | " + manaCost + " MP | " + targetType.name().replace("_", " ");
    }

    /** Multiply min/max damage by mult (used by difficulty scaling). */
    public void scaleDamage(double mult) {
        minDamage = (int)(minDamage * mult);
        maxDamage = (int)(maxDamage * mult);
        if (healAmount > 0) healAmount = (int)(healAmount * mult);
    }

}
