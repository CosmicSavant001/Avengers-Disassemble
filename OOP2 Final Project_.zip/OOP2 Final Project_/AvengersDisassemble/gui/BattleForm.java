package gui;

import battle.BattleEngine;
import characters.Character;
import abilities.Ability;
import game.GameMode;
import game.GameSession;
import ai.AIController;
import graphics.BackgroundRenderer;
import graphics.SoundEngine;
import graphics.SpriteAnimator;
import graphics.SpriteAnimator.State;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

/**
 * Battle screen.
 * - Characters float on the full background (no boxes).
 * - HP bar = RED, Mana bar = BLUE.
 * - Always-visible Exit button top-left.
 * - Best-of-3 for PvP / PvAI: round indicator shown in turn bar;
 *   after each round the same BattleForm resets and plays the next round.
 */
public class BattleForm extends JFrame implements BattleEngine.BattleListener {

    private final GameSession session;
    private       BattleEngine engine;
    private final BackgroundRenderer.Arena arena;

    // Sprites
    private SpriteAnimator blueSprite, redSprite;

    // HUD – floating overlays
    private JProgressBar blueHP, redHP, blueMana, redMana;
    private JLabel lblBlueHP, lblRedHP;
    private JLabel lblBlueStatus, lblRedStatus;

    // Turn bar
    private JLabel lblTurn, lblRound;
    private JPanel turnBar;

    // Bottom HUD
    private JPanel  skillsPanel;
    private JButton[] skillBtns = new JButton[3];
    private JTextArea logArea;
    private JButton btnExitFight;    // always-visible exit

    private DamageNumberOverlay overlay;

    private int turnNumber = 1;
    private int homeX, homeY;
    private Timer shakeTimer;

    // Colours
    private static final Color HP_RED    = new Color(220, 40,  40);
    private static final Color MP_BLUE   = new Color(50,  120, 255);
    private static final Color BLUE_COL  = new Color(60,  140, 255);
    private static final Color RED_COL   = new Color(255, 70,  70);

    // ── Constructor ───────────────────────────────────────────────────────────
    public BattleForm(GameSession session) {
        this.session = session;
        this.arena   = BackgroundRenderer.arenaFor(session.getBlueCharacter().getName());

        setTitle("Avengers: Disassemble");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1120, 730);
        setLocationRelativeTo(null);
        setResizable(false);

        startRound();   // creates engine, builds UI, starts walk-in

        addWindowListener(new WindowAdapter() {
            @Override public void windowOpened(WindowEvent e)  { homeX = getX(); homeY = getY(); }
            @Override public void windowClosed(WindowEvent e)  { stopSprites(); }
        });
    }

    // ── Round lifecycle ───────────────────────────────────────────────────────

    private void startRound() {
        engine = session.startBattle();
        engine.setListener(this);
        turnNumber = 1;

        build();
        refreshAll();

        SwingUtilities.invokeLater(() -> {
            homeX = getX(); homeY = getY();
            logBanner();
            blueSprite.setState(State.WALK);
            redSprite.setState(State.WALK);
            Timer w = new Timer(900, ev -> {
                blueSprite.setState(State.IDLE);
                redSprite.setState(State.IDLE);
                if (isAITurn()) scheduleAI();
            });
            w.setRepeats(false); w.start();
        });
    }

    private void logBanner() {
        String roundInfo = session.isRoundBasedMode()
                ? "ROUND " + session.getCurrentRound() + " OF " + (session.getRoundsToWin()*2-1)
                : "BATTLE";
        log("══════════════════════════════════════");
        log("  " + roundInfo + " — " + engine.getBlueTeam().getName()
                + " [BLUE]  vs  " + engine.getRedTeam().getName() + " [RED]");
        if (session.isRoundBasedMode())
            log("  Score  " + session.getBlueRoundWins() + " – " + session.getRedRoundWins());
        log("══════════════════════════════════════");
    }

    // ── Full UI build (called at start of every round) ────────────────────────
    private void build() {
        stopSprites();

        JLayeredPane layered = new JLayeredPane();
        layered.setPreferredSize(new Dimension(1120, 730));

        JPanel root = new JPanel(new BorderLayout(0,0)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                                    RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                BackgroundRenderer.paint(g2, getWidth(), getHeight(), arena);
            }
        };
        root.setOpaque(true);
        root.setBounds(0, 0, 1120, 730);

        root.add(buildTurnBar(),   BorderLayout.NORTH);
        root.add(buildArena(),     BorderLayout.CENTER);
        root.add(buildHUD(),       BorderLayout.SOUTH);

        overlay = new DamageNumberOverlay();
        overlay.setBounds(0, 0, 1120, 730);

        layered.add(root,    JLayeredPane.DEFAULT_LAYER);
        layered.add(overlay, JLayeredPane.POPUP_LAYER);
        setContentPane(layered);
        revalidate(); repaint();
    }

    // ── Turn bar ──────────────────────────────────────────────────────────────
    private JPanel buildTurnBar() {
        turnBar = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                Color c = engine.isBlueTeamTurn()
                        ? new Color(10,35,120,235) : new Color(120,10,10,235);
                g2.setColor(c); g2.fillRect(0,0,getWidth(),getHeight());
                g2.setColor(new Color(255,255,255,18));
                g2.fillRect(0,getHeight()-2,getWidth(),2);
            }
        };
        turnBar.setOpaque(false);
        turnBar.setPreferredSize(new Dimension(1120, 44));

        // Left: exit button — always visible
        btnExitFight = new JButton("  EXIT FIGHT  ") {
            boolean h = false;
            { addMouseListener(new MouseAdapter(){
                public void mouseEntered(MouseEvent e){h=true;repaint();}
                public void mouseExited (MouseEvent e){h=false;repaint();}
            }); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                Color c = h ? new Color(180,30,30) : new Color(120,20,20);
                g2.setPaint(new GradientPaint(0,0,c.brighter(),0,getHeight(),c.darker()));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                g2.setColor(new Color(255,255,255,h?70:35));
                g2.setStroke(new BasicStroke(1.2f));
                g2.drawRoundRect(1,1,getWidth()-2,getHeight()-2,8,8);
                g2.setFont(new Font("Arial",Font.BOLD,11));
                g2.setColor(Color.WHITE);
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,
                              (getHeight()+fm.getAscent()-fm.getDescent())/2);
            }
        };
        btnExitFight.setPreferredSize(new Dimension(110, 30));
        btnExitFight.setOpaque(false); btnExitFight.setContentAreaFilled(false);
        btnExitFight.setBorderPainted(false); btnExitFight.setFocusPainted(false);
        btnExitFight.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnExitFight.addActionListener(e -> confirmExit());
        JPanel leftWrap = new JPanel(new FlowLayout(FlowLayout.LEFT,10,7));
        leftWrap.setOpaque(false);
        leftWrap.add(btnExitFight);

        lblTurn = new JLabel("", SwingConstants.CENTER);
        lblTurn.setFont(new Font("Impact",Font.BOLD,20));
        lblTurn.setForeground(Color.WHITE);

        // Right: round indicator
        lblRound = new JLabel("", SwingConstants.RIGHT);
        lblRound.setFont(new Font("Arial",Font.BOLD,13));
        lblRound.setForeground(new Color(200,200,210));
        lblRound.setBorder(BorderFactory.createEmptyBorder(0,0,0,14));

        turnBar.add(leftWrap,  BorderLayout.WEST);
        turnBar.add(lblTurn,   BorderLayout.CENTER);
        turnBar.add(lblRound,  BorderLayout.EAST);
        return turnBar;
    }

    private void confirmExit() {
        int choice = JOptionPane.showConfirmDialog(this,
                "Exit to Main Menu? Current fight progress will be lost.",
                "Exit Fight", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (choice == JOptionPane.YES_OPTION) {
            stopSprites();
            new MainMenuForm().setVisible(true);
            dispose();
        }
    }

    // ── Arena canvas ──────────────────────────────────────────────────────────
    private JPanel buildArena() {
        blueSprite = new SpriteAnimator(engine.getBlueTeam().getName(), false);
        redSprite  = new SpriteAnimator(engine.getRedTeam().getName(),  true);

        JPanel canvas = new JPanel(null);
        canvas.setOpaque(false);
        int sprW=220, sprH=260;
        blueSprite.setBounds(60,          30, sprW, sprH);
        redSprite.setBounds(1120-60-sprW, 30, sprW, sprH);
        canvas.add(blueSprite);
        canvas.add(redSprite);

        JPanel blueHud = buildFloatingHUD(engine.getBlueTeam(), BLUE_COL, true);
        blueHud.setBounds(10, 4, 260, 86);
        canvas.add(blueHud);

        JPanel redHud = buildFloatingHUD(engine.getRedTeam(), RED_COL, false);
        redHud.setBounds(1120-270, 4, 260, 86);
        canvas.add(redHud);

        return canvas;
    }

    private JPanel buildFloatingHUD(Character c, Color col, boolean isBlue) {
        JPanel p = new JPanel(new GridLayout(6,1,0,2)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0,0,0,145));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
            }
        };
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(5,8,5,8));

        JLabel name = new JLabel(c.getName(), isBlue ? SwingConstants.LEFT : SwingConstants.RIGHT);
        name.setFont(new Font("Impact",Font.PLAIN,15)); name.setForeground(col);

        // HP bar = RED, MP bar = BLUE
        JProgressBar hp   = makeBar(c.getMaxHP(),   HP_RED,  new Color(30,5,5),  12);
        JProgressBar mana = makeBar(c.getMaxMana(), MP_BLUE, new Color(5,10,35),  8);

        JLabel hpLbl  = miniLbl("HP  " + c.getCurrentHP() + "/" + c.getMaxHP(),   new Color(255,140,140));
        JLabel mpLbl  = miniLbl("MP  " + c.getCurrentMana() + "/" + c.getMaxMana(), new Color(120,180,255));
        JLabel stLbl  = miniLbl(" ", new Color(255,220,60));

        if (isBlue) { blueHP=hp; blueMana=mana; lblBlueHP=hpLbl; lblBlueStatus=stLbl; }
        else        { redHP=hp;  redMana=mana;  lblRedHP=hpLbl;  lblRedStatus=stLbl;  }

        p.add(name); p.add(hp); p.add(hpLbl); p.add(mana); p.add(mpLbl); p.add(stLbl);
        return p;
    }

    // ── Bottom HUD: skills + log ──────────────────────────────────────────────
    private JPanel buildHUD() {
        JPanel hud = new JPanel(new GridLayout(1,2,10,0)) {
            @Override protected void paintComponent(Graphics g) {
                g.setColor(new Color(4,4,16,235)); g.fillRect(0,0,getWidth(),getHeight());
                g.setColor(new Color(60,40,120,160)); g.fillRect(0,0,getWidth(),2);
            }
        };
        hud.setOpaque(false);
        hud.setPreferredSize(new Dimension(1120,235));
        hud.setBorder(BorderFactory.createEmptyBorder(8,14,10,14));
        skillsPanel = buildSkillsPanel();
        hud.add(skillsPanel);
        hud.add(buildLogPanel());
        return hud;
    }

    private JPanel buildSkillsPanel() {
        JPanel p = new JPanel(new BorderLayout(0,7)); p.setOpaque(false);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(70,50,160,180),1),
                BorderFactory.createEmptyBorder(7,7,7,7)));

        JLabel title = new JLabel("  SKILLS", SwingConstants.CENTER);
        title.setFont(new Font("Impact",Font.BOLD,15));
        title.setForeground(new Color(225,185,55));
        p.add(title, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(3,1,0,7)); grid.setOpaque(false);
        Color[] cols = {new Color(22,68,158), new Color(68,22,128), new Color(148,52,14)};
        List<Ability> abs = engine.getBlueTeam().getAbilities();
        for (int i=0;i<3;i++) {
            final int idx=i;
            skillBtns[i]=skillBtn(abs.get(i),i,cols[i]);
            skillBtns[i].addActionListener(e -> handleSkill(idx));
            grid.add(skillBtns[i]);
        }
        p.add(grid, BorderLayout.CENTER);
        return p;
    }

    private JPanel buildLogPanel() {
        JPanel p = new JPanel(new BorderLayout(0,5)); p.setOpaque(false);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(70,50,160,180),1),
                BorderFactory.createEmptyBorder(7,7,7,7)));
        JLabel t = new JLabel("  BATTLE LOG", SwingConstants.CENTER);
        t.setFont(new Font("Impact",Font.BOLD,15)); t.setForeground(new Color(225,185,55));
        p.add(t, BorderLayout.NORTH);
        logArea = new JTextArea();
        logArea.setEditable(false); logArea.setBackground(new Color(3,3,12));
        logArea.setForeground(new Color(200,215,255)); logArea.setFont(new Font("Consolas",Font.PLAIN,11));
        logArea.setLineWrap(true); logArea.setWrapStyleWord(true);
        logArea.setBorder(BorderFactory.createEmptyBorder(4,4,4,4));
        JScrollPane sp = new JScrollPane(logArea);
        sp.setBorder(BorderFactory.createLineBorder(new Color(25,25,55)));
        p.add(sp, BorderLayout.CENTER);
        return p;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // INTERACTION
    // ══════════════════════════════════════════════════════════════════════════
    private void handleSkill(int idx) {
        if (engine.isBattleOver()) return;
        if (isAITurn()) return;
        Character actor  = engine.getCurrentActor();
        Character target = engine.getCurrentTarget();
        Ability ab = actor.getAbilities().get(idx);
        if (ab.getTargetType()==Ability.TargetType.SELF
         || ab.getTargetType()==Ability.TargetType.SINGLE_ALLY) target = actor;
        setSkillsEnabled(false);

        SpriteAnimator att = engine.isBlueTeamTurn() ? blueSprite : redSprite;
        att.playOnce(State.ATTACK, State.IDLE);

        final Character fa=actor, ft=target; final Ability fab=ab;
        Timer d = new Timer(300, e -> {
            engine.executeAbility(fa, ft, fab);
            if (!engine.isBattleOver()) {
                if (isAITurn()) scheduleAI();
                else { rebuildSkillBtns(); setSkillsEnabled(true); }
            }
        });
        d.setRepeats(false); d.start();
    }

    private boolean isAITurn() {
        return session.getMode() == GameMode.PLAYER_VS_AI && !engine.isBlueTeamTurn();
    }

    private void scheduleAI() {
        if (!engine.isBattleOver() && !isAITurn()) {
            rebuildSkillBtns(); setSkillsEnabled(true); return;
        }
        setSkillsEnabled(false);
        Timer t = new Timer(1100, e -> {
            if (engine.isBattleOver()) return;
            if (!isAITurn()) { rebuildSkillBtns(); setSkillsEnabled(true); return; }

            AIController ai   = session.getRedAI();
            Character actor   = engine.getCurrentActor();
            Character target  = engine.getCurrentTarget();
            Ability aiAb      = ai.selectAbility(actor, target);
            if (aiAb.getTargetType()==Ability.TargetType.SELF
             || aiAb.getTargetType()==Ability.TargetType.SINGLE_ALLY) target = actor;

            redSprite.playOnce(State.ATTACK, State.IDLE);
            final Character fa=actor, ft=target; final Ability fab=aiAb;
            Timer d = new Timer(280, e2 -> {
                engine.executeAbility(fa, ft, fab);
                if (!engine.isBattleOver()) {
                    if (isAITurn()) scheduleAI();
                    else { rebuildSkillBtns(); setSkillsEnabled(true); }
                }
            });
            d.setRepeats(false); d.start();
        });
        t.setRepeats(false); t.start();
    }

    private void doShake(boolean heavy) {
        if (shakeTimer!=null) shakeTimer.stop();
        final int[] f={heavy?10:5};
        shakeTimer=new Timer(30,e->{
            if(f[0]<=0){((Timer)e.getSource()).stop();setLocation(homeX,homeY);return;}
            setLocation(homeX+(int)((Math.random()-.5)*f[0]*(heavy?5:3)),
                        homeY+(int)((Math.random()-.5)*f[0]*(heavy?4:2)));
            f[0]--;
        }); shakeTimer.start();
    }

    // ══════════════════════════════════════════════════════════════════════════
    // REFRESH
    // ══════════════════════════════════════════════════════════════════════════
    private void refreshAll() {
        Character blue = engine.getBlueTeam();
        Character red  = engine.getRedTeam();

        blueHP.setMaximum(blue.getMaxHP()); blueHP.setValue(blue.getCurrentHP());
        lblBlueHP.setText("HP  " + blue.getCurrentHP() + "/" + blue.getMaxHP());
        redHP.setMaximum(red.getMaxHP());   redHP.setValue(red.getCurrentHP());
        lblRedHP.setText("HP  " + red.getCurrentHP() + "/" + red.getMaxHP());

        blueMana.setMaximum(blue.getMaxMana()); blueMana.setValue(blue.getCurrentMana());
        redMana.setMaximum(red.getMaxMana());   redMana.setValue(red.getCurrentMana());

        String bs=blue.getStatusString(); lblBlueStatus.setText(bs.isEmpty()?" ":bs);
        String rs=red.getStatusString();  lblRedStatus.setText(rs.isEmpty()?" ":rs);

        boolean bt = engine.isBlueTeamTurn();
        lblTurn.setText(bt
                ? blue.getName().toUpperCase() + "'S TURN  [BLUE]"
                : red.getName().toUpperCase()  + "'S TURN  [RED]");

        // Round label
        if (session.isRoundBasedMode()) {
            lblRound.setText("Round " + session.getCurrentRound()
                    + "   " + session.getBlueRoundWins()
                    + " – " + session.getRedRoundWins() + "   ");
        } else {
            lblRound.setText("Turn " + turnNumber + "   ");
        }
        turnBar.repaint();

        if (!blue.isAlive()) blueSprite.setState(State.DEFEAT);
        if (!red.isAlive())  redSprite.setState(State.DEFEAT);
    }

    private void rebuildSkillBtns() {
        if (skillsPanel==null) return;
        Character actor = engine.getCurrentActor();
        List<Ability> abs = actor.getAbilities();
        JPanel grid = findGrid(skillsPanel);
        if (grid==null) return;
        Color[] cols={new Color(22,68,158),new Color(68,22,128),new Color(148,52,14)};
        grid.removeAll();
        for (int i=0;i<3;i++) {
            final int idx=i; Ability ab=abs.get(i);
            JButton nb=skillBtn(ab,i,cols[i]);
            nb.addActionListener(e->handleSkill(idx));
            nb.setEnabled(actor.getCurrentMana()>=ab.getManaCost()
                          &&!actor.isStunned()&&!actor.isImmobilized());
            grid.add(nb); skillBtns[i]=nb;
        }
        grid.revalidate(); grid.repaint();
    }

    private JPanel findGrid(JPanel p) {
        for (Component c:p.getComponents())
            if (c instanceof JPanel)
                for (Component cc:((JPanel)c).getComponents())
                    if (cc instanceof JPanel) return (JPanel)cc;
        return null;
    }

    private void setSkillsEnabled(boolean en) {
        for (JButton b:skillBtns) if(b!=null) b.setEnabled(en);
    }

    private void stopSprites() {
        if (blueSprite!=null) blueSprite.stopAnimation();
        if (redSprite !=null) redSprite.stopAnimation();
    }

    // ══════════════════════════════════════════════════════════════════════════
    // HELPERS
    // ══════════════════════════════════════════════════════════════════════════
    private JButton skillBtn(Ability ab, int idx, Color col) {
        JButton b = new JButton() {
            boolean h=false;
            { addMouseListener(new MouseAdapter(){
                public void mouseEntered(MouseEvent e){h=true;repaint();}
                public void mouseExited (MouseEvent e){h=false;repaint();}
            }); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg=isEnabled()?(h?col.brighter():col):new Color(30,30,44);
                g2.setPaint(new GradientPaint(0,0,bg.brighter(),0,getHeight(),bg.darker()));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
                g2.setColor(new Color(255,255,255,h?65:25)); g2.fillRoundRect(4,4,getWidth()-8,getHeight()/3,6,6);
                g2.setColor(new Color(255,255,255,h?85:40)); g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(1,1,getWidth()-2,getHeight()-2,12,12);
                g2.setColor(new Color(0,0,0,120)); g2.fillOval(7,5,22,22);
                g2.setFont(new Font("Impact",Font.BOLD,14));
                g2.setColor(isEnabled()?Color.WHITE:new Color(90,90,100));
                g2.drawString(String.valueOf(idx+1),14,21);
                g2.setFont(new Font("Arial",Font.BOLD,12));
                g2.setColor(isEnabled()?Color.WHITE:new Color(90,90,100));
                g2.drawString(ab.getName(),36,17);
                g2.setFont(new Font("Arial",Font.PLAIN,10));
                String dmg=(ab.getMinDamage()==0&&ab.getMaxDamage()==0)
                        ?"Heal/Effect":ab.getMinDamage()+"–"+ab.getMaxDamage()+" dmg";
                g2.setColor(new Color(255,210,110)); g2.drawString(dmg,36,30);
                if (ab.getEffectType()!=Ability.EffectType.NONE
                 && ab.getEffectType()!=Ability.EffectType.IGNORE_DEFENSE) {
                    g2.setColor(new Color(255,175,55));
                    g2.drawString(ab.getEffectType().name().replace("_"," "),36,43);
                }
                g2.setColor(isEnabled()?new Color(100,165,255):new Color(70,70,90));
                g2.drawString(ab.getManaCost()+" MP",getWidth()-56,17);
                String tgt=ab.getTargetType()==Ability.TargetType.ALL_ENEMIES?"ALL"
                         : ab.getTargetType()==Ability.TargetType.SELF?"SELF"
                         : ab.getTargetType()==Ability.TargetType.SINGLE_ALLY?"ALLY":"1 TGT";
                g2.setColor(new Color(140,240,140)); g2.drawString(tgt,getWidth()-56,30);
            }
        };
        b.setPreferredSize(new Dimension(460,56));
        b.setOpaque(false); b.setContentAreaFilled(false);
        b.setBorderPainted(false); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    private JProgressBar makeBar(int max, Color fg, Color bg, int h) {
        JProgressBar pb=new JProgressBar(0,max); pb.setValue(max);
        pb.setStringPainted(false); pb.setForeground(fg); pb.setBackground(bg);
        pb.setBorderPainted(false); pb.setPreferredSize(new Dimension(0,h)); return pb;
    }
    private JLabel miniLbl(String t, Color c) {
        JLabel l=new JLabel(t,SwingConstants.CENTER);
        l.setForeground(c); l.setFont(new Font("Arial",Font.PLAIN,10)); return l;
    }
    private Color hpCol(double p) {
        // HP bar is always red; shade by percentage
        if (p>.55) return HP_RED;
        if (p>.28) return new Color(210,80,20);
        return new Color(200,20,20);
    }
    private void log(String m) {
        if (logArea!=null) {
            logArea.append(m+"\n");
            logArea.setCaretPosition(logArea.getDocument().getLength());
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // BattleEngine.BattleListener
    // ══════════════════════════════════════════════════════════════════════════
    @Override public void onBattleLogUpdate(String msg) {
        SwingUtilities.invokeLater(()->log(msg));
    }

    @Override public void onTurnChange(boolean blueTurn) {
        SwingUtilities.invokeLater(()->{
            turnNumber++;
            refreshAll();
        });
    }

    @Override public void onStatusUpdate() {
        SwingUtilities.invokeLater(()->{
            refreshAll();
            boolean bt = engine.isBlueTeamTurn();
            SpriteAnimator def = bt ? blueSprite : redSprite;
            List<String> bl = engine.getBattleLog();
            if (!bl.isEmpty()) {
                String last = bl.get(bl.size()-1);
                int px=bt?240:870, py=180+(int)(Math.random()*100);
                if (!last.contains("healed")&&!last.contains("BOOST")&&!last.contains("shield"))
                    def.playOnce(State.HIT, State.IDLE);
                if      (last.contains("healed"))      overlay.spawnDamage(px,py,0,false,true);
                else if (last.contains("STUNNED"))     overlay.spawnStatus(px,py,"STUNNED!");
                else if (last.contains("CONFUSED"))    overlay.spawnStatus(px,py,"CONFUSED!");
                else if (last.contains("IMMOBILIZED")) overlay.spawnStatus(px,py,"IMMOBILIZED!");
                else if (last.contains("CRIT"))        { overlay.spawnDamage(px,py,0,true,false); doShake(true); }
                else if (last.contains("takes"))       doShake(false);
                String rec = String.join(" ",bl.subList(Math.max(0,bl.size()-3),bl.size()));
                if     (rec.contains("healed")||rec.contains(" HP")) SoundEngine.play(SoundEngine.SFX.HEAL);
                else if(rec.contains("STUN"))   SoundEngine.play(SoundEngine.SFX.STUN);
                else if(rec.contains("BOOST")||rec.contains("shield")) SoundEngine.play(SoundEngine.SFX.BUFF);
                else if(rec.contains("CRIT"))   SoundEngine.play(SoundEngine.SFX.HEAVY_ATTACK);
                else SoundEngine.play(SoundEngine.SFX.ATTACK);
            }
        });
    }

    @Override public void onBattleEnd(String winner) {
        SwingUtilities.invokeLater(()->{
            refreshAll();
            setSkillsEnabled(false);
            boolean blueWon = winner.contains("Blue");
            (blueWon ? blueSprite : redSprite).setState(State.VICTORY);
            SoundEngine.play(blueWon ? SoundEngine.SFX.VICTORY : SoundEngine.SFX.DEFEAT);

            log("══════════════════════════════════════");
            log("  WINNER: " + winner + "  (Turn " + turnNumber + ")");

            if (session.isRoundBasedMode()) {
                // Record the round win
                session.recordRoundWin(blueWon);
                log("  Score: " + session.getBlueRoundWins()
                        + " – " + session.getRedRoundWins());

                if (session.isMatchOver()) {
                    // Match decided — go to game over
                    String matchWinner = session.blueWonMatch()
                            ? engine.getBlueTeam().getName() + " (Blue Team)"
                            : engine.getRedTeam().getName()  + " (Red Team)";
                    log("  MATCH WINNER: " + matchWinner + "!");
                    Timer t = new Timer(1400, e ->
                            new GameOverForm(matchWinner, session, this).setVisible(true));
                    t.setRepeats(false); t.start();
                } else {
                    // Play next round
                    String next = "Round " + session.getCurrentRound();
                    log("  Starting " + next + "...");
                    Timer t = new Timer(2000, e -> {
                        stopSprites();
                        startRound();
                    });
                    t.setRepeats(false); t.start();
                }
            } else {
                // Single-round mode (Arcade handled separately)
                Timer t = new Timer(1100, e ->
                        new GameOverForm(winner, session, this).setVisible(true));
                t.setRepeats(false); t.start();
            }
        });
    }
}
