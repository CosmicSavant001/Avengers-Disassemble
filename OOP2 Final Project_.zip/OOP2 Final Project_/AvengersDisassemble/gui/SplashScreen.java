package gui;

import graphics.BackgroundRenderer;
import graphics.SoundEngine;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class SplashScreen extends JWindow {

    private float   alpha      = 0f;
    private boolean showButton = false;
    private final Runnable onDone;

    private final Rectangle startBtnRect = new Rectangle(0, 0, 260, 56);

    public SplashScreen(Runnable onDone) {
        this.onDone = onDone;
        setSize(920, 540);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(null) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,      RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,     RenderingHints.VALUE_INTERPOLATION_BILINEAR);

                // Background
                BackgroundRenderer.paint(g2, getWidth(), getHeight(), BackgroundRenderer.Arena.ASGARD);
                g2.setColor(new Color(0, 0, 0, 160));
                g2.fillRect(0, 0, getWidth(), getHeight());

                // Global alpha fade
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));

                int cx = getWidth() / 2;

                // ── AVENGERS: ─────────────────────────────────────────────────
                g2.setFont(new Font("Impact", Font.BOLD, 84));
                FontMetrics fm = g2.getFontMetrics();
                String t1 = "AVENGERS:";
                int x1 = cx - fm.stringWidth(t1) / 2;
                for (int b = 7; b >= 1; b--) {
                    g2.setColor(new Color(200, 20, 20, 13 * b));
                    g2.drawString(t1, x1 - b, 168 + b);
                }
                g2.setColor(new Color(215, 30, 30));
                g2.drawString(t1, x1, 166);

                // ── DISASSEMBLE ───────────────────────────────────────────────
                g2.setFont(new Font("Impact", Font.BOLD, 94));
                fm = g2.getFontMetrics();
                String t2 = "DISASSEMBLE";
                int x2 = cx - fm.stringWidth(t2) / 2;
                for (int b = 7; b >= 1; b--) {
                    g2.setColor(new Color(255, 255, 255, 13 * b));
                    g2.drawString(t2, x2 - b, 262 + b);
                }
                g2.setColor(Color.WHITE);
                g2.drawString(t2, x2, 260);

                // ── Subtitle ──────────────────────────────────────────────────
                g2.setFont(new Font("Arial", Font.ITALIC, 17));
                fm = g2.getFontMetrics();
                String sub = "A Turn-Based Marvel Arena Combat Game";
                g2.setColor(new Color(180, 180, 235));
                g2.drawString(sub, cx - fm.stringWidth(sub) / 2, 300);

                // ── Loading bar — always visible once fading in ────────────────
                int barX = 120, barY = 380, barW = getWidth() - 240, barH = 10;
                g2.setColor(new Color(25, 25, 48));
                g2.fillRoundRect(barX, barY, barW, barH, 6, 6);
                g2.setColor(new Color(200, 30, 30));
                g2.fillRoundRect(barX, barY, (int)(barW * Math.min(1f, alpha)), barH, 6, 6);
                // loading bar border
                g2.setColor(new Color(80, 40, 80, 120));
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(barX, barY, barW, barH, 6, 6);

                // ── START GAME button — shown only when fully loaded ───────────
                if (showButton) {
                    int bx = cx - startBtnRect.width / 2;
                    int by = 410;
                    startBtnRect.setLocation(bx, by);

                    // Pulse glow
                    long ms  = System.currentTimeMillis();
                    float pulse = (float)(0.55 + 0.45 * Math.sin(ms / 420.0));
                    RadialGradientPaint glow = new RadialGradientPaint(
                            bx + startBtnRect.width  / 2f,
                            by + startBtnRect.height / 2f,
                            startBtnRect.width * 0.7f,
                            new float[]{0f, 1f},
                            new Color[]{new Color(200, 30, 30, (int)(110 * pulse)),
                                        new Color(200, 30, 30, 0)});
                    g2.setPaint(glow);
                    g2.fillOval(bx - 30, by - 20,
                                startBtnRect.width + 60, startBtnRect.height + 40);

                    // Button body
                    g2.setPaint(new GradientPaint(
                            bx, by,                       new Color(220, 50, 50),
                            bx, by + startBtnRect.height, new Color(140, 20, 20)));
                    g2.fillRoundRect(bx, by, startBtnRect.width, startBtnRect.height, 14, 14);

                    // Highlight
                    g2.setColor(new Color(255, 255, 255, 40));
                    g2.fillRoundRect(bx + 4, by + 4, startBtnRect.width - 8, startBtnRect.height / 3, 8, 8);

                    // Border
                    g2.setColor(new Color(255, 180, 180, 190));
                    g2.setStroke(new BasicStroke(2f));
                    g2.drawRoundRect(bx + 1, by + 1,
                                     startBtnRect.width - 2, startBtnRect.height - 2, 14, 14);

                    // Label
                    g2.setFont(new Font("Impact", Font.PLAIN, 28));
                    fm = g2.getFontMetrics();
                    String lbl = "  START GAME  ";
                    g2.setColor(new Color(0, 0, 0, 110));
                    g2.drawString(lbl,
                            bx + (startBtnRect.width  - fm.stringWidth(lbl)) / 2 + 1,
                            by + (startBtnRect.height + fm.getAscent() - fm.getDescent()) / 2 + 1);
                    g2.setColor(Color.WHITE);
                    g2.drawString(lbl,
                            bx + (startBtnRect.width  - fm.stringWidth(lbl)) / 2,
                            by + (startBtnRect.height + fm.getAscent() - fm.getDescent()) / 2);
                }

                // ── Credit ────────────────────────────────────────────────────
                g2.setFont(new Font("Arial", Font.PLAIN, 12));
                g2.setColor(new Color(100, 100, 145));
                fm = g2.getFontMetrics();
                String cred = "Group: Fantastic 4  |  Java Swing OOP Project";
                g2.drawString(cred, cx - fm.stringWidth(cred) / 2, 507);

                g2.setComposite(AlphaComposite.SrcOver);
            }
        };
        panel.setBackground(Color.BLACK);

        // Mouse click on the START button
        panel.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (showButton && startBtnRect.contains(e.getPoint()))
                    startFadeOut();
            }
        });

        // Keyboard: Enter or Space
        panel.setFocusable(true);
        panel.addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (showButton && (e.getKeyCode() == KeyEvent.VK_ENTER
                                || e.getKeyCode() == KeyEvent.VK_SPACE))
                    startFadeOut();
            }
        });

        setContentPane(panel);

        // 30 fps pulse repaint
        new Timer(33, e -> { if (showButton) repaint(); }).start();

        // Fade-in
        Timer fadeIn = new Timer(25, null);
        fadeIn.addActionListener(e -> {
            alpha = Math.min(1f, alpha + 0.030f);
            repaint();
            if (alpha >= 1f) {
                fadeIn.stop();
                showButton = true;
                panel.requestFocusInWindow();
                repaint();
            }
        });
        this.startFadeIn = fadeIn;
    }

    private final Timer startFadeIn;

    private void startFadeOut() {
        SoundEngine.play(SoundEngine.SFX.SELECT);
        showButton = false;
        Timer fadeOut = new Timer(25, null);
        fadeOut.addActionListener(e -> {
            alpha = Math.max(0f, alpha - 0.05f);
            repaint();
            if (alpha <= 0f) {
                fadeOut.stop();
                dispose();
                onDone.run();
            }
        });
        fadeOut.start();
    }

    public void start() {
        setVisible(true);
        startFadeIn.start();
    }
}
