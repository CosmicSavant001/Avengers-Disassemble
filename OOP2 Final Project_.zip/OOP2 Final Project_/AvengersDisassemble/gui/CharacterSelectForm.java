package gui;

import characters.CharacterFactory;
import game.GameMode;
import game.GameSession;
import ai.AIController;
import graphics.SpritePortrait;
import graphics.BackgroundRenderer;
import graphics.SoundEngine;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

public class CharacterSelectForm extends JFrame {

    private final GameMode mode;
    private String blueSelected = null;
    private String redSelected  = null;
    private AIController.Difficulty aiDiff = AIController.Difficulty.NORMAL;

    private JLabel lblBlueChosen, lblRedChosen, lblBlueStats, lblRedStats;
    private JLabel lblBluePortrait, lblRedPortrait;
    private JButton btnStart;
    private JPanel blueGrid, redGrid;

    static final String[] CHARS = {
        "Iron Man","Spider-Man","Thor","Hulk",
        "Black Widow","Scarlet Witch","Doctor Strange","Cadie",
        "Loki","Ultron"
    };

    private static final Color BLUE = new Color(30,90,200);
    private static final Color RED  = new Color(200,30,30);

    public CharacterSelectForm(GameMode mode) {
        this.mode = mode;
        setTitle("Select Fighters – " + mode.getDisplayName());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1120, 720);
        setLocationRelativeTo(null);
        setResizable(false);
        build();
    }

    private void build() {
        JPanel root = new JPanel(new BorderLayout(8,8)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                BackgroundRenderer.paint(g2,getWidth(),getHeight(),BackgroundRenderer.Arena.DEFAULT_ARENA);
                g2.setColor(new Color(0,0,0,160)); g2.fillRect(0,0,getWidth(),getHeight());
            }
        };
        root.setOpaque(false);
        root.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));

        // header
        JLabel title = new JLabel("— SELECT YOUR FIGHTERS —  " + mode.getDisplayName().toUpperCase(), SwingConstants.CENTER);
        title.setFont(new Font("Impact",Font.BOLD,28));
        title.setForeground(new Color(220,185,55));
        title.setBorder(BorderFactory.createEmptyBorder(0,0,10,0));
        root.add(title, BorderLayout.NORTH);

        // two team panels side by side
        JPanel teams = new JPanel(new GridLayout(1,2,18,0)); teams.setOpaque(false);
        blueGrid = new JPanel(new GridLayout(2,5,7,7)); blueGrid.setOpaque(false);
        redGrid  = new JPanel(new GridLayout(2,5,7,7)); redGrid.setOpaque(false);

        lblBlueChosen = infoLbl("No character selected");
        lblRedChosen  = infoLbl("No character selected");
        lblBlueStats  = statsLbl(" ");
        lblRedStats   = statsLbl(" ");
        lblBluePortrait = portraitHolder();
        lblRedPortrait  = portraitHolder();

        for (String c : CHARS) {
            blueGrid.add(card(c, BLUE, true));
            redGrid.add(card(c, RED, false));
        }

        teams.add(teamPanel("◆  BLUE TEAM  (Player 1)", BLUE, blueGrid, lblBlueChosen, lblBlueStats, lblBluePortrait));
        teams.add(teamPanel("◆  RED TEAM  " + (mode == GameMode.PLAYER_VS_PLAYER ? "(Player 2)" : "(AI)"),
                RED, redGrid, lblRedChosen, lblRedStats, lblRedPortrait));
        root.add(teams, BorderLayout.CENTER);

        // bottom bar
        JPanel bot = new JPanel(new BorderLayout(8,0)); bot.setOpaque(false);
        bot.setBorder(BorderFactory.createEmptyBorder(10,0,0,0));

        if (mode != GameMode.PLAYER_VS_PLAYER) {
            JPanel dr = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0)); dr.setOpaque(false);
            JLabel dl = new JLabel("AI DIFFICULTY:");
            dl.setForeground(new Color(220, 185, 55)); dl.setFont(new Font("Impact", Font.PLAIN, 16));
            dr.add(dl);
            String[] labels = {"  EASY  ", " NORMAL ", "  HARD  "};
            Color[]  colors = {new Color(30,140,30), new Color(30,80,180), new Color(180,30,30)};
            AIController.Difficulty[] diffs = {AIController.Difficulty.EASY, AIController.Difficulty.NORMAL, AIController.Difficulty.HARD};
            JButton[] diffBtns = new JButton[3];
            for (int di = 0; di < 3; di++) {
                final int dIdx = di;
                JButton db = new JButton(labels[di]) {
                    boolean selected = (dIdx == 1); // default NORMAL
                    { putClientProperty("selected", selected);
                      addActionListener(ev -> {
                          aiDiff = diffs[dIdx];
                          for (JButton b : diffBtns) {
                              boolean s = (b == this);
                              b.putClientProperty("selected", s);
                              b.repaint();
                          }
                      }); }
                    @Override protected void paintComponent(Graphics g) {
                        boolean sel = Boolean.TRUE.equals(getClientProperty("selected"));
                        Graphics2D g2 = (Graphics2D)g;
                        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        Color c = colors[dIdx];
                        if (sel) {
                            g2.setPaint(new GradientPaint(0,0,c.brighter(),0,getHeight(),c));
                        } else {
                            g2.setColor(new Color(c.getRed()/4, c.getGreen()/4, c.getBlue()/4));
                        }
                        g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                        g2.setColor(sel ? Color.WHITE : new Color(c.getRed(),c.getGreen(),c.getBlue(),160));
                        g2.setStroke(new BasicStroke(sel ? 2f : 1f));
                        g2.drawRoundRect(1,1,getWidth()-2,getHeight()-2,8,8);
                        g2.setFont(new Font("Impact", Font.PLAIN, 14));
                        g2.setColor(sel ? Color.WHITE : new Color(180,180,180));
                        FontMetrics fm = g2.getFontMetrics();
                        g2.drawString(getText().trim(), (getWidth()-fm.stringWidth(getText().trim()))/2,
                                      (getHeight()+fm.getAscent()-fm.getDescent())/2);
                    }
                };
                db.setPreferredSize(new Dimension(80, 32));
                db.setOpaque(false); db.setContentAreaFilled(false);
                db.setBorderPainted(false); db.setFocusPainted(false);
                db.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                diffBtns[di] = db;
                dr.add(db);
            }
            // default normal selected
            diffBtns[1].putClientProperty("selected", true);
            bot.add(dr, BorderLayout.WEST);
        }

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT,12,0)); btnRow.setOpaque(false);
        JButton back = sBtn("  Back  ", new Color(55,55,82));
        back.addActionListener(e -> { SoundEngine.play(SoundEngine.SFX.MENU_CLICK); new MainMenuForm().setVisible(true); dispose(); });
        btnStart = sBtn("START BATTLE  →", RED); btnStart.setEnabled(false);
        btnStart.addActionListener(e -> { SoundEngine.play(SoundEngine.SFX.SELECT); startBattle(); });
        btnRow.add(back); btnRow.add(btnStart); bot.add(btnRow, BorderLayout.EAST);
        root.add(bot, BorderLayout.SOUTH);
        setContentPane(root);
    }

    private JPanel teamPanel(String name, Color col, JPanel grid, JLabel chosen, JLabel stats, JLabel portrait) {
        JPanel p = new JPanel(new BorderLayout(0,7));
        p.setBackground(new Color(10,10,24,230));
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(col,2),
                BorderFactory.createEmptyBorder(9,9,9,9)));

        JLabel nm = new JLabel(name, SwingConstants.CENTER);
        nm.setFont(new Font("Impact",Font.BOLD,17)); nm.setForeground(col);
        p.add(nm, BorderLayout.NORTH);
        p.add(grid, BorderLayout.CENTER);

        // info strip
        JPanel info = new JPanel(new BorderLayout(8,0));
        info.setBackground(new Color(6,6,18)); info.setBorder(BorderFactory.createLineBorder(col.darker(),1));
        portrait.setPreferredSize(new Dimension(100,112));
        info.add(portrait, BorderLayout.WEST);
        JPanel txt = new JPanel(new GridLayout(2,1)); txt.setBackground(new Color(6,6,18));
        txt.add(chosen); txt.add(stats); info.add(txt, BorderLayout.CENTER);
        p.add(info, BorderLayout.SOUTH);
        return p;
    }

    private JPanel card(String charName, Color col, boolean isBlue) {
        // tooltip = backstory
        characters.Character c = CharacterFactory.createCharacter(charName);
        String tip = "<html><b>" + charName + "</b><br>"
                + "HP: " + c.getMaxHP() + "  MP: " + c.getMaxMana() + "<br>"
                + "<i>" + c.getBackstory() + "</i></html>";

        JPanel card = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2=(Graphics2D)g; g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                String sel = isBlue ? blueSelected : redSelected;
                boolean selected = charName.equals(sel);
                if (selected) {
                    GradientPaint gp = new GradientPaint(0,0,new Color(col.getRed(),col.getGreen(),col.getBlue(),90),
                            0,getHeight(),new Color(col.getRed(),col.getGreen(),col.getBlue(),40));
                    g2.setPaint(gp);
                } else {
                    g2.setColor(new Color(12,12,26));
                }
                g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                if (selected) { g2.setColor(col); g2.setStroke(new BasicStroke(2.5f)); g2.drawRoundRect(1,1,getWidth()-2,getHeight()-2,10,10); }
            }
        };
        card.setOpaque(false); card.setBorder(BorderFactory.createEmptyBorder(3,3,3,3));
        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        card.setToolTipText(tip);

        BufferedImage img = SpritePortrait.render(charName, 82, 90);
        JLabel portLbl = new JLabel(new ImageIcon(img)); portLbl.setOpaque(false);
        JLabel nm = new JLabel(charName.length()>11?charName.substring(0,10)+"…":charName, SwingConstants.CENTER);
        nm.setFont(new Font("Arial",Font.BOLD,9)); nm.setForeground(new Color(215,215,245)); nm.setOpaque(false);

        card.add(portLbl, BorderLayout.CENTER); card.add(nm, BorderLayout.SOUTH);
        card.addMouseListener(new MouseAdapter(){ public void mouseClicked(MouseEvent e){ SoundEngine.play(SoundEngine.SFX.SELECT); pick(charName,isBlue); } });
        return card;
    }

    private void pick(String charName, boolean isBlue) {
        if (isBlue) {
            blueSelected = charName;
            lblBlueChosen.setText("✓  " + charName);
            lblBlueStats.setText(stats(charName));
            lblBluePortrait.setIcon(new ImageIcon(SpritePortrait.render(charName,96,108)));
            blueGrid.repaint();
        } else {
            redSelected = charName;
            lblRedChosen.setText("✓  " + charName);
            lblRedStats.setText(stats(charName));
            lblRedPortrait.setIcon(new ImageIcon(SpritePortrait.render(charName,96,108)));
            redGrid.repaint();
        }
        checkReady();
    }

    private void checkReady() {
        if (mode == GameMode.PLAYER_VS_PLAYER) {
            btnStart.setEnabled(blueSelected != null && redSelected != null);
        } else if (mode == GameMode.PLAYER_VS_AI) {
            if (blueSelected != null && redSelected == null) autoPickAI(false);
            btnStart.setEnabled(blueSelected != null);
        } else {
            if (blueSelected == null) autoPickAI(true);
            if (redSelected  == null) autoPickAI(false);
            btnStart.setEnabled(true);
        }
    }

    private void autoPickAI(boolean isBlue) {
        String pick = CHARS[(int)(Math.random() * CHARS.length)];
        if (isBlue) {
            blueSelected = pick; lblBlueChosen.setText("AI:  "+pick); lblBlueStats.setText(stats(pick));
            lblBluePortrait.setIcon(new ImageIcon(SpritePortrait.render(pick,96,108))); blueGrid.repaint();
        } else {
            redSelected = pick; lblRedChosen.setText("AI:  "+pick); lblRedStats.setText(stats(pick));
            lblRedPortrait.setIcon(new ImageIcon(SpritePortrait.render(pick,96,108))); redGrid.repaint();
        }
    }

    private void startBattle() {
        if (blueSelected == null || redSelected == null) return;
        GameSession s = new GameSession(mode);
        s.setBlueCharacter(blueSelected); s.setRedCharacter(redSelected);
        if (mode == GameMode.PLAYER_VS_AI)  s.setRedAI(aiDiff);
        if (mode == GameMode.AI_VS_AI) { s.setBlueAI(aiDiff); s.setRedAI(aiDiff); }
        new BattleForm(s).setVisible(true);
        dispose();
    }

    // ── helpers ──
    private JLabel infoLbl(String t) { JLabel l=new JLabel(t,SwingConstants.CENTER); l.setForeground(new Color(165,165,205)); l.setFont(new Font("Arial",Font.BOLD,13)); l.setBorder(BorderFactory.createEmptyBorder(5,5,2,5)); return l; }
    private JLabel statsLbl(String t) { JLabel l=new JLabel(t,SwingConstants.CENTER); l.setForeground(new Color(100,205,105)); l.setFont(new Font("Arial",Font.PLAIN,11)); l.setBorder(BorderFactory.createEmptyBorder(0,5,5,5)); return l; }
    private JLabel portraitHolder() { JLabel l=new JLabel("",SwingConstants.CENTER); l.setPreferredSize(new Dimension(100,112)); return l; }
    private String stats(String n) { characters.Character c=CharacterFactory.createCharacter(n); return "HP: "+c.getMaxHP()+"   MP: "+c.getMaxMana()+"   Skills: 3"; }

    private JButton sBtn(String text, Color col) {
        JButton b = new JButton(text) {
            boolean h=false;
            { addMouseListener(new MouseAdapter(){ public void mouseEntered(MouseEvent e){h=true;repaint();} public void mouseExited(MouseEvent e){h=false;repaint();} }); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g; g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                Color c = isEnabled()?(h?col.brighter():col):new Color(45,45,58);
                GradientPaint gp=new GradientPaint(0,0,c.brighter(),0,getHeight(),c.darker());
                g2.setPaint(gp); g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                g2.setColor(new Color(255,255,255,h?80:40)); g2.setStroke(new BasicStroke(1.5f)); g2.drawRoundRect(1,1,getWidth()-2,getHeight()-2,10,10);
                g2.setFont(new Font("Arial",Font.BOLD,14)); g2.setColor(Color.WHITE);
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
            }
        };
        b.setPreferredSize(new Dimension(185,42));
        b.setOpaque(false); b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }
}
