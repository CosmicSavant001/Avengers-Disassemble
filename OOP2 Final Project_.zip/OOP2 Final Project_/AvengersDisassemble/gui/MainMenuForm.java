package gui;

import game.GameMode;
import graphics.BackgroundRenderer;
import graphics.SoundEngine;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainMenuForm extends JFrame {

    public MainMenuForm() {
        setTitle("Avengers: Disassemble");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(960, 620);
        setLocationRelativeTo(null);
        setResizable(false);
        build();
    }

    private void build() {
        JPanel root = new JPanel(null) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,  RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                BackgroundRenderer.paint(g2, getWidth(), getHeight(), BackgroundRenderer.Arena.SPACE_NEBULA);
                GradientPaint gp = new GradientPaint(0, 0, new Color(0,0,0,40),
                                                     0, getHeight(), new Color(0,0,0,185));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        root.setBackground(Color.BLACK);

        // ── Title block ───────────────────────────────────────────────────────
        JPanel titleBlock = new JPanel(null) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,      RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

                // AVENGERS:
                g2.setFont(new Font("Impact", Font.BOLD, 62));
                FontMetrics fm = g2.getFontMetrics();
                String t1 = "AVENGERS:";
                int x1 = (getWidth() - fm.stringWidth(t1)) / 2;
                for (int b = 5; b >= 1; b--) {
                    g2.setColor(new Color(200, 20, 20, 16 * b));
                    g2.drawString(t1, x1 - b, 60 + b);
                }
                g2.setColor(new Color(215, 30, 30));
                g2.drawString(t1, x1, 58);

                // DISASSEMBLE
                g2.setFont(new Font("Impact", Font.BOLD, 70));
                fm = g2.getFontMetrics();
                String t2 = "DISASSEMBLE";
                int x2 = (getWidth() - fm.stringWidth(t2)) / 2;
                for (int b = 5; b >= 1; b--) {
                    g2.setColor(new Color(255, 255, 255, 14 * b));
                    g2.drawString(t2, x2 - b, 130 + b);
                }
                g2.setColor(Color.WHITE);
                g2.drawString(t2, x2, 128);

                // Subtitle
                g2.setFont(new Font("Arial", Font.ITALIC, 15));
                fm = g2.getFontMetrics();
                String sub = "Turn-Based Marvel Arena Combat";
                g2.setColor(new Color(170, 170, 225));
                g2.drawString(sub, (getWidth() - fm.stringWidth(sub)) / 2, 156);
            }
        };
        titleBlock.setOpaque(false);
        titleBlock.setBounds(0, 30, 960, 168);
        root.add(titleBlock);

        // ── Mode buttons — 3 modes only (no AI vs AI) ─────────────────────────
        Object[][] modes = {
            {"PLAYER  vs  PLAYER",  GameMode.PLAYER_VS_PLAYER,
             new Color(25, 85, 175),   "Two players battle on the same machine"},
            {"PLAYER  vs  AI",      GameMode.PLAYER_VS_AI,
             new Color(18, 105, 50),   "Face off against the computer"},
            {"ARCADE  MODE",         GameMode.ARCADE,
             new Color(140, 60, 0),    "Survive endless waves — how far can you go?"},
        };

        int bw = 480, bh = 62, bx = (960 - bw) / 2, by = 222;
        for (int i = 0; i < modes.length; i++) {
            final GameMode gm  = (GameMode) modes[i][1];
            final Color    col = (Color)    modes[i][2];
            final String   dsc = (String)   modes[i][3];
            JButton b = menuBtn((String) modes[i][0], dsc, col, bw, bh);
            b.setBounds(bx, by + i * (bh + 14), bw, bh);
            b.addActionListener(e -> { SoundEngine.play(SoundEngine.SFX.MENU_CLICK); openSelect(gm); });
            root.add(b);
        }

        // ── Exit ──────────────────────────────────────────────────────────────
        JButton exit = menuBtn("  EXIT  ", "Leave the game", new Color(100, 18, 18), 200, 40);
        exit.setBounds((960 - 200) / 2, by + modes.length * (bh + 14) + 6, 200, 40);
        exit.addActionListener(e -> {
            SoundEngine.play(SoundEngine.SFX.MENU_CLICK);
            if (JOptionPane.showConfirmDialog(this, "Exit game?", "Exit",
                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
                System.exit(0);
        });
        root.add(exit);

        // ── Credits + sound toggle ────────────────────────────────────────────
        JLabel cred = new JLabel("Group: Fantastic 4  |  OOP Java Swing Project", SwingConstants.CENTER);
        cred.setFont(new Font("Arial", Font.PLAIN, 11));
        cred.setForeground(new Color(80, 80, 120));
        cred.setBounds(0, 596, 960, 18);
        root.add(cred);

        JCheckBox snd = new JCheckBox("🔊 Sound", true);
        snd.setForeground(new Color(150, 150, 195));
        snd.setFont(new Font("Arial", Font.BOLD, 12));
        snd.setOpaque(false); snd.setFocusPainted(false);
        snd.setBounds(858, 594, 94, 18);
        snd.addActionListener(e -> SoundEngine.setEnabled(snd.isSelected()));
        root.add(snd);

        setContentPane(root);
    }

    private JButton menuBtn(String text, String desc, Color col, int w, int h) {
        JButton b = new JButton(text) {
            boolean hov = false;
            { addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { hov = true;  repaint(); }
                public void mouseExited (MouseEvent e) { hov = false; repaint(); }
            }); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color c = hov ? col.brighter() : col;
                g2.setPaint(new GradientPaint(0, 0, c.brighter().brighter(), 0, getHeight(), c.darker()));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
                // Top highlight strip
                g2.setColor(new Color(255, 255, 255, hov ? 55 : 25));
                g2.fillRoundRect(4, 4, getWidth() - 8, getHeight() / 3, 8, 8);
                // Border
                g2.setColor(new Color(255, 255, 255, hov ? 95 : 45));
                g2.setStroke(new BasicStroke(hov ? 2f : 1.5f));
                g2.drawRoundRect(1, 1, getWidth() - 2, getHeight() - 2, 14, 14);
                // Two-line layout: measure both lines, center the block vertically
                Font mainFont = new Font("Arial", Font.BOLD, 19);
                Font descFont = new Font("Arial", Font.ITALIC, 11);
                g2.setFont(mainFont);
                FontMetrics mFm = g2.getFontMetrics();
                g2.setFont(descFont);
                FontMetrics dFm = g2.getFontMetrics();
                int lineGap   = 3;
                int totalH    = mFm.getAscent() + lineGap + dFm.getAscent();
                int blockTop  = (getHeight() - totalH) / 2;
                int mainY     = blockTop + mFm.getAscent();
                int descY     = mainY + lineGap + dFm.getAscent();
                // Main label
                g2.setFont(mainFont);
                g2.setColor(new Color(0, 0, 0, 80));
                g2.drawString(getText(), (getWidth() - mFm.stringWidth(getText())) / 2 + 1, mainY + 1);
                g2.setColor(Color.WHITE);
                g2.drawString(getText(), (getWidth() - mFm.stringWidth(getText())) / 2, mainY);
                // Description — centered
                g2.setFont(descFont);
                g2.setColor(new Color(255, 255, 255, 175));
                g2.drawString(desc, (getWidth() - dFm.stringWidth(desc)) / 2, descY);
            }
        };
        b.setPreferredSize(new Dimension(w, h));
        b.setOpaque(false); b.setContentAreaFilled(false);
        b.setBorderPainted(false); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    private void openSelect(GameMode mode) {
        if (mode == GameMode.ARCADE) {
            new ArcadeSelectForm(this).setVisible(true);
        } else {
            new CharacterSelectForm(mode).setVisible(true);
        }
        setVisible(false);
    }
}
