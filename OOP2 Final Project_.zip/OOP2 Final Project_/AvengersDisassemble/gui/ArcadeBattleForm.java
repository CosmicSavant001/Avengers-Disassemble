package gui;

import battle.BattleEngine;
import characters.Character;
import characters.CharacterFactory;
import abilities.Ability;
import game.GameMode;
import game.GameSession;
import ai.AIController;
import graphics.BackgroundRenderer;
import graphics.SoundEngine;
import graphics.SpriteAnimator;
import graphics.SpriteAnimator.State;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Arcade Mode battle screen.
 *
 * The player's chosen hero fights wave after wave of random opponents.
 * After each victory:
 *   • HP restored by 30 %  of max
 *   • A random new enemy is chosen (never the same one twice in a row)
 *   • Wave counter and streak score are updated
 *
 * Difficulty controls the enemy stat scaling via AIController.applyDifficultyScaling.
 * If the player loses, the run ends and a Game Over screen shows the final streak.
 */
public class ArcadeBattleForm extends JFrame implements BattleEngine.BattleListener {

    // ── Arcade run state ──────────────────────────────────────────────────────
    private final String                   playerCharName;
    private final AIController.Difficulty  difficulty;
    private       int                      wave;          // current wave number
    private       int                      streak;        // enemies defeated this run
    private       Character                playerChar;    // persists across waves (HP carries over)
    private       Character                enemyChar;

    private BattleEngine engine;

    // ── UI ────────────────────────────────────────────────────────────────────
    private SpriteAnimator  playerSprite, enemySprite;
    private JProgressBar    playerHP, enemyHP, playerMana, enemyMana;
    private JLabel          lblPlayerHP, lblEnemyHP, lblPlayerMana;
    private JLabel          lblPlayerStatus, lblEnemyStatus;
    private JLabel          lblTurn, lblWave, lblStreak;
    private JPanel          turnBar, skillsPanel;
    private JButton[]       skillBtns = new JButton[3];
    private JTextArea       logArea;
    private DamageNumberOverlay overlay;

    private int    turnNumber = 1;
    private int    homeX, homeY;
    private Timer  shakeTimer;
    private static final int MANA_REGEN = 30;

    // Enemy pool — all characters, shuffled each run
    private static final String[] ENEMY_POOL = CharacterFactory.CHARACTER_NAMES;
    private final List<String> enemyQueue = new ArrayList<>();
    private String lastEnemy = null;

    private static final Color BLUE   = new Color(60, 140, 255);
    private static final Color RED    = new Color(255, 70, 70);
    private static final Color ORANGE = new Color(255, 140, 0);

    // ── Constructor ───────────────────────────────────────────────────────────
    public ArcadeBattleForm(String playerCharName, AIController.Difficulty difficulty, int startWave) {
        this.playerCharName = playerCharName;
        this.difficulty     = difficulty;
        this.wave           = startWave;
        this.streak         = 0;

        // Create player character (persists)
        playerChar = CharacterFactory.createCharacter(playerCharName);
        playerChar.setTeam("BLUE");

        setTitle("Arcade Mode — Wave " + wave);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1120, 730);
        setLocationRelativeTo(null);
        setResizable(false);

        buildEnemyQueue();
        nextEnemy();   // pick first enemy
        buildUI();
        refreshAll();

        addWindowListener(new WindowAdapter() {
            @Override public void windowOpened(WindowEvent e)  { homeX = getX(); homeY = getY(); }
            @Override public void windowClosed(WindowEvent e)  {
                if (playerSprite != null) playerSprite.stopAnimation();
                if (enemySprite  != null) enemySprite.stopAnimation();
            }
        });

        SwingUtilities.invokeLater(() -> {
            homeX = getX(); homeY = getY();
            logBanner();
            playerSprite.setState(State.WALK);
            enemySprite.setState(State.WALK);
            Timer walkIn = new Timer(900, ev -> {
                playerSprite.setState(State.IDLE);
                enemySprite.setState(State.IDLE);
            });
            walkIn.setRepeats(false); walkIn.start();
        });
    }

    // ── Enemy management ──────────────────────────────────────────────────────
    private void buildEnemyQueue() {
        enemyQueue.clear();
        enemyQueue.addAll(Arrays.asList(ENEMY_POOL));
        Collections.shuffle(enemyQueue, new Random());
    }

    private void nextEnemy() {
        // Pick from queue, skipping the last used name
        if (enemyQueue.isEmpty()) buildEnemyQueue();

        String pick = null;
        for (int i = 0; i < enemyQueue.size(); i++) {
            String candidate = enemyQueue.get(i);
            if (!candidate.equals(playerCharName) && !candidate.equals(lastEnemy)) {
                pick = candidate;
                enemyQueue.remove(i);
                break;
            }
        }
        if (pick == null) { pick = enemyQueue.remove(0); }

        lastEnemy = pick;
        enemyChar = CharacterFactory.createCharacter(pick);
        enemyChar.setTeam("RED");

        // Scale enemy stats by difficulty
        AIController ai = new AIController(difficulty);
        ai.applyDifficultyScaling(enemyChar);

        // Create a fresh engine for this wave
        engine = new BattleEngine(playerChar, enemyChar);
        engine.setListener(this);
    }

    // ── UI construction ───────────────────────────────────────────────────────
    private void buildUI() {
        JLayeredPane layered = new JLayeredPane();
        layered.setPreferredSize(new Dimension(1120, 730));

        BackgroundRenderer.Arena arena = BackgroundRenderer.arenaFor(enemyChar.getName());

        JPanel root = new JPanel(new BorderLayout(0,0)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                BackgroundRenderer.paint(g2, getWidth(), getHeight(), arena);
            }
        };
        root.setOpaque(true);
        root.setBounds(0,0,1120,730);
        root.add(buildTurnBar(), BorderLayout.NORTH);
        root.add(buildArena(),   BorderLayout.CENTER);
        root.add(buildHUD(),     BorderLayout.SOUTH);

        overlay = new DamageNumberOverlay();
        overlay.setBounds(0,0,1120,730);
        layered.add(root,    JLayeredPane.DEFAULT_LAYER);
        layered.add(overlay, JLayeredPane.POPUP_LAYER);
        setContentPane(layered);
    }

    private JPanel buildTurnBar() {
        turnBar = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                Color c = engine.isBlueTeamTurn() ? new Color(10,35,120,235) : new Color(120,10,10,235);
                g2.setColor(c); g2.fillRect(0,0,getWidth(),getHeight());
                g2.setColor(new Color(255,255,255,20));
                g2.fillRect(0,getHeight()-2,getWidth(),2);
            }
        };
        turnBar.setOpaque(false);
        turnBar.setPreferredSize(new Dimension(1120,44));

        // Left: wave label + exit button
        JPanel leftWrap = new JPanel(new FlowLayout(FlowLayout.LEFT,8,7));
        leftWrap.setOpaque(false);

        lblWave = new JLabel("Wave 1");
        lblWave.setFont(new Font("Arial",Font.BOLD,13)); lblWave.setForeground(ORANGE);
        leftWrap.add(lblWave);

        JButton btnExit = new JButton("  EXIT  ") {
            boolean h=false;
            { addMouseListener(new java.awt.event.MouseAdapter(){
                public void mouseEntered(java.awt.event.MouseEvent e){h=true;repaint();}
                public void mouseExited (java.awt.event.MouseEvent e){h=false;repaint();}
            }); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                Color c=h?new Color(180,30,30):new Color(120,20,20);
                g2.setPaint(new GradientPaint(0,0,c.brighter(),0,getHeight(),c.darker()));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                g2.setColor(new Color(255,255,255,h?70:35));
                g2.setStroke(new BasicStroke(1.2f));
                g2.drawRoundRect(1,1,getWidth()-2,getHeight()-2,8,8);
                g2.setFont(new Font("Arial",Font.BOLD,11)); g2.setColor(Color.WHITE);
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
            }
        };
        btnExit.setPreferredSize(new Dimension(70,28));
        btnExit.setOpaque(false); btnExit.setContentAreaFilled(false);
        btnExit.setBorderPainted(false); btnExit.setFocusPainted(false);
        btnExit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnExit.addActionListener(e -> {
            int ch=JOptionPane.showConfirmDialog(ArcadeBattleForm.this,
                    "Exit to Main Menu? Your run will be lost.","Exit",JOptionPane.YES_NO_OPTION);
            if(ch==JOptionPane.YES_OPTION){
                if(playerSprite!=null) playerSprite.stopAnimation();
                if(enemySprite!=null)  enemySprite.stopAnimation();
                new MainMenuForm().setVisible(true);
                dispose();
            }
        });
        leftWrap.add(btnExit);

        lblTurn = new JLabel("", SwingConstants.CENTER);
        lblTurn.setFont(new Font("Impact",Font.BOLD,20)); lblTurn.setForeground(Color.WHITE);

        lblStreak = new JLabel("Streak: 0", SwingConstants.RIGHT);
        lblStreak.setFont(new Font("Arial",Font.BOLD,13)); lblStreak.setForeground(new Color(200,200,210));
        lblStreak.setBorder(BorderFactory.createEmptyBorder(0,0,0,14));

        turnBar.add(leftWrap,  BorderLayout.WEST);
        turnBar.add(lblTurn,   BorderLayout.CENTER);
        turnBar.add(lblStreak, BorderLayout.EAST);
        return turnBar;
    }

    private JPanel buildArena() {
        playerSprite = new SpriteAnimator(playerChar.getName(), false);
        enemySprite  = new SpriteAnimator(enemyChar.getName(),  true);

        JPanel canvas = new JPanel(null); canvas.setOpaque(false);
        int sprW=220, sprH=260;
        playerSprite.setBounds(60,           30, sprW, sprH);
        enemySprite.setBounds(1120-60-sprW,  30, sprW, sprH);
        canvas.add(playerSprite);
        canvas.add(enemySprite);

        // Floating HUD overlays
        canvas.add(buildFloatingHUD(playerChar, BLUE, true));
        canvas.add(buildFloatingHUD(enemyChar,  RED,  false));
        return canvas;
    }

    private JPanel buildFloatingHUD(Character c, Color col, boolean isPlayer) {
        JPanel p = new JPanel(new GridLayout(6,1,0,2)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0,0,0,145));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
            }
        };
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(5,8,5,8));
        p.setBounds(isPlayer ? 10 : 870, 4, 260, 92);

        JLabel name = new JLabel(c.getName(), isPlayer ? SwingConstants.LEFT : SwingConstants.RIGHT);
        name.setFont(new Font("Impact",Font.PLAIN,15)); name.setForeground(col);

        // HP = RED, MP = BLUE
        JProgressBar hp   = makeBar(c.getMaxHP(),   new Color(220,40,40),  new Color(30,5,5),  12);
        JProgressBar mana = makeBar(c.getMaxMana(), new Color(50,120,255), new Color(5,10,35),  8);
        JLabel hpLbl  = miniLbl("HP  "+c.getCurrentHP()+"/"+c.getMaxHP(), new Color(255,140,140));
        JLabel mpLbl  = miniLbl("MP  "+c.getCurrentMana()+"/"+c.getMaxMana(), new Color(120,180,255));
        JLabel stLbl  = miniLbl(" ", new Color(255,220,60));

        if (isPlayer) { playerHP=hp; playerMana=mana; lblPlayerHP=hpLbl; lblPlayerStatus=stLbl; }
        else          { enemyHP=hp;  enemyMana=mana;  lblEnemyHP=hpLbl;  lblEnemyStatus=stLbl;  }

        p.add(name); p.add(hp); p.add(hpLbl); p.add(mana); p.add(mpLbl); p.add(stLbl);
        return p;
    }

    private JPanel buildHUD() {
        JPanel hud = new JPanel(new GridLayout(1,2,10,0)) {
            @Override protected void paintComponent(Graphics g) {
                g.setColor(new Color(4,4,16,235)); g.fillRect(0,0,getWidth(),getHeight());
                g.setColor(new Color(60,40,120,160)); g.fillRect(0,0,getWidth(),2);
            }
        };
        hud.setOpaque(false);
        hud.setPreferredSize(new Dimension(1120,235));
        hud.setBorder(BorderFactory.createEmptyBorder(8,14,10,14));
        skillsPanel = buildSkillsPanel();
        hud.add(skillsPanel); hud.add(buildLogPanel());
        return hud;
    }

    private JPanel buildSkillsPanel() {
        JPanel p = new JPanel(new BorderLayout(0,7)); p.setOpaque(false);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(70,50,160,180),1),
                BorderFactory.createEmptyBorder(7,7,7,7)));

        JLabel title = new JLabel("⚔  SKILLS", SwingConstants.CENTER);
        title.setFont(new Font("Impact",Font.BOLD,15)); title.setForeground(new Color(225,185,55));
        p.add(title, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(3,1,0,7)); grid.setOpaque(false);
        Color[] cols = {new Color(22,68,158), new Color(68,22,128), new Color(148,52,14)};
        List<Ability> abs = playerChar.getAbilities();
        for (int i=0;i<3;i++) {
            final int idx=i;
            skillBtns[i] = skillBtn(abs.get(i), i, cols[i]);
            skillBtns[i].addActionListener(e -> handleSkill(idx));
            grid.add(skillBtns[i]);
        }
        p.add(grid, BorderLayout.CENTER);
        return p;
    }

    private JPanel buildLogPanel() {
        JPanel p = new JPanel(new BorderLayout(0,5)); p.setOpaque(false);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(70,50,160,180),1),
                BorderFactory.createEmptyBorder(7,7,7,7)));
        JLabel t = new JLabel("📜  BATTLE LOG", SwingConstants.CENTER);
        t.setFont(new Font("Impact",Font.BOLD,15)); t.setForeground(new Color(225,185,55));
        p.add(t, BorderLayout.NORTH);
        logArea = new JTextArea();
        logArea.setEditable(false); logArea.setBackground(new Color(3,3,12));
        logArea.setForeground(new Color(200,215,255)); logArea.setFont(new Font("Consolas",Font.PLAIN,11));
        logArea.setLineWrap(true); logArea.setWrapStyleWord(true);
        logArea.setBorder(BorderFactory.createEmptyBorder(4,4,4,4));
        JScrollPane sp = new JScrollPane(logArea);
        sp.setBorder(BorderFactory.createLineBorder(new Color(25,25,55)));
        p.add(sp, BorderLayout.CENTER);
        return p;
    }

    // ── Interaction ───────────────────────────────────────────────────────────
    private void handleSkill(int idx) {
        if (engine.isBattleOver()) return;
        // Make sure it is actually the player's turn before accepting input
        if (!engine.isBlueTeamTurn()) return;
        Character actor  = engine.getCurrentActor();
        Character target = engine.getCurrentTarget();
        Ability ab = actor.getAbilities().get(idx);
        if (ab.getTargetType()==Ability.TargetType.SELF||ab.getTargetType()==Ability.TargetType.SINGLE_ALLY) target=actor;
        // Check mana before committing
        if (actor.getCurrentMana() < ab.getManaCost()) {
            log("Not enough mana for " + ab.getName() + "! (" + actor.getCurrentMana() + "/" + ab.getManaCost() + " MP)");
            return;
        }
        setSkillsEnabled(false);
        playerSprite.playOnce(State.ATTACK, State.IDLE);
        final Character fa=actor, ft=target; final Ability fab=ab;
        Timer d = new Timer(300, e -> {
            engine.executeAbility(fa, ft, fab);
            if (!engine.isBattleOver()) {
                // After player turn, engine has flipped — it is now enemy's turn
                scheduleAI();
            }
        }); d.setRepeats(false); d.start();
    }

    private void scheduleAI() {
        // Guard: if it is actually the player's turn, hand control back
        if (!engine.isBattleOver() && engine.isBlueTeamTurn()) {
            rebuildSkillBtns();
            setSkillsEnabled(true);
            return;
        }
        setSkillsEnabled(false);
        Timer t = new Timer(1000, e -> {
            if (engine.isBattleOver()) return;
            // Double-check after the delay that it is still the enemy's turn
            if (engine.isBlueTeamTurn()) {
                rebuildSkillBtns(); setSkillsEnabled(true); return;
            }
            AIController ai = new AIController(difficulty);
            Character actor  = engine.getCurrentActor();
            Character target = engine.getCurrentTarget();

            // Pick an ability the AI can actually afford
            Ability ab = ai.selectAbility(actor, target);
            // If still not affordable (all abilities cost too much), force-pick the
            // cheapest ability and let BattleEngine grant a free mana boost so the
            // game never stalls.
            if (actor.getCurrentMana() < ab.getManaCost()) {
                Ability cheapest = actor.getAbilities().get(0);
                for (Ability a : actor.getAbilities()) {
                    if (a.getManaCost() < cheapest.getManaCost()) cheapest = a;
                }
                // Give the enemy just enough mana to use the cheapest skill
                actor.regenMana(cheapest.getManaCost());
                ab = cheapest;
            }

            if (ab.getTargetType()==Ability.TargetType.SELF||ab.getTargetType()==Ability.TargetType.SINGLE_ALLY) target=actor;
            enemySprite.playOnce(State.ATTACK, State.IDLE);
            final Character fa=actor, ft=target; final Ability fab=ab;
            Timer d = new Timer(280, e2 -> {
                engine.executeAbility(fa, ft, fab);
                if (!engine.isBattleOver()) {
                    // After enemy turn, engine has flipped — it is now player's turn
                    rebuildSkillBtns();
                    setSkillsEnabled(true);
                }
            }); d.setRepeats(false); d.start();
        });
        t.setRepeats(false); t.start();
    }

    // ── Wave transition ───────────────────────────────────────────────────────
    private void startNextWave() {
        // Partial HP restore: 30% of max
        int restore = (int)(playerChar.getMaxHP() * 0.30);
        playerChar.heal(restore);
        // Restore some mana too
        playerChar.regenMana((int)(playerChar.getMaxMana() * 0.40));

        wave++;
        streak++;
        nextEnemy();
        turnNumber = 1;

        // Rebuild the entire UI for the new wave
        getContentPane().removeAll();

        playerSprite = null; enemySprite = null;
        playerHP=null; enemyHP=null; playerMana=null; enemyMana=null;
        lblPlayerHP=null; lblEnemyHP=null; lblPlayerMana=null;
        lblPlayerStatus=null; lblEnemyStatus=null;
        lblTurn=null; lblWave=null; lblStreak=null;
        skillsPanel=null; logArea=null; overlay=null;
        skillBtns = new JButton[3];

        buildUI();
        setTitle("Arcade Mode — Wave " + wave);
        refreshAll();

        SwingUtilities.invokeLater(() -> {
            logBanner();
            playerSprite.setState(State.WALK);
            enemySprite.setState(State.WALK);
            Timer walkIn = new Timer(900, ev -> {
                playerSprite.setState(State.IDLE);
                enemySprite.setState(State.IDLE);
            });
            walkIn.setRepeats(false); walkIn.start();
        });
        revalidate(); repaint();
    }

    // ── Refresh ───────────────────────────────────────────────────────────────
    private void refreshAll() {
        if (playerHP==null||enemyHP==null) return;

        playerHP.setMaximum(playerChar.getMaxHP()); playerHP.setValue(playerChar.getCurrentHP());
        playerHP.setForeground(hpCol(playerChar.getHPPercent()));
        if(lblPlayerHP!=null) lblPlayerHP.setText(playerChar.getCurrentHP()+"/"+playerChar.getMaxHP());

        enemyHP.setMaximum(enemyChar.getMaxHP());   enemyHP.setValue(enemyChar.getCurrentHP());
        enemyHP.setForeground(hpCol(enemyChar.getHPPercent()));
        if(lblEnemyHP!=null) lblEnemyHP.setText(enemyChar.getCurrentHP()+"/"+enemyChar.getMaxHP());

        if(playerMana!=null){ playerMana.setMaximum(playerChar.getMaxMana()); playerMana.setValue(playerChar.getCurrentMana()); }
        if(enemyMana!=null){ enemyMana.setMaximum(enemyChar.getMaxMana());   enemyMana.setValue(enemyChar.getCurrentMana()); }

        String ps=playerChar.getStatusString(); if(lblPlayerStatus!=null) lblPlayerStatus.setText(ps.isEmpty()?" ":ps);
        String es=enemyChar.getStatusString();  if(lblEnemyStatus!=null)  lblEnemyStatus.setText(es.isEmpty()?" ":es);

        boolean bt=engine.isBlueTeamTurn();
        if(lblTurn!=null) lblTurn.setText(bt?"🔵  "+playerChar.getName().toUpperCase()+"'S TURN":"🔴  "+enemyChar.getName().toUpperCase()+"'S TURN");
        if(lblWave!=null)   lblWave.setText("Wave " + wave);
        if(lblStreak!=null) lblStreak.setText("Streak: " + streak);
        if(turnBar!=null)   turnBar.repaint();

        if(!playerChar.isAlive() && playerSprite!=null) playerSprite.setState(State.DEFEAT);
        if(!enemyChar.isAlive()  && enemySprite!=null)  enemySprite.setState(State.DEFEAT);
    }

    private void rebuildSkillBtns() {
        if (skillsPanel==null) return;
        JPanel grid = findGrid(skillsPanel);
        if (grid==null) return;
        List<Ability> abs = playerChar.getAbilities();
        Color[] cols={new Color(22,68,158),new Color(68,22,128),new Color(148,52,14)};
        grid.removeAll();
        for (int i=0;i<3;i++) {
            final int idx=i; Ability ab=abs.get(i);
            JButton nb=skillBtn(ab,i,cols[i]);
            nb.addActionListener(e->handleSkill(idx));
            nb.setEnabled(playerChar.getCurrentMana()>=ab.getManaCost()&&!playerChar.isStunned()&&!playerChar.isImmobilized());
            grid.add(nb); skillBtns[i]=nb;
        }
        grid.revalidate(); grid.repaint();
    }

    private JPanel findGrid(JPanel p) {
        for (Component c:p.getComponents())
            if (c instanceof JPanel)
                for (Component cc:((JPanel)c).getComponents())
                    if (cc instanceof JPanel) return (JPanel)cc;
        return null;
    }

    private void setSkillsEnabled(boolean en) { for(JButton b:skillBtns) if(b!=null) b.setEnabled(en); }

    private void doShake(boolean heavy) {
        if(shakeTimer!=null) shakeTimer.stop();
        final int[]f={heavy?10:5};
        shakeTimer=new Timer(30,e->{
            if(f[0]<=0){((Timer)e.getSource()).stop();setLocation(homeX,homeY);return;}
            setLocation(homeX+(int)((Math.random()-.5)*f[0]*(heavy?5:3)),
                        homeY+(int)((Math.random()-.5)*f[0]*(heavy?4:2)));
            f[0]--;
        }); shakeTimer.start();
    }

    private void logBanner() {
        log("══════════════════════════════════════");
        log("  🎮  WAVE " + wave + "  —  " + playerChar.getName() + " vs " + enemyChar.getName());
        log("  HP carry-in: " + playerChar.getCurrentHP() + "/" + playerChar.getMaxHP());
        log("══════════════════════════════════════");
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private JButton skillBtn(Ability ab, int idx, Color col) {
        JButton b = new JButton() {
            boolean h=false;
            { addMouseListener(new MouseAdapter(){
                public void mouseEntered(MouseEvent e){h=true;repaint();}
                public void mouseExited (MouseEvent e){h=false;repaint();}
            }); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg=isEnabled()?(h?col.brighter():col):new Color(30,30,44);
                g2.setPaint(new GradientPaint(0,0,bg.brighter(),0,getHeight(),bg.darker()));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
                g2.setColor(new Color(255,255,255,h?65:25)); g2.fillRoundRect(4,4,getWidth()-8,getHeight()/3,6,6);
                g2.setColor(new Color(255,255,255,h?85:40)); g2.setStroke(new BasicStroke(1.5f)); g2.drawRoundRect(1,1,getWidth()-2,getHeight()-2,12,12);
                g2.setColor(new Color(0,0,0,120)); g2.fillOval(7,5,22,22);
                g2.setFont(new Font("Impact",Font.BOLD,14)); g2.setColor(isEnabled()?Color.WHITE:new Color(90,90,100));
                g2.drawString(String.valueOf(idx+1),14,21);
                g2.setFont(new Font("Arial",Font.BOLD,12)); g2.setColor(isEnabled()?Color.WHITE:new Color(90,90,100));
                g2.drawString(ab.getName(),36,17);
                g2.setFont(new Font("Arial",Font.PLAIN,10));
                String dmg=(ab.getMinDamage()==0&&ab.getMaxDamage()==0)?"Heal/Effect":ab.getMinDamage()+"–"+ab.getMaxDamage()+" dmg";
                g2.setColor(new Color(255,210,110)); g2.drawString(dmg,36,30);
                if(ab.getEffectType()!=Ability.EffectType.NONE&&ab.getEffectType()!=Ability.EffectType.IGNORE_DEFENSE){
                    g2.setColor(new Color(255,175,55)); g2.drawString(ab.getEffectType().name().replace("_"," "),36,43);}
                g2.setColor(isEnabled()?new Color(100,165,255):new Color(70,70,90)); g2.drawString(ab.getManaCost()+" MP",getWidth()-56,17);
                String tgt=ab.getTargetType()==Ability.TargetType.ALL_ENEMIES?"◆ ALL":ab.getTargetType()==Ability.TargetType.SELF?"◆ SELF":ab.getTargetType()==Ability.TargetType.SINGLE_ALLY?"◆ ALLY":"◆ 1 TGT";
                g2.setColor(new Color(140,240,140)); g2.drawString(tgt,getWidth()-56,30);
            }
        };
        b.setPreferredSize(new Dimension(460,56));
        b.setOpaque(false); b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); return b;
    }

    private JProgressBar makeBar(int max, Color fg, Color bg, int h) {
        JProgressBar pb=new JProgressBar(0,max); pb.setValue(max); pb.setStringPainted(false);
        pb.setForeground(fg); pb.setBackground(bg); pb.setBorderPainted(false);
        pb.setPreferredSize(new Dimension(0,h)); return pb;
    }
    private JLabel miniLbl(String t, Color c) {
        JLabel l=new JLabel(t,SwingConstants.CENTER); l.setForeground(c); l.setFont(new Font("Arial",Font.PLAIN,10)); return l; }
    private Color hpCol(double p) { if(p>.55) return new Color(50,210,50); if(p>.28) return new Color(230,190,20); return new Color(230,40,40); }
    private void log(String m) { if(logArea!=null){logArea.append(m+"\n"); logArea.setCaretPosition(logArea.getDocument().getLength());} }

    // ── BattleEngine.BattleListener ───────────────────────────────────────────
    @Override public void onBattleLogUpdate(String msg) { SwingUtilities.invokeLater(()->log(msg)); }

    @Override public void onTurnChange(boolean blueTurn) {
        SwingUtilities.invokeLater(()->{ turnNumber++; refreshAll(); });
    }

    @Override public void onStatusUpdate() {
        SwingUtilities.invokeLater(()->{
            refreshAll();
            boolean bt=engine.isBlueTeamTurn();
            SpriteAnimator defSprite = bt ? playerSprite : enemySprite;
            List<String> bl=engine.getBattleLog();
            if (!bl.isEmpty()) {
                String last=bl.get(bl.size()-1);
                int px=bt?240:870; int py=180+(int)(Math.random()*100);
                if(!last.contains("healed")&&!last.contains("BOOST")&&!last.contains("shield")&&defSprite!=null)
                    defSprite.playOnce(State.HIT,State.IDLE);
                if      (last.contains("healed"))      overlay.spawnDamage(px,py,0,false,true);
                else if (last.contains("STUNNED"))     overlay.spawnStatus(px,py,"STUNNED!");
                else if (last.contains("CONFUSED"))    overlay.spawnStatus(px,py,"CONFUSED!");
                else if (last.contains("IMMOBILIZED")) overlay.spawnStatus(px,py,"IMMOBILIZED!");
                else if (last.contains("CRIT"))        { overlay.spawnDamage(px,py,0,true,false); doShake(true); }
                else if (last.contains("takes"))       doShake(false);
                String recent=String.join(" ",bl.subList(Math.max(0,bl.size()-3),bl.size()));
                if     (recent.contains("healed")||recent.contains(" HP")) SoundEngine.play(SoundEngine.SFX.HEAL);
                else if(recent.contains("STUN"))   SoundEngine.play(SoundEngine.SFX.STUN);
                else if(recent.contains("BOOST")||recent.contains("shield")) SoundEngine.play(SoundEngine.SFX.BUFF);
                else if(recent.contains("CRIT"))   SoundEngine.play(SoundEngine.SFX.HEAVY_ATTACK);
                else SoundEngine.play(SoundEngine.SFX.ATTACK);
            }
        });
    }

    @Override public void onBattleEnd(String winner) {
        SwingUtilities.invokeLater(()->{
            refreshAll(); setSkillsEnabled(false);
            boolean playerWon = winner.contains("Blue");

            if (playerWon) {
                streak++;
                if(playerSprite!=null) playerSprite.setState(State.VICTORY);
                SoundEngine.play(SoundEngine.SFX.VICTORY);
                log("══════════════════════════════════════");
                log("✦  WAVE " + wave + " CLEAR!  Streak: " + streak);
                log("  HP restored +30% — next enemy incoming!");
                log("══════════════════════════════════════");

                // Short pause, then advance to next wave
                Timer t = new Timer(2200, e -> startNextWave());
                t.setRepeats(false); t.start();
            } else {
                // Player lost — show arcade game over
                if(enemySprite!=null) enemySprite.setState(State.VICTORY);
                SoundEngine.play(SoundEngine.SFX.DEFEAT);
                log("══════════════════════════════════════");
                log("✖  DEFEATED on Wave " + wave + "  |  Streak: " + streak);
                log("══════════════════════════════════════");

                Timer t = new Timer(1400, e -> showArcadeGameOver());
                t.setRepeats(false); t.start();
            }
        });
    }

    private void showArcadeGameOver() {
        new ArcadeGameOverForm(this, playerCharName, wave, streak, difficulty).setVisible(true);
    }
}
