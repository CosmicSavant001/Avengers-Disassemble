package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Transparent overlay panel that shows floating damage/heal numbers above the arena.
 * Attach over the arena panel using LayeredPane.
 */
public class DamageNumberOverlay extends JPanel {

    private final List<FloatingNumber> numbers = new ArrayList<>();
    private final Timer animTimer;

    public DamageNumberOverlay() {
        setOpaque(false);
        setLayout(null);
        animTimer = new Timer(30, e -> tick());
        animTimer.start();
    }

    public void spawnDamage(int x, int y, int value, boolean isCrit, boolean isHeal) {
        numbers.add(new FloatingNumber(x, y, value, isCrit, isHeal));
        repaint();
    }

    public void spawnStatus(int x, int y, String text) {
        numbers.add(new FloatingNumber(x, y, text));
        repaint();
    }

    private void tick() {
        boolean changed = false;
        Iterator<FloatingNumber> it = numbers.iterator();
        while (it.hasNext()) {
            FloatingNumber fn = it.next();
            fn.tick();
            if (fn.isDead()) { it.remove(); changed = true; }
            else changed = true;
        }
        if (changed) repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        for (FloatingNumber fn : numbers) fn.draw(g2);
    }

    // ── inner class ───────────────────────────────────────────────────────────
    private static class FloatingNumber {
        float x, y;
        float vy;
        float alpha = 1f;
        int ticks = 0;
        int maxTicks = 50;
        String text;
        Color color;
        Font font;
        boolean isCrit;

        FloatingNumber(int x, int y, int value, boolean isCrit, boolean isHeal) {
            this.x = x + (float)(Math.random() * 40 - 20);
            this.y = y;
            this.vy = -2.5f;
            this.isCrit = isCrit;
            this.text = isHeal ? "+" + value + " HP" : (isCrit ? "CRIT! " : "") + value;
            this.color = isHeal ? new Color(80, 255, 100)
                       : isCrit ? new Color(255, 80, 80)
                                : new Color(255, 220, 60);
            this.font = new Font("Impact", Font.BOLD, isCrit ? 22 : 16);
            this.maxTicks = isCrit ? 65 : 50;
        }

        FloatingNumber(int x, int y, String statusText) {
            this.x = x + (float)(Math.random() * 30 - 15);
            this.y = y;
            this.vy = -1.5f;
            this.text = statusText;
            this.color = new Color(255, 160, 50);
            this.font = new Font("Arial", Font.BOLD, 13);
            this.maxTicks = 60;
        }

        void tick() {
            y += vy;
            vy *= 0.95f;
            ticks++;
            if (ticks > maxTicks / 2) alpha = 1f - (float)(ticks - maxTicks/2) / (maxTicks/2);
            alpha = Math.max(0, alpha);
        }

        boolean isDead() { return ticks >= maxTicks; }

        void draw(Graphics2D g2) {
            g2.setFont(font);
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));
            FontMetrics fm = g2.getFontMetrics();
            int tw = fm.stringWidth(text);
            // shadow
            g2.setColor(new Color(0, 0, 0, (int)(200 * alpha)));
            g2.drawString(text, (int)x - tw/2 + 2, (int)y + 2);
            // text
            g2.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(255 * alpha)));
            g2.drawString(text, (int)x - tw/2, (int)y);
            g2.setComposite(AlphaComposite.SrcOver);
        }
    }
}
