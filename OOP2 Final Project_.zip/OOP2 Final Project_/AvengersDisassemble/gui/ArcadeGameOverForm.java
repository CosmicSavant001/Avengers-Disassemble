package gui;

import ai.AIController;
import graphics.BackgroundRenderer;
import graphics.SpritePortrait;
import graphics.SoundEngine;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

/**
 * Arcade Mode Game Over screen — shows wave reached, streak count,
 * difficulty played, and offers Play Again or Main Menu.
 */
public class ArcadeGameOverForm extends JDialog {

    private final JFrame       parent;
    private final String       heroName;
    private final int          wave;
    private final int          streak;
    private final AIController.Difficulty difficulty;

    public ArcadeGameOverForm(JFrame parent, String heroName,
                               int wave, int streak,
                               AIController.Difficulty difficulty) {
        super(parent, "Arcade Mode — Run Over", true);
        this.parent     = parent;
        this.heroName   = heroName;
        this.wave       = wave;
        this.streak     = streak;
        this.difficulty = difficulty;
        setSize(560, 430);
        setLocationRelativeTo(parent);
        setResizable(false);
        build();
    }

    private void build() {
        JPanel root = new JPanel(new BorderLayout(0, 16)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,  RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                BackgroundRenderer.paint(g2,getWidth(),getHeight(),BackgroundRenderer.Arena.ULTRON_FACTORY);
                g2.setColor(new Color(0,0,0,175)); g2.fillRect(0,0,getWidth(),getHeight());
            }
        };
        root.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200,80,0),3),
                BorderFactory.createEmptyBorder(22,30,20,30)));

        // ── Top: portrait + title ─────────────────────────────────────────────
        BufferedImage portrait = SpritePortrait.render(heroName, 124, 148);
        // orange border
        BufferedImage framed = new BufferedImage(128,152,BufferedImage.TYPE_INT_ARGB);
        Graphics2D fg = framed.createGraphics();
        fg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        fg.setColor(new Color(200,80,0)); fg.fillRoundRect(0,0,128,152,12,12);
        fg.drawImage(portrait,2,2,null); fg.dispose();
        JLabel portLbl = new JLabel(new ImageIcon(framed), SwingConstants.CENTER);

        JLabel title = new JLabel("🎮  RUN OVER", SwingConstants.CENTER);
        title.setFont(new Font("Impact",Font.BOLD,38)); title.setForeground(new Color(255,140,0));

        JLabel sub = new JLabel(heroName + " has fallen!", SwingConstants.CENTER);
        sub.setFont(new Font("Arial",Font.BOLD,15)); sub.setForeground(new Color(220,170,170));

        JPanel textP = new JPanel(new GridLayout(3,1,0,6)); textP.setOpaque(false);
        textP.add(new JLabel("🎮", SwingConstants.CENTER) {{ setFont(new Font("Segoe UI Emoji",Font.PLAIN,44)); }});
        textP.add(title); textP.add(sub);

        JPanel topRow = new JPanel(new BorderLayout(16,0)); topRow.setOpaque(false);
        topRow.add(portLbl, BorderLayout.WEST);
        topRow.add(textP,   BorderLayout.CENTER);
        root.add(topRow, BorderLayout.NORTH);

        // ── Stats card ────────────────────────────────────────────────────────
        JPanel stats = new JPanel(new GridLayout(3,2,16,8)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(15,15,40,200)); g2.fillRoundRect(0,0,getWidth(),getHeight(),14,14);
                g2.setColor(new Color(200,80,0,120)); g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(1,1,getWidth()-2,getHeight()-2,14,14);
            }
        };
        stats.setOpaque(false);
        stats.setBorder(BorderFactory.createEmptyBorder(14,20,14,20));

        addStat(stats, "Hero",       heroName);
        addStat(stats, "Difficulty", difficulty.name());
        addStat(stats, "Waves Reached", "Wave " + wave);
        addStat(stats, "Enemies Defeated", String.valueOf(streak));
        addStat(stats, "Rating", rating(streak));
        addStat(stats, "Best Tip", streak < 3 ? "Try EASY mode to start!" : streak < 7 ? "Use heals wisely!" : "Legendary run! 🏆");
        root.add(stats, BorderLayout.CENTER);

        // ── Buttons ───────────────────────────────────────────────────────────
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER,14,0)); btns.setOpaque(false);

        JButton bAgain  = btn("  Play Again  ",    new Color(160,60,0));
        JButton bMenu   = btn("  Main Menu  ",    new Color(40,40,72));

        bAgain.addActionListener(e -> {
            SoundEngine.play(SoundEngine.SFX.MENU_CLICK);
            dispose(); parent.dispose();
            new ArcadeSelectForm(new MainMenuForm()).setVisible(true);
        });
        bMenu.addActionListener(e -> {
            SoundEngine.play(SoundEngine.SFX.MENU_CLICK);
            dispose(); parent.dispose();
            new MainMenuForm().setVisible(true);
        });

        btns.add(bAgain); btns.add(bMenu);
        root.add(btns, BorderLayout.SOUTH);
        setContentPane(root);
    }

    private void addStat(JPanel p, String key, String val) {
        JLabel k = new JLabel(key + ":", SwingConstants.RIGHT);
        k.setFont(new Font("Arial",Font.BOLD,13)); k.setForeground(new Color(160,160,200));
        JLabel v = new JLabel(val);
        v.setFont(new Font("Arial",Font.BOLD,14)); v.setForeground(new Color(255,180,60));
        p.add(k); p.add(v);
    }

    private String rating(int s) {
        if (s >= 15) return "S — LEGENDARY ★★★★★";
        if (s >= 10) return "A — HEROIC ★★★★";
        if (s >= 6)  return "B — FIGHTER ★★★";
        if (s >= 3)  return "C — ROOKIE ★★";
        return "D — Keep Training ★";
    }

    private JButton btn(String text, Color col) {
        JButton b = new JButton(text) {
            boolean h=false;
            { addMouseListener(new MouseAdapter(){
                public void mouseEntered(MouseEvent e){h=true;repaint();}
                public void mouseExited (MouseEvent e){h=false;repaint();}
            }); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g; g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp=new GradientPaint(0,0,h?col.brighter().brighter():col.brighter(),0,getHeight(),col.darker());
                g2.setPaint(gp); g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                g2.setColor(new Color(255,255,255,h?80:40)); g2.setStroke(new BasicStroke(1.5f)); g2.drawRoundRect(1,1,getWidth()-2,getHeight()-2,10,10);
                g2.setFont(new Font("Arial",Font.BOLD,13)); g2.setColor(Color.WHITE);
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
            }
        };
        b.setPreferredSize(new Dimension(165,40));
        b.setOpaque(false); b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); return b;
    }
}
