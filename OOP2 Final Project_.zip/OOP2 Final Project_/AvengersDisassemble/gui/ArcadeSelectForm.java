package gui;

import characters.CharacterFactory;
import game.GameMode;
import game.GameSession;
import ai.AIController;
import graphics.BackgroundRenderer;
import graphics.SpritePortrait;
import graphics.SoundEngine;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

/**
 * Arcade Mode hero select — player picks ONE hero and a difficulty,
 * then fights endless waves of random opponents.
 */
public class ArcadeSelectForm extends JFrame {

    private final JFrame parent;
    private String selectedChar = null;
    private AIController.Difficulty difficulty = AIController.Difficulty.NORMAL;

    private JLabel lblChosen, lblStats, lblPortrait;
    private JButton btnStart;
    private JPanel  cardGrid;

    private static final String[] ALL_CHARS = CharacterFactory.CHARACTER_NAMES;
    private static final Color ACCENT = new Color(200, 80, 0);

    public ArcadeSelectForm(JFrame parent) {
        this.parent = parent;
        setTitle("Arcade Mode — Choose Your Fighter");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 640);
        setLocationRelativeTo(null);
        setResizable(false);
        build();
    }

    private void build() {
        JPanel root = new JPanel(new BorderLayout(0, 0)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                BackgroundRenderer.paint(g2, getWidth(), getHeight(), BackgroundRenderer.Arena.ULTRON_FACTORY);
                g2.setColor(new Color(0, 0, 0, 155));
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        root.setBorder(BorderFactory.createEmptyBorder(14, 16, 14, 16));

        // ── Header ────────────────────────────────────────────────────────────
        JLabel title = new JLabel("🎮  ARCADE MODE — CHOOSE YOUR FIGHTER", SwingConstants.CENTER);
        title.setFont(new Font("Impact", Font.PLAIN, 26));
        title.setForeground(new Color(255, 160, 40));
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        root.add(title, BorderLayout.NORTH);

        // ── Character grid ────────────────────────────────────────────────────
        cardGrid = new JPanel(new GridLayout(2, 5, 8, 8));
        cardGrid.setOpaque(false);
        for (String c : ALL_CHARS) cardGrid.add(buildCard(c));
        root.add(cardGrid, BorderLayout.CENTER);

        // ── Bottom strip: difficulty + info + start ────────────────────────────
        JPanel bottom = new JPanel(new BorderLayout(12, 0));
        bottom.setOpaque(false);
        bottom.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        // Left: portrait + info
        lblPortrait = new JLabel("", SwingConstants.CENTER);
        lblPortrait.setPreferredSize(new Dimension(100, 112));

        lblChosen = new JLabel("Pick a hero to begin your run", SwingConstants.LEFT);
        lblChosen.setForeground(new Color(220, 185, 55));
        lblChosen.setFont(new Font("Impact", Font.PLAIN, 16));

        lblStats = new JLabel(" ", SwingConstants.LEFT);
        lblStats.setForeground(new Color(140, 240, 140));
        lblStats.setFont(new Font("Arial", Font.PLAIN, 12));

        JLabel arcadeDesc = new JLabel(
            "<html><i>Defeat enemies one after another.<br>Your HP partially restores after each win.<br>See how far you can go!</i></html>");
        arcadeDesc.setForeground(new Color(170, 170, 210));
        arcadeDesc.setFont(new Font("Arial", Font.PLAIN, 11));

        JPanel infoPanel = new JPanel(new GridLayout(3, 1, 0, 3));
        infoPanel.setOpaque(false);
        infoPanel.add(lblChosen); infoPanel.add(lblStats); infoPanel.add(arcadeDesc);

        JPanel leftPanel = new JPanel(new BorderLayout(8, 0));
        leftPanel.setOpaque(false);
        leftPanel.add(lblPortrait, BorderLayout.WEST);
        leftPanel.add(infoPanel,   BorderLayout.CENTER);
        bottom.add(leftPanel, BorderLayout.CENTER);

        // Right: difficulty + buttons
        JPanel rightPanel = new JPanel(new BorderLayout(0, 8));
        rightPanel.setOpaque(false);

        // Difficulty selector
        JPanel diffPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        diffPanel.setOpaque(false);
        JLabel diffLabel = new JLabel("DIFFICULTY:");
        diffLabel.setForeground(new Color(220, 185, 55));
        diffLabel.setFont(new Font("Impact", Font.PLAIN, 15));
        diffPanel.add(diffLabel);

        String[] dLabels = {"  EASY  ", " NORMAL ", "  HARD  "};
        Color[]  dColors = {new Color(30,130,30), new Color(30,80,180), new Color(180,30,30)};
        AIController.Difficulty[] diffs = {AIController.Difficulty.EASY, AIController.Difficulty.NORMAL, AIController.Difficulty.HARD};
        JButton[] diffBtns = new JButton[3];
        for (int di = 0; di < 3; di++) {
            final int idx = di;
            JButton db = new JButton(dLabels[di]) {
                { putClientProperty("sel", idx == 1);
                  addActionListener(ev -> {
                      difficulty = diffs[idx];
                      for (JButton b2 : diffBtns) { b2.putClientProperty("sel", b2 == this); b2.repaint(); }
                  }); }
                @Override protected void paintComponent(Graphics g) {
                    boolean sel = Boolean.TRUE.equals(getClientProperty("sel"));
                    Graphics2D g2 = (Graphics2D) g;
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    Color c = dColors[idx];
                    g2.setColor(sel ? c : new Color(c.getRed()/4, c.getGreen()/4, c.getBlue()/4, 200));
                    g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                    g2.setColor(sel ? Color.WHITE : new Color(c.getRed(),c.getGreen(),c.getBlue(),140));
                    g2.setStroke(new BasicStroke(sel?2f:1f));
                    g2.drawRoundRect(1,1,getWidth()-2,getHeight()-2,8,8);
                    g2.setFont(new Font("Impact",Font.PLAIN,13));
                    g2.setColor(sel ? Color.WHITE : new Color(170,170,170));
                    FontMetrics fm=g2.getFontMetrics();
                    String t=getText().trim();
                    g2.drawString(t,(getWidth()-fm.stringWidth(t))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
                }
            };
            db.setPreferredSize(new Dimension(76, 30));
            db.setOpaque(false); db.setContentAreaFilled(false); db.setBorderPainted(false); db.setFocusPainted(false);
            db.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            diffBtns[di] = db;
            diffPanel.add(db);
        }
        diffBtns[1].putClientProperty("sel", true);

        // Buttons row
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnRow.setOpaque(false);

        JButton back = actionBtn("  Back  ", new Color(50, 50, 80));
        back.addActionListener(e -> { SoundEngine.play(SoundEngine.SFX.MENU_CLICK); parent.setVisible(true); dispose(); });

        btnStart = actionBtn("  START RUN  ", ACCENT);
        btnStart.setEnabled(false);
        btnStart.addActionListener(e -> { SoundEngine.play(SoundEngine.SFX.SELECT); startArcade(); });

        btnRow.add(back); btnRow.add(btnStart);

        rightPanel.add(diffPanel, BorderLayout.NORTH);
        rightPanel.add(btnRow, BorderLayout.SOUTH);
        bottom.add(rightPanel, BorderLayout.EAST);

        root.add(bottom, BorderLayout.SOUTH);
        setContentPane(root);
    }

    private JPanel buildCard(String charName) {
        JPanel card = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                boolean sel = charName.equals(selectedChar);
                if (sel) {
                    g2.setPaint(new GradientPaint(0,0,new Color(ACCENT.getRed(),ACCENT.getGreen(),ACCENT.getBlue(),80),
                            0,getHeight(),new Color(ACCENT.getRed(),ACCENT.getGreen(),ACCENT.getBlue(),30)));
                } else {
                    g2.setColor(new Color(12,12,26));
                }
                g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                if (sel) {
                    g2.setColor(ACCENT); g2.setStroke(new BasicStroke(2.5f));
                    g2.drawRoundRect(1,1,getWidth()-2,getHeight()-2,10,10);
                }
            }
        };
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        BufferedImage img = SpritePortrait.render(charName, 84, 92);
        JLabel portLbl = new JLabel(new ImageIcon(img));
        portLbl.setOpaque(false);

        JLabel nm = new JLabel(charName.length() > 11 ? charName.substring(0,10)+"…" : charName, SwingConstants.CENTER);
        nm.setFont(new Font("Arial", Font.BOLD, 9));
        nm.setForeground(new Color(215, 215, 245));
        nm.setOpaque(false);

        card.add(portLbl, BorderLayout.CENTER);
        card.add(nm,      BorderLayout.SOUTH);

        card.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                SoundEngine.play(SoundEngine.SFX.SELECT);
                selectedChar = charName;
                cardGrid.repaint();
                lblChosen.setText("✓  " + charName);
                characters.Character c = CharacterFactory.createCharacter(charName);
                lblStats.setText("HP: " + c.getMaxHP() + "  |  MP: " + c.getMaxMana() + "  |  Skills: 3");
                lblPortrait.setIcon(new ImageIcon(SpritePortrait.render(charName, 96, 108)));
                btnStart.setEnabled(true);
            }
        });
        return card;
    }

    private void startArcade() {
        if (selectedChar == null) return;
        dispose();
        new ArcadeBattleForm(selectedChar, difficulty, 1).setVisible(true);
    }

    private JButton actionBtn(String text, Color col) {
        JButton b = new JButton(text) {
            boolean h = false;
            { addMouseListener(new MouseAdapter(){
                public void mouseEntered(MouseEvent e){h=true;repaint();}
                public void mouseExited (MouseEvent e){h=false;repaint();}
            }); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                Color c = isEnabled() ? (h ? col.brighter() : col) : new Color(40,40,55);
                g2.setPaint(new GradientPaint(0,0,c.brighter(),0,getHeight(),c.darker()));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                g2.setColor(new Color(255,255,255,h?70:35));
                g2.setStroke(new BasicStroke(1.5f)); g2.drawRoundRect(1,1,getWidth()-2,getHeight()-2,10,10);
                g2.setFont(new Font("Arial",Font.BOLD,14)); g2.setColor(isEnabled()?Color.WHITE:new Color(90,90,100));
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
            }
        };
        b.setPreferredSize(new Dimension(160, 42));
        b.setOpaque(false); b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }
}
