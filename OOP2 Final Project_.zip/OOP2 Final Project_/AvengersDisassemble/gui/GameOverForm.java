package gui;

import game.GameSession;
import game.GameMode;
import graphics.CharacterPortraitRenderer;
import graphics.BackgroundRenderer;
import graphics.SoundEngine;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

public class GameOverForm extends JDialog {
    private final String winner;
    private final GameSession session;
    private final BattleForm battleForm;

    public GameOverForm(String winner, GameSession session, BattleForm battleForm) {
        super(battleForm, "Battle Over", true);
        this.winner = winner; this.session = session; this.battleForm = battleForm;
        setSize(540, 390);
        setLocationRelativeTo(battleForm);
        setResizable(false);
        build();
    }

    private void build() {
        JPanel root = new JPanel(new BorderLayout(0,16)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g; g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                BackgroundRenderer.paint(g2,getWidth(),getHeight(),BackgroundRenderer.Arena.DEFAULT_ARENA);
                g2.setColor(new Color(0,0,0,175)); g2.fillRect(0,0,getWidth(),getHeight());
            }
        };
        root.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(205,175,35),3),
                BorderFactory.createEmptyBorder(24,32,22,32)));

        // winner character name extraction
        String charName = winner.contains("(") ? winner.substring(0,winner.lastIndexOf("(")).trim() : winner;
        // handle "Name (Blue/Red Team)"
        if (charName.endsWith("Blue Team") || charName.endsWith("Red Team"))
            charName = charName.replaceAll("\\s*\\(.*","").trim();

        // LEFT: big portrait of winner
        BufferedImage portrait = CharacterPortraitRenderer.render(charName, 130, 155);
        // gold border effect
        BufferedImage framed = new BufferedImage(134,159,BufferedImage.TYPE_INT_ARGB);
        Graphics2D fg = framed.createGraphics();
        fg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        fg.setColor(new Color(205,175,35)); fg.fillRoundRect(0,0,134,159,12,12);
        fg.drawImage(portrait,2,2,null); fg.dispose();
        JLabel portLbl = new JLabel(new ImageIcon(framed), SwingConstants.CENTER);

        // RIGHT: text
        JLabel trophy = new JLabel("🏆", SwingConstants.CENTER);
        trophy.setFont(new Font("Segoe UI Emoji",Font.PLAIN,52));

        JLabel goLbl = new JLabel("BATTLE OVER!", SwingConstants.CENTER);
        goLbl.setFont(new Font("Impact",Font.BOLD,36)); goLbl.setForeground(new Color(225,185,55));

        // winner label
        boolean blueWon = winner.contains("Blue");
        JLabel winLbl = new JLabel(
            "<html><center><font color='"+( blueWon ? "#5599ff" : "#ff5555")+"'>"
            + charName + "</font><br><font color='white' size='4'>WINS THE BATTLE!</font></center></html>",
            SwingConstants.CENTER);
        winLbl.setFont(new Font("Arial",Font.BOLD,15));

        JPanel textP = new JPanel(new GridLayout(3,1,0,6)); textP.setOpaque(false);
        textP.add(trophy); textP.add(goLbl); textP.add(winLbl);

        JPanel center = new JPanel(new BorderLayout(16,0)); center.setOpaque(false);
        center.add(portLbl, BorderLayout.WEST); center.add(textP, BorderLayout.CENTER);
        root.add(center, BorderLayout.CENTER);

        // BUTTONS
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER,14,0)); btns.setOpaque(false);
        JButton bR = btn("  Rematch  ",       new Color(28,78,158));
        JButton bN = btn("  New Fighters  ",  new Color(68,42,115));
        JButton bM = btn("  Main Menu  ",     new Color(42,42,72));

        bR.addActionListener(e -> {
            SoundEngine.play(SoundEngine.SFX.MENU_CLICK);
            dispose(); battleForm.dispose();
            GameSession ns = new GameSession(session.getMode());
            ns.setBlueCharacter(session.getBlueCharacter().getName());
            ns.setRedCharacter(session.getRedCharacter().getName());
            if(session.getBlueAI()!=null) ns.setBlueAI(session.getBlueAI().getDifficulty());
            if(session.getRedAI() !=null) ns.setRedAI(session.getRedAI().getDifficulty());
            new BattleForm(ns).setVisible(true);
        });
        bN.addActionListener(e -> { SoundEngine.play(SoundEngine.SFX.MENU_CLICK); dispose(); battleForm.dispose(); new CharacterSelectForm(session.getMode()).setVisible(true); });
        bM.addActionListener(e -> { SoundEngine.play(SoundEngine.SFX.MENU_CLICK); dispose(); battleForm.dispose(); new MainMenuForm().setVisible(true); });

        btns.add(bR); btns.add(bN); btns.add(bM);
        root.add(btns, BorderLayout.SOUTH);
        setContentPane(root);
    }

    private JButton btn(String text, Color col) {
        JButton b = new JButton(text) {
            boolean h=false;
            { addMouseListener(new MouseAdapter(){ public void mouseEntered(MouseEvent e){h=true;repaint();} public void mouseExited(MouseEvent e){h=false;repaint();} }); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g; g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp=new GradientPaint(0,0,h?col.brighter().brighter():col.brighter(),0,getHeight(),col.darker());
                g2.setPaint(gp); g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                g2.setColor(new Color(255,255,255,h?80:40)); g2.setStroke(new BasicStroke(1.5f)); g2.drawRoundRect(1,1,getWidth()-2,getHeight()-2,10,10);
                g2.setFont(new Font("Arial",Font.BOLD,13)); g2.setColor(Color.WHITE);
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,(getHeight()+fm.getAscent()-fm.getDescent())/2);
            }
        };
        b.setPreferredSize(new Dimension(152,40));
        b.setOpaque(false); b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }
}
