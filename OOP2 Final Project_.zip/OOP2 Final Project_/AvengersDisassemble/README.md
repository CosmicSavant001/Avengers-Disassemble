# Avengers: Disassemble
### Group: Fantastic 4 | Turn-Based Java Swing OOP Game

---

## ▶ How to Run (no build needed)
```
java -jar AvengersDisassemble.jar
```
Requires Java 8 or higher.

## ⚙ Build from Source
**Windows:**
```bat
build.bat
```
**Linux / Mac:**
```bash
chmod +x build.sh && ./build.sh
```
**IntelliJ IDEA:** Mark `src/` and `gui/` as Sources Root → Run `Main`

---

## 🎮 Game Modes
| Mode | Description |
|---|---|
| Player vs Player | Both players take turns choosing skills |
| Player vs AI | You control Blue Team; AI controls Red Team |
| Arcade / AI vs AI | Spectate a fully automated battle |

---

## 🦸 Characters (10 total)
| Hero | HP | Mana | Special |
|---|---|---|---|
| Iron Man | 2400 | 500 | Arc Reactor damage / Armor Boost |
| Spider-Man | 2100 | 450 | Immobilize / High crit combo |
| Thor | 2700 | 400 | AoE lightning / Storm |
| Hulk | 3500 | 300 | Highest HP / Rage buff |
| Black Widow | 2000 | 450 | Defense reduction / Speed boost |
| Scarlet Witch | 2200 | 600 | Confuse all / Reality wave |
| Doctor Strange | 2100 | 650 | Shield / Heal / Defense ignore |
| Cadie | 2600 | 350 | Flerken cat / Heal + defense buff |
| Loki | 3800 | 750 | Stun AoE / Clone illusion |
| Ultron | 4200 | 600 | Highest HP / Defense shred |

---

## 🎨 Visual Features
- **Splash screen** with all 10 character portraits, loading bar, fade in/out
- **Hand-drawn character portraits** for every hero/villain (Java2D, no image files)
- **9 unique Marvel arena backgrounds**: Stark Tower, NYC, Asgard, Gamma Lab,
  S.H.I.E.L.D. Helicarrier, Scarlet Dimension, Sanctum Sanctorum, Space Nebula, Ultron Factory
- **Floating damage numbers** that drift up and fade over the battle arena
- **Screen shake** on normal hits; stronger shake on critical hits
- **Greyscale + X portrait** when a character is defeated
- **Animated HP/MP bars** with colour transitions (green → yellow → red)
- **Turn counter** displayed in the HUD

## 🔊 Sound Features
- Synthesised sound effects (no audio files) via `javax.sound.sampled`
- Attack, heavy attack, heal, buff, stun, magic, victory, defeat, UI clicks
- Sound toggle checkbox on the main menu

## ⚔ Battle System
- Turn-based: Blue Team → Red Team → repeat
- **Mana regen**: +30 MP to defender each turn
- Status effects: Stun, Confuse, Immobilize, Shield, Attack/Defense/Speed Boost, Defense Reduction
- Critical hits (variable per skill), AoE vs single-target skills
- AI difficulties: Easy (random), Normal (50% optimal), Hard (HP-aware optimal)

---

## 🧠 OOP Concepts Demonstrated
| Concept | Where |
|---|---|
| Abstraction | `Character` abstract class |
| Inheritance | All 10 character subclasses extend `Character` |
| Polymorphism | `initAbilities()` overridden per character |
| Encapsulation | Private fields, public getters/setters |
| Interface | `BattleEngine.BattleListener` |
| Factory Pattern | `CharacterFactory.createCharacter(name)` |
| Strategy Pattern | `AIController` difficulty strategies |
| Observer Pattern | `BattleListener` callbacks from engine to GUI |
