#!/bin/bash
echo "=== Building Avengers: Disassemble ==="
mkdir -p out
javac -d out -encoding UTF-8 \
  src/abilities/Ability.java \
  src/characters/Character.java \
  src/characters/IronMan.java src/characters/SpiderMan.java src/characters/Thor.java \
  src/characters/Hulk.java src/characters/BlackWidow.java src/characters/ScarletWitch.java \
  src/characters/DoctorStrange.java src/characters/Cadie.java \
  src/characters/Loki.java src/characters/Ultron.java \
  src/characters/CharacterFactory.java \
  src/battle/BattleResult.java src/battle/BattleEngine.java \
  src/ai/AIController.java \
  src/game/GameMode.java src/game/GameSession.java \
  src/graphics/SpriteLoader.java \
  src/graphics/SpriteAnimator.java \
  src/graphics/CharacterPortraitRenderer.java \
  src/graphics/BackgroundRenderer.java \
  src/graphics/SoundEngine.java \
  gui/DamageNumberOverlay.java \
  gui/SplashScreen.java \
  gui/GameOverForm.java \
  gui/CharacterSelectForm.java \
  gui/BattleForm.java \
  gui/MainMenuForm.java \
  Main.java && echo "BUILD SUCCESS" && java -cp out Main
